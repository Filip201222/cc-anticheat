/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.combat.clickpatterns;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.violation.ViolationProcessor;

import java.util.*;

/**
 * cc-anticheat — ClickPatternEnsemble
 *
 * Combines all 7 Intave click-pattern detectors into one class with:
 *  1. Fixed EqualDelay (makeDetection was missing in Intave source)
 *  2. Weighted ensemble scoring across all sub-checks
 *  3. Coefficient of Variation instead of raw SD for Deviation (scale-independent)
 *  4. Bigram entropy for Entropy check (detects two-delay bots)
 *  5. Cross-check: player passes individual thresholds but ensemble score is suspicious
 *
 * Sub-checks and weights:
 *   Deviation   1.5  — SD/mean of inter-click delays
 *   Entropy     1.2  — Shannon entropy of delay distribution
 *   EqualDelay  1.3  — fixed repeating delay pattern (was dead in Intave)
 *   Kurtosis    1.0  — peakedness of delay distribution
 *   Bursts      0.8  — click bursts without natural double-click variation
 *   Fluctuation 1.0  — variance-over-time instability
 *   Repetitive  0.9  — long same-delay streaks
 */
public class ClickPatternEnsemble extends Check {

    // ── Buffer sizes (matching Intave) ────────────────────────────────────────
    private static final int BUF_DEVIATION   = 50;
    private static final int BUF_ENTROPY     = 100;
    private static final int BUF_KURTOSIS    = 25;
    private static final int BUF_EQUALDEL    = 40;   // tick-aligned history
    private static final int BUF_REPETITIVE  = 60;
    private static final int TIMEOUT_MS      = 4000;

    // ── Ensemble flag threshold ───────────────────────────────────────────────
    private static final double ENSEMBLE_FLAG_THRESHOLD = 18.0;

    // ── Stan VL per sub-check ────────────────────────────────────────────────
    // UWAGA (Etap 1): wcześniej te pola żyły w PlayerData. Ponieważ CheckManager
    // trzyma jedną instancję ClickPatternEnsemble na gracza (patrz PlayerChecks),
    // stan lokalny w instancji jest równoważny i prostszy — nie wymaga
    // rozdymania współdzielonego PlayerData polami specyficznymi dla jednego checka.
    private double vlDeviation   = 0;
    private double vlEntropy     = 0;
    private double vlKurtosis    = 0;
    private double vlBursts      = 0;
    private double vlFluctuation = 0;
    private double vlEqualDelay  = 0;
    private double vlRepetitive  = 0;
    private double clickEnsembleVL = 0;

    public ClickPatternEnsemble(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "ClickPattern");
    }

    /** Re-compute weighted ensemble VL from all 7 click-pattern sub-checks. */
    private void recomputeClickEnsemble() {
        clickEnsembleVL =
              vlDeviation   * 1.5
            + vlEntropy     * 1.2
            + vlKurtosis    * 1.0
            + vlBursts      * 0.8
            + vlFluctuation * 1.0
            + vlEqualDelay  * 1.3
            + vlRepetitive  * 0.9;
    }

    /**
     * Entry point: called on every ARM_ANIMATION packet.
     */
    public void onSwing() {
        long now   = System.currentTimeMillis();
        long delay = now - data.lastSwingMs;
        data.lastSwingMs = now;

        if (data.isClickCheckDeactivated(delay)) {
            data.swingDelays.clear();
            // Decay all VLs slowly while deactivated
            decayAll(0.05);
            recomputeClickEnsemble();
            return;
        }

        data.swingDelays.addLast(delay);

        // Run all sub-checks
        runDeviation(delay);
        runEntropy();
        runKurtosis();
        runEqualDelay();
        runBursts();
        runFluctuation();
        runRepetitive();

        // Recompute ensemble
        recomputeClickEnsemble();
        checkEnsemble();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 1. DEVIATION  (Intave Deviation, improved with CV)
    // ─────────────────────────────────────────────────────────────────────────
    private void runDeviation(long latestDelay) {
        if (data.swingDelays.size() < BUF_DEVIATION) return;

        Collection<Long> window = windowOf(data.swingDelays, BUF_DEVIATION);
        double mean = mean(window);
        double sd   = standardDeviation(window, mean);

        // Coefficient of Variation — scale-independent, unlike raw SD
        double cv = mean > 0 ? sd / mean : 0;

        if (cv < 0.08 && mean < TIMEOUT_MS) {
            // Very uniform clicking — likely autoclick
            int add = cv < 0.03 ? 2 : 1;
            vlDeviation += add;
            if (vlDeviation > 2) {
                vp.flag(data, "ClickPattern/Deviation",
                    String.format("cv:%.4f mean:%.1f sd:%.2f vl:%.1f", cv, mean, sd, vlDeviation),
                    vlDeviation > 0 ? 8.0 : 0.0, false);
            }
        } else {
            vlDeviation = Math.max(0, (vlDeviation - 0.1) * 0.9);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 2. ENTROPY  (Intave Entropy + bigram check)
    // ─────────────────────────────────────────────────────────────────────────
    private void runEntropy() {
        if (data.swingDelays.size() < BUF_ENTROPY) return;

        Collection<Long> window = windowOf(data.swingDelays, BUF_ENTROPY);

        // Unigram entropy
        double entropy = shannonEntropy(window);

        if (entropy <= 1.0 && entropy >= 0.35) {
            vlEntropy += 2;
            if (vlEntropy > 1) {
                vp.flag(data, "ClickPattern/Entropy",
                    String.format("H:%.3f vl:%.1f", entropy, vlEntropy),
                    vlEntropy > 0 ? 5.0 : 0.0, false);
            }
        } else {
            // Bigram entropy — detects two-delay alternating bots (high unigram, low bigram)
            double bigramH = bigramEntropy(new ArrayList<>(window));
            if (bigramH < 0.6 && entropy > 2.0) {
                vlEntropy += 1;
                vp.flag(data, "ClickPattern/BigramEntropy",
                    String.format("H:%.3f bigram:%.3f", entropy, bigramH),
                    3.0, false);
            } else {
                vlEntropy = Math.max(0, (vlEntropy - 0.2) * 0.98);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 3. KURTOSIS  (Intave Kurtosis — unchanged, solid)
    // ─────────────────────────────────────────────────────────────────────────
    private void runKurtosis() {
        if (data.swingDelays.size() < BUF_KURTOSIS) return;

        List<Long> window = new ArrayList<>(windowOf(data.swingDelays, BUF_KURTOSIS));
        double k = kurtosis(window) / 1000.0;

        if (k < 6.0) {
            vlKurtosis += 1.0;
            if (vlKurtosis > 15) {
                vp.flag(data, "ClickPattern/Kurtosis",
                    String.format("k:%.2f vl:%.1f", k, vlKurtosis),
                    vlKurtosis > 24 ? 5.0 : 2.5, false);
            }
        } else {
            vlKurtosis = Math.max(0, (vlKurtosis - 0.1) * 0.98);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 4. EQUAL DELAY  (Intave EqualDelay — FIXED: was missing makeDetection)
    // ─────────────────────────────────────────────────────────────────────────
    private void runEqualDelay() {
        if (data.swingDelays.size() < BUF_EQUALDEL) return;

        List<Long> window = new ArrayList<>(windowOf(data.swingDelays, BUF_EQUALDEL));

        // Build inter-click delay list
        int maxStreak   = 0;
        int streak      = 1;
        long lastDelay  = window.get(0);

        for (int i = 1; i < window.size(); i++) {
            long d = window.get(i);
            if (Math.abs(d - lastDelay) <= 2) { // ±2ms tolerance (jitter)
                streak++;
                if (streak > maxStreak) maxStreak = streak;
            } else {
                streak = 1;
            }
            lastDelay = d;
        }

        // Dynamic streak limit from Intave (longer delays = more tolerance)
        int limit = 10;
        if (lastDelay > 50)  limit += 2;
        if (lastDelay > 100) limit += 2;
        if (lastDelay > 150) limit += 2;

        if (maxStreak > limit) {
            vlEqualDelay += 2;
            // ← THIS IS THE FIX: Intave's EqualDelay had analyzeClicks() but no makeDetection()
            if (vlEqualDelay > 4) {
                vp.flag(data, "ClickPattern/EqualDelay",
                    String.format("streak:%d limit:%d delay:%dms vl:%.1f",
                        maxStreak, limit, lastDelay, vlEqualDelay),
                    vlEqualDelay > 0 ? 10.0 : 0.0, false);
            }
        } else {
            vlEqualDelay = Math.max(0, (vlEqualDelay - 0.15) * 0.95);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 5. BURSTS  (Intave Bursts — no double-click variation)
    // ─────────────────────────────────────────────────────────────────────────
    private void runBursts() {
        if (data.swingDelays.size() < 40) return;

        List<Long> window = new ArrayList<>(windowOf(data.swingDelays, 40));

        // Count runs of very fast clicks (< 30ms = sub-tick, suggests jitter click macro)
        int fastStreak = 0;
        int maxFast    = 0;
        for (long d : window) {
            if (d < 30) {
                fastStreak++;
                if (fastStreak > maxFast) maxFast = fastStreak;
            } else {
                fastStreak = 0;
            }
        }

        if (maxFast >= 5) {
            vlBursts += 0.8;
            vp.flag(data, "ClickPattern/Bursts",
                String.format("fastStreak:%d vl:%.1f", maxFast, vlBursts),
                5.0, false);
        } else {
            vlBursts = Math.max(0, vlBursts - 0.05);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 6. FLUCTUATION  (Intave Fluctuation — variance over time)
    // ─────────────────────────────────────────────────────────────────────────
    private void runFluctuation() {
        int size = data.swingDelays.size();
        if (size < 60) return;

        List<Long> all    = new ArrayList<>(data.swingDelays);
        int half          = all.size() / 2;
        List<Long> first  = all.subList(0, half);
        List<Long> second = all.subList(half, all.size());

        double sd1 = standardDeviation(first,  mean(first));
        double sd2 = standardDeviation(second, mean(second));

        // Real humans have natural fluctuation in their click SD over time.
        // Bots maintain suspiciously stable SD across time windows.
        double sdRatio = Math.min(sd1, sd2) / Math.max(Math.max(sd1, sd2), 1);

        if (sdRatio > 0.92 && sd1 < 15 && sd2 < 15) {
            // SD is almost identical in both halves AND both are low → bot
            vlFluctuation += 1;
            if (vlFluctuation > 5) {
                vp.flag(data, "ClickPattern/Fluctuation",
                    String.format("sd1:%.2f sd2:%.2f ratio:%.3f vl:%.1f",
                        sd1, sd2, sdRatio, vlFluctuation),
                    4.0, false);
            }
        } else {
            vlFluctuation = Math.max(0, (vlFluctuation - 0.08) * 0.97);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 7. REPETITIVE  (Intave Repetitive — long same-delay streaks)
    // ─────────────────────────────────────────────────────────────────────────
    private void runRepetitive() {
        if (data.swingDelays.size() < BUF_REPETITIVE) return;

        List<Long> window = new ArrayList<>(windowOf(data.swingDelays, BUF_REPETITIVE));

        // Count how many unique delay values appear
        Set<Long> unique = new HashSet<>();
        for (long d : window) unique.add(d / 5 * 5); // bucket to 5ms

        double uniqueRatio = (double) unique.size() / window.size();

        if (uniqueRatio < 0.06 && !window.isEmpty()) {
            // Less than 6% unique delay buckets over 60 samples → extremely repetitive
            vlRepetitive += 1.5;
            if (vlRepetitive > 6) {
                vp.flag(data, "ClickPattern/Repetitive",
                    String.format("unique:%d/%d ratio:%.3f vl:%.1f",
                        unique.size(), window.size(), uniqueRatio, vlRepetitive),
                    6.0, false);
            }
        } else {
            vlRepetitive = Math.max(0, (vlRepetitive - 0.1) * 0.96);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ENSEMBLE CHECK — catches bots that stay under each individual threshold
    // ─────────────────────────────────────────────────────────────────────────
    private void checkEnsemble() {
        if (clickEnsembleVL > ENSEMBLE_FLAG_THRESHOLD) {
            vp.flag(data, "ClickPattern/Ensemble",
                String.format("score:%.2f [D:%.1f E:%.1f K:%.1f B:%.1f F:%.1f EQ:%.1f R:%.1f]",
                    clickEnsembleVL,
                    vlDeviation, vlEntropy, vlKurtosis,
                    vlBursts, vlFluctuation, vlEqualDelay, vlRepetitive),
                clickEnsembleVL, false);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Math helpers
    // ─────────────────────────────────────────────────────────────────────────

    private static double mean(Collection<? extends Number> c) {
        double sum = 0;
        for (Number n : c) sum += n.doubleValue();
        return c.isEmpty() ? 0 : sum / c.size();
    }

    private static double standardDeviation(Collection<? extends Number> c, double mean) {
        double sum = 0;
        for (Number n : c) {
            double d = n.doubleValue() - mean;
            sum += d * d;
        }
        return c.isEmpty() ? 0 : Math.sqrt(sum / c.size());
    }

    private static double shannonEntropy(Collection<? extends Number> c) {
        Map<Long, Integer> counts = new HashMap<>();
        for (Number n : c) {
            long bucket = n.longValue() / 5 * 5; // 5ms buckets
            counts.merge(bucket, 1, Integer::sum);
        }
        double entropy = 0;
        int total = c.size();
        for (int cnt : counts.values()) {
            double p = (double) cnt / total;
            entropy -= p * (Math.log(p) / Math.log(2));
        }
        return entropy;
    }

    /** H(X_{n+1} | X_n) — conditional entropy on delay pairs */
    private static double bigramEntropy(List<Long> delays) {
        if (delays.size() < 4) return 10.0;
        Map<String, Integer> pairCounts = new HashMap<>();
        Map<Long, Integer>   firstCounts = new HashMap<>();
        int total = delays.size() - 1;

        for (int i = 0; i < total; i++) {
            long a = delays.get(i)   / 5 * 5;
            long b = delays.get(i+1) / 5 * 5;
            String key = a + "," + b;
            pairCounts.merge(key, 1, Integer::sum);
            firstCounts.merge(a, 1, Integer::sum);
        }

        double h = 0;
        for (Map.Entry<String, Integer> e : pairCounts.entrySet()) {
            long a = Long.parseLong(e.getKey().split(",")[0]);
            double pAB = (double) e.getValue() / total;
            double pA  = (double) firstCounts.getOrDefault(a, 1) / total;
            double pBgA = pAB / pA;
            if (pBgA > 0) h -= pAB * (Math.log(pBgA) / Math.log(2));
        }
        return h;
    }

    private static double kurtosis(List<? extends Number> input) {
        int n = input.size();
        if (n < 3) return 0;

        double sum = 0;
        for (Number x : input) sum += x.doubleValue();
        double mean = sum / n;

        double s2 = 0, s4 = 0;
        for (Number x : input) {
            double d = x.doubleValue() - mean;
            s2 += d * d;
            s4 += d * d * d * d;
        }

        double d2 = (double) n * (n + 1) / ((double)(n-1) * (n-2) * (n-3));
        double d3 = 3.0 * Math.pow(n-1, 2) / ((double)(n-2) * (n-3));

        return d2 * (s4 / Math.pow(s2 / sum, 2)) - d3;
    }

    private static <T> Collection<T> windowOf(Deque<T> deque, int size) {
        List<T> result = new ArrayList<>(size);
        Iterator<T> it = deque.descendingIterator();
        int count = 0;
        while (it.hasNext() && count++ < size) result.add(it.next());
        return result;
    }

    private void decayAll(double factor) {
        vlDeviation   = Math.max(0, vlDeviation   * (1 - factor));
        vlEntropy     = Math.max(0, vlEntropy     * (1 - factor));
        vlKurtosis    = Math.max(0, vlKurtosis    * (1 - factor));
        vlBursts      = Math.max(0, vlBursts      * (1 - factor));
        vlFluctuation = Math.max(0, vlFluctuation * (1 - factor));
        vlEqualDelay  = Math.max(0, vlEqualDelay  * (1 - factor));
        vlRepetitive  = Math.max(0, vlRepetitive  * (1 - factor));
    }

    @Override
    public void reset() {
        super.reset();
        vlDeviation = 0;
        vlEntropy = 0;
        vlKurtosis = 0;
        vlBursts = 0;
        vlFluctuation = 0;
        vlEqualDelay = 0;
        vlRepetitive = 0;
        clickEnsembleVL = 0;
    }
}
