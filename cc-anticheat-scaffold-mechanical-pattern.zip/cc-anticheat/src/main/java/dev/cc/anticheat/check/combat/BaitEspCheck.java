/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.combat;

import dev.cc.anticheat.bait.BaitEspManager;
import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.Location;

import java.util.ArrayDeque;

/**
 * cc-anticheat — BaitEspCheck
 *
 * NAPRAWA (przegląd, priorytet 🔴 "Bait tracking correlation"): poprzednia
 * wersja flagowała na podstawie SAMEGO KĄTA ("gracz patrzy w stronę
 * niewidocznego baita poniżej progu X° przez kilka ticków") — to jest
 * przypadkowo osiągalne przez gracza skanującego okolicę bez żadnego ESP,
 * bo nie odróżnia "patrzenia" od "śledzenia RUCHU". Przebudowane na model
 * korelacji kierunku, dokładnie zgodnie z przykładem z przeglądu:
 *
 *   bait przesuwa się w lewo
 *         ↓
 *   gracz obraca kamerę w lewo (rotation delta ZGODNA z kierunkiem baita)
 *         ↓
 *   bait przesuwa się ponownie (inna faza, inny kierunek)
 *         ↓
 *   gracz ponownie kompensuje rotacją w TYM SAMYM kierunku
 *         ↓
 *   powtarza się REACQUISITIONS_REQUIRED razy z rzędu
 *
 * Sygnały zbierane na każdy tick (patrz onTick):
 *   - angle              — kąt między kierunkiem patrzenia a pozycją baita (jak poprzednio, ale teraz TYLKO jeden z sygnałów)
 *   - angle delta         — zmiana kąta między kolejnymi tickami (czy gracz się "domyka" na cel, czy oddala)
 *   - bait movement vector — kierunek fazowego ruchu baita (z BaitEspManager#getBaitMovementDirection)
 *   - player rotation delta — zmiana yaw/pitch gracza między kolejnymi tickami
 *   - rotation → bait correlation — znak (kierunek) rotation delta zgodny ze znakiem wymaganej korekty w stronę baita
 *   - tracking duration    — ile KOLEJNYCH ticków korelacja się utrzymuje w RAMACH JEDNEJ fazy ruchu baita
 *   - reacquisition        — ile RAZY (przez kolejne, różne fazy ruchu baita) gracz na nowo "złapał" korelację
 *     po tym, jak faza się zmieniła — to jest kluczowy sygnał z przykładu:
 *     pojedyncza zbieżność w jednej fazie to może być przypadek, ale
 *     POWTARZAJĄCA SIĘ zbieżność w KOLEJNYCH, niezależnych fazach (bait
 *     zmienia kierunek losowo — patrz BaitEspManager) jest matematycznie
 *     nieprawdopodobna bez faktycznego śledzenia pozycji baita.
 */
public class BaitEspCheck extends Check {

    private static final double FOV_LIMIT_DEGREES = 12.0;
    /** Ile kolejnych ticków w RAMACH JEDNEJ fazy ruchu baita korelacja rotacji musi się utrzymać, żeby faza liczyła się jako "złapana". */
    private static final int TRACKING_DURATION_REQUIRED = 3;
    /** Ile RAZY (przez różne, niezależne fazy) gracz musi ponownie złapać korelację, zanim to przestaje być zbiegiem okoliczności. */
    private static final int REACQUISITIONS_REQUIRED = 4;
    /** Minimalna wielkość rotation delta gracza, żeby w ogóle liczyć korelację kierunku (poniżej tego to szum/bezruch). */
    private static final double MIN_ROTATION_DELTA_DEGREES = 0.15;
    /** Minimalna zgodność kierunku (iloczyn znaków), żeby uznać tick za "korelujący". */
    private static final double MIN_DIRECTION_ALIGNMENT = 0.5;
    /** Jeśli gracz nie widział bait movement vectora przez tyle ticków, resetujemy tracking (timeout, nie tylko zmiana fazy). */
    private static final int MAX_GAP_TICKS = 30;

    private double lastAngle = Double.NaN;
    private float lastYaw, lastPitch;
    private boolean hasLastRotation = false;

    /** Identyfikator bieżącej fazy ruchu baita — wykrywany przez zmianę wektora kierunku (patrz onTick). */
    private double currentPhaseDirX = Double.NaN, currentPhaseDirZ = Double.NaN;
    private int trackingTicksInPhase = 0;
    private boolean phaseAlreadyCountedAsReacquisition = false;
    private int reacquisitionCount = 0;
    private int ticksSinceLastBait = 0;

    /** Historia ostatnich N wyników "czy tick korelował" — do oceny confidence zamiast pojedynczego binarnego progu. */
    private final ArrayDeque<Boolean> recentCorrelationHits = new ArrayDeque<>(20);

    public BaitEspCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "BaitEsp");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.02; // bardzo wolny decay — potwierdzone tracking correlation to poważny dowód, nie powinno szybko "wyparować"
        this.vlDecayMultiplier = 0.99;
        this.flagThreshold = 3.0;
        this.setbackThreshold = Double.MAX_VALUE; // BaitEsp tylko flaguje/alertuje, nigdy nie robi setbacku
        this.requiredBuffer = 1; // reacquisitionCount już wymaga wielokrotnego potwierdzenia — dodatkowy bufor tutaj byłby nadmiarowy
        this.maxBuffer = 10;
    }

    /**
     * Wołane cyklicznie (na każdym pakiecie rotacji/ruchu), gdy bait jest
     * aktywny dla tego gracza. Nie robi nic, jeśli bait nie istnieje albo
     * wciąż jest w widocznej fazie flash (patrz
     * BaitEspManager#getReactableLocation — zwraca null w tych przypadkach).
     */
    public void onTick(BaitEspManager baitManager) {
        Location baitLoc = baitManager.getReactableLocation(data.player);
        double[] baitDirection = baitManager.getBaitMovementDirection(data.player);

        if (baitLoc == null || baitDirection == null) {
            ticksSinceLastBait++;
            if (ticksSinceLastBait > MAX_GAP_TICKS) {
                resetTrackingState();
            }
            return;
        }
        ticksSinceLastBait = 0;

        // ── Sygnał: angle + angle delta ──────────────────────────────────────
        double angle = angleToLocation(baitLoc);
        double angleDelta = Double.isNaN(lastAngle) ? 0 : angle - lastAngle;
        lastAngle = angle;

        // ── Sygnał: player rotation delta ────────────────────────────────────
        float yawDelta = 0, pitchDelta = 0;
        if (hasLastRotation) {
            yawDelta = normalizeAngle(data.yaw - lastYaw);
            pitchDelta = data.pitch - lastPitch;
        }
        lastYaw = data.yaw;
        lastPitch = data.pitch;
        hasLastRotation = true;

        // ── Wykrycie zmiany FAZY ruchu baita (nowy, niezależny kierunek) ─────
        boolean isNewPhase = Double.isNaN(currentPhaseDirX)
            || dot(currentPhaseDirX, currentPhaseDirZ, baitDirection[0], baitDirection[1]) < 0.3;
        if (isNewPhase) {
            // Faza się zmieniła (albo to pierwsza próbka) — jeśli poprzednia
            // faza faktycznie osiągnęła TRACKING_DURATION_REQUIRED i jeszcze
            // nie została policzona jako reacquisition, liczymy ją teraz —
            // czyli reacquisition jest liczone PRZY ZMIANIE fazy, na podstawie
            // tego, co się działo w fazie, która właśnie się skończyła.
            if (trackingTicksInPhase >= TRACKING_DURATION_REQUIRED && !phaseAlreadyCountedAsReacquisition) {
                reacquisitionCount++;
            }
            currentPhaseDirX = baitDirection[0];
            currentPhaseDirZ = baitDirection[1];
            trackingTicksInPhase = 0;
            phaseAlreadyCountedAsReacquisition = false;
        }

        // ── Sygnał: rotation → bait correlation ──────────────────────────────
        // Wektor "korekty", jakiej gracz MUSIAŁBY dokonać, żeby zmniejszyć swój
        // aktualny błąd celowania w stronę baita — porównujemy jego ZNAK
        // (kierunek) z faktyczną rotation delta gracza, nie samą wielkość.
        boolean correlatesThisTick = false;
        double rotationMagnitude = Math.sqrt(yawDelta * yawDelta + pitchDelta * pitchDelta);
        if (hasLastRotation && rotationMagnitude >= MIN_ROTATION_DELTA_DEGREES && angle <= FOV_LIMIT_DEGREES) {
            double expectedYawCorrectionSign = Math.signum(requiredYawCorrection(baitLoc));
            double actualYawSign = Math.signum(yawDelta);
            double alignment = expectedYawCorrectionSign * actualYawSign; // +1 zgodne, -1 przeciwne, 0 brak ruchu w tej osi

            if (alignment >= MIN_DIRECTION_ALIGNMENT && angleDelta <= 0.5) {
                // Rotacja idzie w kierunku ZGODNYM z korektą potrzebną do
                // domknięcia na bait ORAZ kąt do baita się nie powiększa
                // (gracz faktycznie się zbliża, nie przypadkiem miga w tę stronę)
                // ORAZ gracz jest już w rozsądnym FOV baita — poza tym zakresem
                // "kierunek korekty" jest w praktyce prawie losowy (przy bardzo
                // dużym błędzie kątowym najmniejszy ruch myszy zgadza się ze
                // znakiem korekty z ~50% szansą, co psułoby wiarygodność sygnału).
                correlatesThisTick = true;
            }
        }

        recentCorrelationHits.addLast(correlatesThisTick);
        while (recentCorrelationHits.size() > 20) recentCorrelationHits.pollFirst();

        if (correlatesThisTick) {
            trackingTicksInPhase++;
            if (trackingTicksInPhase >= TRACKING_DURATION_REQUIRED && !phaseAlreadyCountedAsReacquisition) {
                reacquisitionCount++;
                phaseAlreadyCountedAsReacquisition = true;
            }
        }

        // ── Confidence złożone z REACQUISITIONS + hitRatio, nie z pojedynczego progu ────
        if (reacquisitionCount >= REACQUISITIONS_REQUIRED) {
            double hitRatio = correlationHitRatio();
            // Severity skalowana przez hitRatio (jak spójna jest korelacja w
            // całym oknie, nie tylko w progowym momencie reacquisition) —
            // to jest "confidence" zamiast stałej kary: te same 4
            // reacquisitions z hitRatio 0.9 są mocniejszym dowodem niż z
            // hitRatio 0.4 (dużo szumu między trafieniami), więc kara rośnie
            // proporcjonalnie zamiast być binarnym "próg osiągnięty = stała kara".
            double severity = 1.5 + hitRatio * 2.5;
            buffer(severity, String.format(
                "reacquisitions:%d angle:%.2f angleDelta:%.3f hitRatio:%.2f trackingTicks:%d",
                reacquisitionCount, angle, angleDelta, hitRatio, trackingTicksInPhase));
        }
    }

    private double correlationHitRatio() {
        if (recentCorrelationHits.isEmpty()) return 0.0;
        long hits = recentCorrelationHits.stream().filter(Boolean::booleanValue).count();
        return (double) hits / recentCorrelationHits.size();
    }

    /** Znak i przybliżona wielkość korekty yaw potrzebnej, by dokładniej celować w baita — dodatnia = trzeba obrócić w prawo. */
    private double requiredYawCorrection(Location target) {
        double dx = target.getX() - data.x;
        double dz = target.getZ() - data.z;
        double targetYaw = Math.toDegrees(Math.atan2(-dx, dz));
        return normalizeAngle((float) (targetYaw - data.yaw));
    }

    private double angleToLocation(Location target) {
        double dx = target.getX() - data.x;
        double dy = target.getY() - (data.y + 1.62);
        double dz = target.getZ() - data.z;

        double targetYaw = Math.toDegrees(Math.atan2(-dx, dz));
        double targetPitch = Math.toDegrees(-Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        double dyaw = Math.abs(normalizeAngle((float) (data.yaw - targetYaw)));
        double dpitch = Math.abs(data.pitch - targetPitch);
        return Math.sqrt(dyaw * dyaw + dpitch * dpitch);
    }

    private static double dot(double x1, double z1, double x2, double z2) {
        return x1 * x2 + z1 * z2;
    }

    private float normalizeAngle(float angle) {
        while (angle > 180) angle -= 360;
        while (angle < -180) angle += 360;
        return angle;
    }

    private void resetTrackingState() {
        lastAngle = Double.NaN;
        hasLastRotation = false;
        currentPhaseDirX = Double.NaN;
        currentPhaseDirZ = Double.NaN;
        trackingTicksInPhase = 0;
        phaseAlreadyCountedAsReacquisition = false;
        reacquisitionCount = 0;
        recentCorrelationHits.clear();
    }

    @Override
    public void reset() {
        super.reset();
        resetTrackingState();
        ticksSinceLastBait = 0;
    }
}
