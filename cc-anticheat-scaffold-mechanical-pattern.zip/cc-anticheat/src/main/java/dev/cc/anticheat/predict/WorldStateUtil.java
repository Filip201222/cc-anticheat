/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.predict;

import dev.cc.anticheat.data.MovementData;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;

import java.util.HashSet;
import java.util.Set;

/**
 * cc-anticheat — WorldStateUtil
 *
 * Wypełnia pola środowiskowe MovementData na podstawie bloków przecinających
 * bounding box gracza. Scentralizowane tutaj, żeby każdy check odczytujący
 * "czy gracz jest w wodzie / na lodzie / na pajęczynie" korzystał z tej samej,
 * spójnej definicji zamiast duplikować logikę.
 */
public final class WorldStateUtil {

    private static final Set<Material> CLIMBABLE = new HashSet<>();
    private static final Set<Material> ICE_TYPES = new HashSet<>();

    static {
        CLIMBABLE.add(Material.LADDER);
        CLIMBABLE.add(Material.VINE);
        CLIMBABLE.add(Material.SCAFFOLDING);
        CLIMBABLE.add(Material.WEEPING_VINES);
        CLIMBABLE.add(Material.WEEPING_VINES_PLANT);
        CLIMBABLE.add(Material.TWISTING_VINES);
        CLIMBABLE.add(Material.TWISTING_VINES_PLANT);
        CLIMBABLE.add(Material.CAVE_VINES);
        CLIMBABLE.add(Material.CAVE_VINES_PLANT);

        ICE_TYPES.add(Material.ICE);
        ICE_TYPES.add(Material.PACKED_ICE);
        ICE_TYPES.add(Material.BLUE_ICE);
        ICE_TYPES.add(Material.FROSTED_ICE);
    }

    private WorldStateUtil() {}

    /**
     * Wypełnia pola środowiskowe (woda/lawa/sieć/lód/slime/tarcie/kolizje) na
     * podanym MovementData na podstawie bounding boxa gracza w danym momencie.
     */
    public static void populate(Player player, MovementData movement, double height) {
        World world = player.getWorld();
        double x = movement.x, y = movement.y, z = movement.z;

        BoundingBox box = CollisionUtil.playerBoundingBox(x, y, z, height);

        int minX = (int) Math.floor(box.getMinX());
        int maxX = (int) Math.floor(box.getMaxX());
        int minY = (int) Math.floor(box.getMinY());
        int maxY = (int) Math.floor(box.getMaxY());
        int minZ = (int) Math.floor(box.getMinZ());
        int maxZ = (int) Math.floor(box.getMaxZ());

        boolean inWater = false, inLava = false, inWeb = false, onClimbable = false;
        boolean inBubble = false;

        for (int bx = minX; bx <= maxX; bx++) {
            for (int by = minY; by <= maxY; by++) {
                for (int bz = minZ; bz <= maxZ; bz++) {
                    Block block = world.getBlockAt(bx, by, bz);
                    Material type = block.getType();

                    if (type == Material.WATER || type == Material.BUBBLE_COLUMN) {
                        inWater = true;
                        if (type == Material.BUBBLE_COLUMN) inBubble = true;
                    } else if (isWaterlogged(block)) {
                        inWater = true;
                    } else if (type == Material.LAVA) {
                        inLava = true;
                    } else if (type == Material.COBWEB) {
                        inWeb = true;
                    } else if (CLIMBABLE.contains(type)) {
                        onClimbable = true;
                    }
                }
            }
        }

        movement.inWater = inWater;
        movement.inLava = inLava;
        movement.inLiquid = inWater || inLava;
        movement.inWeb = inWeb;
        movement.onClimbable = onClimbable;
        movement.inBubbleColumn = inBubble;

        // Blok pod graczem — tarcie oraz typ (lód/slime/honey/soul sand). Sprawdzamy
        // konkretnie ten jeden blok (nie cały bounding box) dla spójności ze
        // wszystkimi innymi polami "on<Block>" — gracz "stoi NA" tylko jednym bloku naraz.
        Block below = world.getBlockAt((int) Math.floor(x), (int) Math.floor(y - 0.05), (int) Math.floor(z));
        Material belowType = below.getType();
        movement.onIce = ICE_TYPES.contains(belowType);
        movement.onSlimeBlock = belowType == Material.SLIME_BLOCK;
        movement.onHoneyBlock = belowType == Material.HONEY_BLOCK;
        movement.onSoulSand = belowType == Material.SOUL_SAND || belowType == Material.SOUL_SOIL;
        movement.blockFriction = PlayerPhysicsEngine.frictionForBlock(belowType);

        movement.gliding = player.isGliding();
        movement.swimming = player.isSwimming();
        movement.sneaking = player.isSneaking();
        movement.sprinting = player.isSprinting();
        movement.flying = player.isFlying();
        movement.inVehicle = player.isInsideVehicle();

        movement.touchingPistonOrMovingBlock = touchesMovingBlock(world, box);
    }

    private static boolean isWaterlogged(Block block) {
        BlockData data = block.getBlockData();
        if (data instanceof org.bukkit.block.data.Waterlogged wl) {
            return wl.isWaterlogged();
        }
        return false;
    }

    /**
     * Sprawdza, czy w promieniu bounding boxa gracza (+1 margines) znajduje się
     * piston, ruchoma platforma pistonu (moving_piston) — potrzebne do
     * wykluczenia false-positive w Flight/Phase check podczas jazdy na pistonie.
     */
    private static boolean touchesMovingBlock(World world, BoundingBox box) {
        int minX = (int) Math.floor(box.getMinX()) - 1;
        int maxX = (int) Math.floor(box.getMaxX()) + 1;
        int minY = (int) Math.floor(box.getMinY()) - 1;
        int maxY = (int) Math.floor(box.getMaxY()) + 1;
        int minZ = (int) Math.floor(box.getMinZ()) - 1;
        int maxZ = (int) Math.floor(box.getMaxZ()) + 1;

        for (int bx = minX; bx <= maxX; bx++) {
            for (int by = minY; by <= maxY; by++) {
                for (int bz = minZ; bz <= maxZ; bz++) {
                    Material type = world.getBlockAt(bx, by, bz).getType();
                    if (type == Material.PISTON_HEAD || type == Material.MOVING_PISTON
                        || type == Material.PISTON || type == Material.STICKY_PISTON) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
