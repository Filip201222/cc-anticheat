/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.predict;

/**
 * cc-anticheat — MovementEnvelope
 *
 * Pełny "expected state" dla jednego ticka ruchu, zastępujący model
 * "pojedyncza przewidywana wartość + sztywny próg" bogatszą reprezentacją:
 *
 *   expectedVelocity   — najbardziej prawdopodobny wektor ruchu (środek envelope)
 *   legalMin/legalMax  — dolna/górna granica fizycznie możliwego ruchu na
 *                        każdej osi w tym ticku, uwzględniająca WSZYSTKIE
 *                        legalne źródła wariancji (input gracza nieznany
 *                        serwerowi, jitter sieciowy, zaokrąglenia protokołu)
 *   deviation          — o ile faktyczny ruch gracza wykracza POZA envelope
 *                        (0 jeśli mieści się w granicach — nie karzemy za
 *                        samo bycie blisko granicy)
 *   confidence         — 0.0-1.0, jak bardzo serwer jest w stanie pewnie
 *                        przewidzieć ten tick. Niska confidence (np. tuż po
 *                        zmianie środowiska, przy nieznanym input momentum)
 *                        oznacza, że checki powinny traktować deviation
 *                        z większym marginesem zamiast karać za to, że
 *                        predykcja sama w sobie jest niepewna — patrz
 *                        punkt "sytuacje, w których serwer nie może
 *                        dokładnie przewidzieć klienta".
 *
 * Ta klasa NIE zastępuje PlayerPhysicsEngine.Prediction (używanego przez
 * Speed/NoSlow/Flight w niezmienionej formie) — jest zbudowana NA NIM,
 * jako bogatszy widok tego samego obliczenia, do użytku przez checki, które
 * potrzebują pełnego zakresu (min/max) zamiast pojedynczej wartości offsetu.
 */
public final class MovementEnvelope {

    public final double expectedVelocityX, expectedVelocityY, expectedVelocityZ;

    public final double legalMinX, legalMaxX;
    public final double legalMinY, legalMaxY;
    public final double legalMinZ, legalMaxZ;

    /** Ile faktyczny ruch gracza wykracza POZA envelope na każdej osi (0 = w granicach). */
    public double deviationX, deviationY, deviationZ;

    /**
     * 0.0-1.0 — jak pewna jest ta predykcja. Obniżana przez PlayerPhysicsEngine
     * w sytuacjach z natury niepewnych dla serwera (patrz
     * PlayerPhysicsEngine#computeEnvelope): pierwszy tick po zmianie
     * środowiska (grunt/ciecz/climbable), pierwszy tick po ticku z zerową
     * historią, oraz sytuacje gdzie input gracza (nieznany serwerowi) ma
     * duży wpływ na wynik (np. moment odbicia od ziemi, gdzie kierunek
     * strafe'a zmienia wynikowy wektor bardziej niż w locie ustalonym).
     */
    public final double confidence;

    /** Krótki, czytelny powód obniżonej confidence — do logów/alertów debugowych. */
    public final String confidenceNote;

    public MovementEnvelope(double evx, double evy, double evz,
                             double minX, double maxX,
                             double minY, double maxY,
                             double minZ, double maxZ,
                             double confidence, String confidenceNote) {
        this.expectedVelocityX = evx;
        this.expectedVelocityY = evy;
        this.expectedVelocityZ = evz;
        this.legalMinX = minX;
        this.legalMaxX = maxX;
        this.legalMinY = minY;
        this.legalMaxY = maxY;
        this.legalMinZ = minZ;
        this.legalMaxZ = maxZ;
        this.confidence = confidence;
        this.confidenceNote = confidenceNote;
    }

    /** Oblicza i zapisuje deviation dla faktycznego ruchu (dx, dy, dz) — wołane raz przez PacketListener po zbudowaniu envelope. */
    public void computeDeviation(double actualDx, double actualDy, double actualDz) {
        deviationX = outsideRange(actualDx, legalMinX, legalMaxX);
        deviationY = outsideRange(actualDy, legalMinY, legalMaxY);
        deviationZ = outsideRange(actualDz, legalMinZ, legalMaxZ);
    }

    /** Pozioma deviation łączna (Pitagoras z X/Z) — wygodne dla checków patrzących tylko na płaszczyznę pozioma. */
    public double horizontalDeviation() {
        return Math.sqrt(deviationX * deviationX + deviationZ * deviationZ);
    }

    /**
     * Deviation przeskalowana odwrotnie do confidence — ten sam surowy offset
     * powinien ważyć MNIEJ, gdy confidence predykcji było niskie (bo część
     * odchylenia mogła wynikać z samej niepewności modelu, nie z cheatowania).
     * Checki powinny mnożyć surową severity przez ten współczynnik zamiast
     * całkowicie ignorować ticki o niskiej confidence (co dawałoby lukę do
     * nadużycia — spamowanie zmian stanu, żeby stale obniżać confidence).
     */
    public double confidenceWeightedSeverity(double rawSeverity) {
        return rawSeverity * confidence;
    }

    private static double outsideRange(double actual, double min, double max) {
        if (actual < min) return min - actual;
        if (actual > max) return actual - max;
        return 0.0;
    }
}
