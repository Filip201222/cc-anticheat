/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.movement.physics;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Player;
import org.bukkit.entity.Vehicle;

/**
 * cc-anticheat — BoatFlyCheck
 *
 * Wykrywa BoatFly — utrzymywanie się lub wznoszenie łodzią w powietrzu wbrew
 * fizyce vanilla. Przebudowane na system Check (VL/buffer/decay wspólny dla
 * całego projektu) z zachowaniem trzech sub-checków z oryginalnej koncepcji.
 *
 * Sub-checki:
 *   A. Vertical Hold — łódź w powietrzu przestaje opadać na dłużej niż kilka ticków
 *   B. Ascent        — łódź wznosi się w powietrzu bez fizycznego powodu
 *   C. Gravity        — realna deltaY łodzi odbiega od przewidywanej krzywej grawitacji
 */
public class BoatFlyCheck extends Check {

    private static final int HOVER_TICK_THRESHOLD = 8;
    private static final double BOAT_GRAVITY = 0.04;
    private static final double BOAT_GRAVITY_DRAG = 0.99;
    private static final double MAX_LEGIT_ASCENT = 0.5625; // vanilla step height
    private static final int STABILIZE_TICKS = 40;

    private boolean lastInBoat = false;
    private int boatTicks = 0;
    private int airHoverTicks = 0;
    private double predictedVelY = 0;

    public BoatFlyCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "BoatFly");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.08;
        this.vlDecayMultiplier = 0.96;
        this.flagThreshold = 6.0;
        this.setbackThreshold = Double.MAX_VALUE; // BoatFly nie robi setbacku — tylko flaguje
        this.requiredBuffer = 3;
        this.maxBuffer = 20;
    }

    public void onMovement(MovementData current) {
        Player player = data.player;

        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (data.awaitingTeleportConfirm) return;

        boolean inBoat = isInBoat(player);

        if (!inBoat) {
            if (lastInBoat) resetState();
            lastInBoat = false;
            reward();
            return;
        }

        if (!lastInBoat) {
            resetState();
            lastInBoat = true;
            return;
        }

        if (tickExemption()) return;

        lastInBoat = true;
        boatTicks++;

        if (boatTicks < STABILIZE_TICKS) {
            return;
        }

        double deltaY = current.deltaY;

        if (isInOrOnWater(player, current.y)) {
            airHoverTicks = 0;
            predictedVelY = 0;
            reward();
            return;
        }

        boolean groundBelow = hasBlockBelow(player, current.y);

        if (groundBelow && deltaY >= 0) {
            airHoverTicks = 0;
            predictedVelY = 0;
            reward();
            return;
        }

        boolean flaggedThisTick = false;

        // ── A. Vertical Hold ─────────────────────────────────────────────
        if (!groundBelow && Math.abs(deltaY) < 0.001) {
            airHoverTicks++;
            if (airHoverTicks > HOVER_TICK_THRESHOLD) {
                buffer(2.0, String.format("sub:VerticalHold hoverTicks:%d deltaY:%.5f", airHoverTicks, deltaY));
                flaggedThisTick = true;
            }
        } else {
            airHoverTicks = Math.max(0, airHoverTicks - 1);
        }

        // ── B. Ascent ────────────────────────────────────────────────────
        if (!groundBelow && deltaY > MAX_LEGIT_ASCENT) {
            buffer(3.0, String.format("sub:Ascent deltaY:%.4f maxLegit:%.4f", deltaY, MAX_LEGIT_ASCENT));
            flaggedThisTick = true;
        }

        // ── C. Gravity prediction ────────────────────────────────────────
        if (!groundBelow) {
            double expectedVelY = (predictedVelY - BOAT_GRAVITY) * BOAT_GRAVITY_DRAG;
            double offset = deltaY - expectedVelY;

            if (offset > 0.05 && deltaY > 0) {
                buffer(Math.min(offset * 8, 3.0), String.format(
                    "sub:Gravity actual:%.4f expected:%.4f offset:%.4f", deltaY, expectedVelY, offset));
                flaggedThisTick = true;
            }
            predictedVelY = deltaY;
        } else {
            predictedVelY = deltaY;
        }

        if (!flaggedThisTick) {
            reward();
        }
    }

    // ── Pomocniki ─────────────────────────────────────────────────────────────

    private static boolean isInBoat(Player player) {
        Vehicle vehicle = player.getVehicle() instanceof Vehicle ? (Vehicle) player.getVehicle() : null;
        return vehicle instanceof Boat;
    }

    @SuppressWarnings("deprecation")
    private static boolean isInOrOnWater(Player player, double y) {
        Location loc = player.getLocation();
        Block atFeet = loc.getBlock();
        if (isWater(atFeet.getType())) return true;

        Block below = loc.getWorld().getBlockAt(
            (int) Math.floor(loc.getX()),
            (int) Math.floor(y - 0.1),
            (int) Math.floor(loc.getZ())
        );
        return isWater(below.getType());
    }

    private static boolean isWater(Material m) {
        return m == Material.WATER || m.name().contains("WATER");
    }

    private static boolean hasBlockBelow(Player player, double y) {
        Location loc = player.getLocation();
        for (double dy = 0.1; dy <= 1.2; dy += 0.3) {
            Block b = loc.getWorld().getBlockAt(
                (int) Math.floor(loc.getX()),
                (int) Math.floor(y - dy),
                (int) Math.floor(loc.getZ())
            );
            if (b.getType().isSolid()) return true;
        }
        return false;
    }

    private void resetState() {
        boatTicks = 0;
        airHoverTicks = 0;
        predictedVelY = 0;
    }

    @Override
    public void reset() {
        super.reset();
        resetState();
        lastInBoat = false;
    }
}
