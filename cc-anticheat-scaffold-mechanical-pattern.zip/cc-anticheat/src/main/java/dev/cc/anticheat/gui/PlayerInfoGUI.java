/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.gui;

import dev.cc.anticheat.CCAnticheat;
import dev.cc.anticheat.data.AlertHistory;
import org.bukkit.BanEntry;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * cc-anticheat — PlayerInfoGUI
 *
 * "/anticheat alertgui <player>" (and clicking a name inside a chat alert)
 * opens this inventory: a player head with all AC alerts / kicks / ban
 * status in the lore, plus a green-dye button that teleports the viewer
 * into spectator mode on that player (same as /anticheat spectate).
 */
public class PlayerInfoGUI implements InventoryHolder {

    public static final int SIZE          = 27;
    public static final int HEAD_SLOT     = 13;
    public static final int SPECTATE_SLOT = 22;

    private final Inventory inventory;
    private final String targetName;

    public PlayerInfoGUI(CCAnticheat plugin, String targetName) {
        this.targetName = targetName;
        this.inventory = Bukkit.createInventory(this, SIZE,
                ChatColor.translateAlternateColorCodes('&', "&d&lAC &8• &f" + targetName));
        build(plugin);
    }

    public String getTargetName() {
        return targetName;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    private void build(CCAnticheat plugin) {
        AlertHistory history = plugin.getAlertHistory();
        List<AlertHistory.Entry> entries = history.get(targetName);

        int alertCount = 0, kickCount = 0;
        for (AlertHistory.Entry e : entries) {
            if (e.type == AlertHistory.Entry.Type.ALERT) alertCount++;
            else if (e.type == AlertHistory.Entry.Type.KICK) kickCount++;
        }

        // ── Live ban lookup (always accurate, regardless of who issued the ban) ──
        boolean banned = false;
        String banReason = "Brak powodu";
        String banExpiry = "nigdy (permanentny)";
        try {
            BanEntry banEntry = Bukkit.getBanList(BanList.Type.NAME).getBanEntry(targetName);
            if (banEntry != null) {
                banned = true;
                if (banEntry.getReason() != null) banReason = banEntry.getReason();
                if (banEntry.getExpiration() != null) {
                    banExpiry = new SimpleDateFormat("dd.MM.yyyy HH:mm").format(banEntry.getExpiration());
                }
            }
        } catch (Exception ignored) {
            // Ban list lookups can throw on some server forks; fail open (show "no ban info").
        }

        inventory.setItem(HEAD_SLOT, buildHead(targetName, alertCount, kickCount, banned, banReason, banExpiry, entries));
        inventory.setItem(SPECTATE_SLOT, buildSpectateButton());
    }

    private ItemStack buildHead(String targetName, int alertCount, int kickCount,
                                 boolean banned, String banReason, String banExpiry,
                                 List<AlertHistory.Entry> entries) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        if (meta == null) return head;

        meta.setOwningPlayer(Bukkit.getOfflinePlayer(targetName));
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&d&l" + targetName));

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.DARK_GRAY + "――――――――――――――――");
        lore.add(ChatColor.GRAY + "Alerty: " + ChatColor.WHITE + alertCount);
        lore.add(ChatColor.GRAY + "Kicki od AC: " + ChatColor.WHITE + kickCount);
        lore.add(ChatColor.GRAY + "Ban: " + (banned ? ChatColor.RED + "TAK" : ChatColor.GREEN + "NIE"));
        if (banned) {
            lore.add(ChatColor.GRAY + " Powód: " + ChatColor.WHITE + banReason);
            lore.add(ChatColor.GRAY + " Wygasa: " + ChatColor.WHITE + banExpiry);
        }
        lore.add(ChatColor.DARK_GRAY + "――――――――――――――――");
        lore.add(ChatColor.YELLOW + "Ostatnie wpisy:");

        if (entries.isEmpty()) {
            lore.add(ChatColor.GRAY + "Brak historii.");
        } else {
            SimpleDateFormat fmt = new SimpleDateFormat("HH:mm:ss");
            int shown = 0;
            for (AlertHistory.Entry e : entries) {
                if (shown >= 9) {
                    lore.add(ChatColor.DARK_GRAY + "... i " + (entries.size() - shown) + " więcej");
                    break;
                }
                String tag;
                switch (e.type) {
                    case KICK: tag = ChatColor.RED + "✖ "; break;
                    case BAN:  tag = ChatColor.DARK_RED + "⛔ "; break;
                    default:   tag = ChatColor.YELLOW + "! "; break;
                }
                String line = tag + ChatColor.GRAY + fmt.format(new Date(e.timestamp)) + " "
                        + ChatColor.WHITE + e.check
                        + (e.detail.isEmpty() ? "" : ChatColor.DARK_GRAY + " (" + e.detail + ")");
                lore.add(line);
                shown++;
            }
        }

        meta.setLore(lore);
        head.setItemMeta(meta);
        return head;
    }

    private ItemStack buildSpectateButton() {
        ItemStack spectate = new ItemStack(Material.LIME_DYE);
        ItemMeta meta = spectate.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&a&lObserwuj (Spectator)"));
            meta.setLore(List.of(
                    ChatColor.GRAY + "Kliknij, aby przejść w tryb",
                    ChatColor.GRAY + "obserwatora i teleportować się",
                    ChatColor.GRAY + "do " + ChatColor.WHITE + targetName,
                    "",
                    ChatColor.DARK_GRAY + "Kliknij ponownie, aby wrócić."
            ));
            spectate.setItemMeta(meta);
        }
        return spectate;
    }
}
