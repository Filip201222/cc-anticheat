/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.manager;

import dev.cc.anticheat.CCAnticheat;
import dev.cc.anticheat.data.PlayerData;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

/**
 * cc-anticheat — BukkitListener
 *
 * Handles Bukkit-level events that don't require packet interception.
 */
public class BukkitListener implements Listener {

    private final CCAnticheat  plugin;
    private final CheckManager cm;

    public BukkitListener(CCAnticheat plugin, CheckManager cm) {
        this.plugin = plugin;
        this.cm     = cm;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        cm.onJoin(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        cm.onQuit(event.getPlayer());
        // Clean up any spectate/bait state so nothing leaks across sessions.
        plugin.getSpectateManager().forget(event.getPlayer());
        plugin.getBaitEspManager().stop(event.getPlayer());
        dev.cc.anticheat.predict.EntityHistoryTracker.forget(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent event) {
        // Re-init data on respawn (clears velocity state etc.)
        cm.onQuit(event.getPlayer());
        cm.onJoin(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onTeleport(PlayerTeleportEvent event) {
        // Zwolnij WSZYSTKIE checki ruchu na 20 ticków po teleporcie — nagła
        // zmiana pozycji jest z definicji "nielegalnym" ruchem z punktu widzenia
        // predykcji fizyki, więc bez tego każdy teleport (portal, /tp, plugin,
        // enderperła, itp.) generowałby fałszywe alarmy Flight/Speed/Phase.
        Player player = event.getPlayer();
        PlayerData data = cm.getData(player);
        if (data == null) return;
        data.awaitingTeleportConfirm = false;
        data.exemptAll(20);
    }

    /**
     * Gracz użył totema (przeżył śmierć dzięki totemowi).
     * EntityResurrectEvent odpala się dokładnie w momencie użycia totema.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTotemUse(EntityResurrectEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        Player player = (Player) event.getEntity();
        PlayerData data = cm.getData(player);
        if (data == null) return;
        cm.onTotemUse(data);
    }

    /**
     * Gracz kliknął w ekwipunku — potencjalny swap totema.
     * Sprawdzamy tylko gdy mamy aktywne oczekiwanie na swap (flaga w AutoTotemCheck).
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();
        PlayerData data = cm.getData(player);
        if (data == null) return;
        // Małe opóźnienie — czekamy 1 tick żeby slot faktycznie się zaktualizował
        player.getServer().getScheduler().runTask(plugin, () -> cm.onInventoryAction(data));
    }

    /**
     * Hook into damage events to capture knockback vectors BEFORE they're sent.
     * This starts the velocity sandwich for AntiKB detection. Also feeds
     * CriticalsCheck (attacker side) and AutoArmorCheck (victim side), oraz
     * AntiFireballCheck gdy damager to Fireball odbity atakiem gracza.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        // ── Victim-side: AutoArmor reaction-time trigger ────────────────────
        if (event.getEntity() instanceof Player) {
            Player victim = (Player) event.getEntity();
            PlayerData victimData = cm.getData(victim);
            if (victimData != null) {
                cm.onDamageTaken(victimData);
            }
        }

        // ── Attacker-side: Criticals ─────────────────────────────────────────
        if (event.getDamager() instanceof Player) {
            Player attacker = (Player) event.getDamager();
            PlayerData attackerData = cm.getData(attacker);
            if (attackerData != null && event.isCritical()) {
                cm.onCriticalHit(attackerData);
            }
        }

        // ── Attacker-side: AntiFireball (gracz "odbił" fireballa atakiem) ────
        if (event.getEntity() instanceof Fireball && event.getDamager() instanceof Player) {
            Player deflector = (Player) event.getDamager();
            PlayerData deflectorData = cm.getData(deflector);
            Fireball fireball = (Fireball) event.getEntity();
            if (deflectorData != null) {
                Long enteredRangeMs = deflectorData.fireballsInRange.remove(fireball.getEntityId());
                if (enteredRangeMs != null) {
                    cm.onFireballDeflect(deflectorData, fireball, enteredRangeMs);
                }
            }
        }

        // ── Victim-side: knockback vector Bukkit would apply (simplified model) ──
        if (!(event.getEntity() instanceof Player)) return;
        Player victim = (Player) event.getEntity();

        PlayerData data = cm.getData(victim);
        if (data == null) return;

        Entity damager = event.getDamager();
        // Źródło impulsu determinuje skąd bierzemy "attackerEntityId" i jaki
        // KnockbackSource przekazujemy — pocisk (strzała/trójząb) ma swój
        // własny entity ID inny niż strzelec, a mechanika aplikacji KB różni
        // się od zwykłego melee (patrz VelocityCheck#ratioRangeFor).
        PlayerData.KnockbackSource source;
        Entity kbOriginEntity = damager;
        if (damager instanceof Projectile) {
            source = PlayerData.KnockbackSource.PROJECTILE;
            Object shooter = ((Projectile) damager).getShooter();
            if (shooter instanceof Entity) {
                kbOriginEntity = (Entity) shooter;
            }
        } else {
            source = PlayerData.KnockbackSource.MELEE;
        }

        double dx = victim.getLocation().getX() - kbOriginEntity.getLocation().getX();
        double dz = victim.getLocation().getZ() - kbOriginEntity.getLocation().getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        if (dist < 0.01) return; // same position — no horizontal KB

        double kbStrength = 0.4; // vanilla default
        Vector kb = new Vector(
            (-dx / dist) * kbStrength,
             0.36,  // vanilla Y knockback
            (-dz / dist) * kbStrength
        );

        cm.onKnockbackSent(data, damager.getEntityId(), kb, source);
    }

    /** Gracz otrzymał obrażenia z dowolnego źródła — trigger AutoArmor. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamageGeneric(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        Player player = (Player) event.getEntity();
        PlayerData data = cm.getData(player);
        if (data == null) return;
        cm.onDamageTaken(data);
    }

    /** Gracz wystrzelił z łuku/kuszy — weryfikacja siły strzału (FastBow). */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onShootBow(EntityShootBowEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        Player player = (Player) event.getEntity();
        PlayerData data = cm.getData(player);
        if (data == null) return;
        cm.onBowShoot(data, event.getForce());
    }

    /** Gracz zaczyna naciągać łuk/kuszę (RIGHT_CLICK z łukiem/kuszą w ręce). */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        PlayerData data = cm.getData(player);
        if (data == null) return;

        if (event.getAction().name().startsWith("RIGHT_CLICK")) {
            ItemStack item = event.getHand() == EquipmentSlot.OFF_HAND
                ? player.getInventory().getItemInOffHand()
                : player.getInventory().getItemInMainHand();
            if (item != null && isBowOrCrossbow(item.getType().name())) {
                cm.onBowRaise(data);
            }
        }
    }

    private boolean isBowOrCrossbow(String materialName) {
        return materialName.equals("BOW") || materialName.equals("CROSSBOW");
    }

    /**
     * Blok został złamany — weryfikujemy zarówno FastBreak (czas łamania
     * wobec fizyki vanilla) jak i Nuke (rate/spread/no-look). ignoreCancelled
     * jest celowo pominięte tutaj (domyślnie false) — chcemy widzieć próbę
     * złamania nawet jeśli inny plugin już ją anulował, żeby dane statystyczne
     * (rate/spread) pozostały spójne; ewentualne anulowanie robimy sami przez
     * event.setCancelled() na podstawie wyniku checka.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        PlayerData data = cm.getData(player);
        if (data == null) return;

        boolean cancel = cm.onBlockBreak(data, event.getBlock().getLocation());
        if (cancel) {
            event.setCancelled(true);
        }
    }

    /**
     * Pocisk (fireball Ghasta) trafił w cel. Sprzątamy jego wpis ze śledzenia
     * "w zasięgu" niezależnie od wyniku (trafienie gracza, bloku, lub despawn) —
     * AntiFireballCheck.onFireballDeflect() jest wołane osobno z onDamage (gdy
     * damager to Fireball i entity to Player, patrz ścieżka KB powyżej), więc
     * tutaj czyścimy tylko stan, żeby fireballsInRange nie rosło w nieskończoność
     * dla pocisków, które nigdy nie zostały odbite.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onProjectileHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Fireball)) return;
        int fireballId = event.getEntity().getEntityId();

        if (event.getHitEntity() instanceof Player) {
            Player player = (Player) event.getHitEntity();
            PlayerData data = cm.getData(player);
            if (data != null) {
                data.fireballsInRange.remove(fireballId);
            }
        }
    }
}
