/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check;

import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.violation.ViolationProcessor;

/**
 * cc-anticheat — Check
 *
 * Wspólna baza dla wszystkich checków ruchu i walki.
 *
 * Każdy check w tym anticheacie posiada:
 *   - buffer      liczba kolejnych "podejrzanych" ticków wymaganych zanim VL faktycznie
 *                 zacznie rosnąć (odporność na pojedynczy zły tick spowodowany lagiem)
 *   - VL          poziom naruszenia, akumulowany w czasie
 *   - decay       naturalny spadek VL na czystych tickach (gracz "odpokutowuje" VL)
 *   - threshold   próg VL, po którym check faktycznie zgłasza flagę do ViolationProcessor
 *   - setback     opcjonalny próg dla cofnięcia gracza do bezpiecznej pozycji
 *   - exemption   licznik ticków, podczas których check jest całkowicie wyłączony
 *                 (teleport, respawn, zmiana świata, zmiana gamemode, itd.)
 *
 * Nie flagujemy nigdy na podstawie pojedynczego ticka — flag() jest wołane tylko
 * z warstwy detekcji, kiedy bufor/VL faktycznie przekroczy próg zdefiniowany przez check.
 */
public abstract class Check {

    protected final ViolationProcessor vp;
    protected final PlayerData data;

    /** Unikalna nazwa checka używana w alertach, np. "Speed/A", "Killaura/Rotation". */
    private final String checkName;

    // ── Violation level state ───────────────────────────────────────────────
    private double violationLevel = 0.0;
    private int buffer = 0;

    // ── Konfiguracja (nadpisywana przez podklasy w konstruktorze) ────────────
    /** Ile VL dodawane jest za pojedyncze naruszenie zanim zadziała mnożnik ciężkości. */
    protected double vlIncrement = 1.0;
    /** Naturalny spadek VL na czysty tick. */
    protected double vlDecay = 0.02;
    /** Mnożnik decay — VL *= (1 - decayRate) zamiast liniowego odejmowania, dla płynności. */
    protected double vlDecayMultiplier = 0.98;
    /** Próg VL, po którego przekroczeniu check zgłasza flagę. */
    protected double flagThreshold = 1.0;
    /** Próg VL, po którego przekroczeniu check prosi o setback (jeśli check go wspiera). */
    protected double setbackThreshold = Double.MAX_VALUE;
    /** Ile kolejnych podejrzanych ticków (buffer) zanim VL zacznie faktycznie rosnąć. */
    protected int requiredBuffer = 0;
    /** Maksymalny buffer — zapobiega nieograniczonemu narastaniu przy ciągłym cheatowaniu. */
    protected int maxBuffer = 20;

    // ── Exemption ──────────────────────────────────────────────────────────
    private int exemptTicks = 0;

    protected Check(PlayerData data, ViolationProcessor vp, String checkName) {
        this.data = data;
        this.vp = vp;
        this.checkName = checkName;
    }

    public final String getCheckName() {
        return checkName;
    }

    public final double getViolationLevel() {
        return violationLevel;
    }

    public final int getBuffer() {
        return buffer;
    }

    /**
     * Wyłącza check na daną liczbę ticków. Wołane przy teleportach, respawnie,
     * zmianie świata/gamemode, wejściu do pojazdu itd. Nie resetuje VL —
     * jedynie wstrzymuje detekcję, żeby uniknąć false-positive w trakcie
     * legalnej, nagłej zmiany stanu.
     */
    public final void exempt(int ticks) {
        if (ticks > this.exemptTicks) {
            this.exemptTicks = ticks;
        }
    }

    /** Czy check jest obecnie zwolniony z detekcji (np. po teleporcie). */
    protected final boolean isExempt() {
        return exemptTicks > 0;
    }

    /**
     * Wołane raz na tick klienta przez pętlę checka, ZANIM zostanie wykonana
     * właściwa logika detekcji. Zmniejsza licznik zwolnienia.
     *
     * @return true jeśli check powinien pominąć tę turę detekcji (był zwolniony)
     */
    protected final boolean tickExemption() {
        if (exemptTicks > 0) {
            exemptTicks--;
            return true;
        }
        return false;
    }

    /**
     * Zgłasza podejrzany tick. Buffer musi osiągnąć requiredBuffer zanim VL
     * faktycznie zacznie rosnąć — pojedynczy podejrzany tick nigdy sam z siebie
     * nie generuje flagi.
     *
     * @param severity  waga tego konkretnego naruszenia (0.0-∞, zwykle 0.5-5.0)
     * @param detail    opis debugowy dołączany do alertu
     */
    protected final void buffer(double severity, String detail) {
        buffer(severity, detail, 1.0);
    }

    /**
     * Wariant buffer() z jawnym mnożnikiem korelacji (patrz
     * dev.cc.anticheat.check.combat.CombatContext) — używany przez combat
     * checki (Reach/AimBot/KillAura), gdy ten sam atak wygenerował sygnał
     * z więcej niż jednego niezależnego checka naraz.
     */
    protected final void buffer(double severity, String detail, double correlationMultiplier) {
        if (buffer < maxBuffer) {
            buffer++;
        }

        if (buffer < requiredBuffer) {
            // Bufor jeszcze się nie wypełnił — nie karzemy pojedynczego ticka.
            return;
        }

        violationLevel += vlIncrement * severity;

        if (violationLevel >= setbackThreshold) {
            vp.flag(data, checkName, detail, violationLevel, true, correlationMultiplier);
        } else if (violationLevel >= flagThreshold) {
            vp.flag(data, checkName, detail, violationLevel, false, correlationMultiplier);
        }
    }

    /**
     * Wołane na czystym (niepodejrzanym) ticku. Zmniejsza buffer i stosuje decay do VL.
     * Zapewnia, że VL nie rośnie w nieskończoność i gracze "odpokutowują" stare naruszenia.
     */
    protected final void reward() {
        if (buffer > 0) {
            buffer--;
        }
        violationLevel = Math.max(0.0, (violationLevel - vlDecay) * vlDecayMultiplier);
    }

    /** Twardy reset stanu checka — wołane po setbacku lub ręcznym /ac reset. */
    public void reset() {
        violationLevel = 0.0;
        buffer = 0;
        exemptTicks = 0;
    }
}
