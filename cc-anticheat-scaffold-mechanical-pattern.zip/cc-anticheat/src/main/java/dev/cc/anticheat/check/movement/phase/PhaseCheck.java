/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.movement.phase;

import dev.cc.anticheat.CCAnticheat;
import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.predict.CollisionUtil;
import dev.cc.anticheat.predict.SetbackUtil;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/**
 * cc-anticheat — PhaseCheck (NoClip)
 *
 * Wykrywa przenikanie gracza przez bloki kolizyjne ("phase"/"noclip").
 *
 * Zamiast sprawdzać tylko pozycję końcową (co przepuszcza "tunelowanie" przez
 * cienkie ściany przy dużej prędkości w jednym pakiecie), próbkujemy CAŁY
 * odcinek ruchu między poprzednią a bieżącą pozycją (raytrace) i sprawdzamy,
 * czy przecina jakikolwiek kolizyjny blok. To jest odpowiednik podejścia
 * Grima (segment-based collision sampling) — ale własna implementacja.
 *
 * Wykluczenia: piston/moving block (mogą legalnie "wciskać" gracza przez to,
 * co chwilę wcześniej było ścianą), oraz świeżo po teleporcie/respawnie.
 *
 * NAPRAWA (priorytet 🟡11): poprzednia konfiguracja (requiredBuffer=0,
 * setback już po ~2 naruszeniach z rzędu) była zbyt agresywna jak na check
 * bazujący na przybliżonej geometrii AABB (Bukkit Block#getBoundingBox() nie
 * jest idealnie identyczny z wewnętrznym modelem kolizji Minecrafta dla
 * wszystkich bloków — drzwi w trakcie animacji otwierania, płoty, niektóre
 * bloki roślinne). Pojedynczy false-positive natychmiast eskalował do
 * setbacku. Dodano minimalny bufor (wymaga 2 kolejnych podejrzanych ticków)
 * oraz jawne wykluczenie bloków ze zmiennym/animowanym hitboxem.
 */
public class PhaseCheck extends Check {

    private final CCAnticheat plugin;

    public PhaseCheck(PlayerData data, ViolationProcessor vp, CCAnticheat plugin) {
        super(data, vp, "Phase");
        this.plugin = plugin;
        this.vlIncrement = 1.0;
        this.vlDecay = 0.2;
        this.vlDecayMultiplier = 0.9;
        this.flagThreshold = 2.0;
        this.setbackThreshold = 3.0; // wymaga teraz 3 potwierdzonych naruszeń zamiast ~2, patrz requiredBuffer
        this.requiredBuffer = 2; // minimalny bufor — pojedynczy podejrzany tick (np. drzwi w animacji) nie eskaluje sam z siebie
        this.maxBuffer = 6;
    }

    public void onMovement(MovementData current) {
        Player player = data.player;

        if (tickExemption()) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (data.awaitingTeleportConfirm) return;
        if (current.touchingPistonOrMovingBlock) return;
        if (current.totalDistance() < 0.001) return; // brak ruchu — nic do sprawdzenia

        double height = playerHeight(player);

        Vector start = new Vector(current.lastX, current.lastY, current.lastZ);
        Vector end = new Vector(current.x, current.y, current.z);

        boolean intersects = CollisionUtil.segmentIntersectsSolid(player.getWorld(), start, end, height);

        if (intersects) {
            buffer(1.0, String.format("from:(%.2f,%.2f,%.2f) to:(%.2f,%.2f,%.2f)",
                start.getX(), start.getY(), start.getZ(), end.getX(), end.getY(), end.getZ()));
        } else {
            reward();
        }

        if (getViolationLevel() >= setbackThreshold) {
            SetbackUtil.performSetback(plugin, data, "Phase");
        }
    }

    private double playerHeight(Player player) {
        if (player.isSwimming() || player.isGliding()) return CollisionUtil.PLAYER_HEIGHT_SWIMMING;
        if (player.isSneaking()) return CollisionUtil.PLAYER_HEIGHT_SNEAKING;
        return CollisionUtil.PLAYER_HEIGHT_STANDING;
    }
}
