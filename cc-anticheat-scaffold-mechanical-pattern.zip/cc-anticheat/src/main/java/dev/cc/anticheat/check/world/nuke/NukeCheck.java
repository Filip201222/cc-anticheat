/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.world.nuke;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;

/**
 * cc-anticheat — NukeCheck
 *
 * Wykrywa "Nuke" — niszczenie wielu bloków w promieniu wokół gracza naraz
 * (zamiast pojedynczego bloku, na który wskazuje raytrace), typowe dla cheatów
 * typu "X-Ray Nuke" / "Nuker" łamiących całe obszary automatycznie.
 *
 * Sub-checki:
 *   A. Break Rate — liczba bloków złamanych w krótkim oknie czasowym
 *      przekracza to, co pojedynczy gracz może fizycznie zdążyć kliknąć
 *      (uwzględniając auto-clickery jako górną granicę realistycznego CPS).
 *   B. Spatial Spread — złamane bloki w krótkim oknie czasowym są rozrzucone
 *      w promieniu, w którym pojedynczy raytrace (jeden kierunek patrzenia)
 *      nie mógłby ich wszystkich objąć — nuker łamie bloki dookoła siebie,
 *      nie tylko ten, na który faktycznie patrzy gracz.
 *   C. No-look correlation — złamany blok nie leży na linii wzroku gracza
 *      w momencie złamania (poza normalnym marginesem raytrace'a).
 */
public class NukeCheck extends Check {

    private static final long RATE_WINDOW_MS = 1000L;
    /** Maksymalna realistyczna liczba bloków/s dla ręcznego, szybkiego kopania z auto-repeat. */
    private static final int MAX_BLOCKS_PER_SECOND = 18;
    private static final double RAYTRACE_ANGLE_TOLERANCE_DEGREES = 12.0;
    private static final int SPATIAL_SAMPLE_MIN = 4;
    /** Promień, w którym rozrzut złamanych bloków w krótkim oknie jest fizycznie niemożliwy z jednego punktu patrzenia. */
    private static final double IMPOSSIBLE_SPREAD_RADIUS = 4.0;

    private final ArrayDeque<Long> breakTimestamps = new ArrayDeque<>(64);
    private final ArrayDeque<Location> recentBreakLocations = new ArrayDeque<>(16);

    public NukeCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "Nuke");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.1;
        this.vlDecayMultiplier = 0.9;
        this.flagThreshold = 3.0;
        this.setbackThreshold = Double.MAX_VALUE; // Nuke tylko flaguje/cancel, nie robi setbacku pozycji
        this.requiredBuffer = 1;
        this.maxBuffer = 15;
    }

    /**
     * Wołane gdy blok został faktycznie złamany (BlockBreakEvent), zanim
     * decydujemy czy pozwolić na drop/efekt.
     *
     * @return true jeśli złamanie powinno być anulowane (Nuke wykryty z wysoką pewnością)
     */
    public boolean onBlockBreak(Location brokenBlockLoc) {
        if (tickExemption()) return false;

        Player player = data.player;

        // Creative mode: gracz może legalnie łamać wiele bloków bardzo szybko
        // (instant-break niezależnie od narzędzia) podczas budowania/czyszczenia
        // terenu — rate/spread w survivalowym sensie tu nie ma zastosowania.
        if (player.getGameMode() == GameMode.CREATIVE) {
            reward();
            return false;
        }

        long now = System.currentTimeMillis();

        boolean flagged = false;

        // ── A. Break Rate ────────────────────────────────────────────────────
        breakTimestamps.addLast(now);
        while (!breakTimestamps.isEmpty() && now - breakTimestamps.peekFirst() > RATE_WINDOW_MS) {
            breakTimestamps.pollFirst();
        }

        if (breakTimestamps.size() > MAX_BLOCKS_PER_SECOND) {
            buffer(3.0, String.format("sub:BreakRate count:%d windowMs:%d", breakTimestamps.size(), RATE_WINDOW_MS));
            flagged = true;
        }

        // ── C. No-look correlation ──────────────────────────────────────────
        double angle = angleToBlock(player, brokenBlockLoc);
        if (angle > RAYTRACE_ANGLE_TOLERANCE_DEGREES) {
            buffer(2.5, String.format("sub:NoLook angle:%.1f limit:%.1f", angle, RAYTRACE_ANGLE_TOLERANCE_DEGREES));
            flagged = true;
        }

        // ── B. Spatial Spread ────────────────────────────────────────────────
        recentBreakLocations.addLast(brokenBlockLoc.clone());
        while (recentBreakLocations.size() > SPATIAL_SAMPLE_MIN) recentBreakLocations.pollFirst();

        if (recentBreakLocations.size() >= SPATIAL_SAMPLE_MIN && breakTimestamps.size() >= SPATIAL_SAMPLE_MIN) {
            long windowStart = now - 300L; // 300ms — kilka ticków
            long recentCount = breakTimestamps.stream().filter(t -> t >= windowStart).count();
            if (recentCount >= SPATIAL_SAMPLE_MIN) {
                double maxSpread = maxPairwiseDistance(recentBreakLocations);
                if (maxSpread > IMPOSSIBLE_SPREAD_RADIUS) {
                    buffer(3.5, String.format("sub:SpatialSpread spread:%.2f limit:%.1f samples:%d",
                        maxSpread, IMPOSSIBLE_SPREAD_RADIUS, recentBreakLocations.size()));
                    flagged = true;
                }
            }
        }

        if (!flagged) {
            reward();
        }

        return getViolationLevel() >= flagThreshold * 2;
    }

    /** Kąt (stopnie) między kierunkiem patrzenia gracza a wektorem do środka złamanego bloku. */
    private double angleToBlock(Player player, Location blockLoc) {
        Vector toBlock = blockLoc.toVector().add(new Vector(0.5, 0.5, 0.5))
            .subtract(player.getEyeLocation().toVector());
        Vector look = player.getEyeLocation().getDirection();

        double dot = clamp(toBlock.normalize().dot(look.normalize()), -1.0, 1.0);
        return Math.toDegrees(Math.acos(dot));
    }

    /** Maksymalna odległość między dowolną parą lokacji w zbiorze — miara rozrzutu przestrzennego. */
    private double maxPairwiseDistance(Iterable<Location> locations) {
        double max = 0;
        java.util.List<Location> list = new java.util.ArrayList<>();
        for (Location l : locations) list.add(l);
        for (int i = 0; i < list.size(); i++) {
            for (int j = i + 1; j < list.size(); j++) {
                double dist = list.get(i).distance(list.get(j));
                if (dist > max) max = dist;
            }
        }
        return max;
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    @Override
    public void reset() {
        super.reset();
        breakTimestamps.clear();
        recentBreakLocations.clear();
    }
}
