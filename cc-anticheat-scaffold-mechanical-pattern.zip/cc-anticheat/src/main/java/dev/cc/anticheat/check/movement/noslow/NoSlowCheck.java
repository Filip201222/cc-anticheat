/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.movement.noslow;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.predict.PlayerPhysicsEngine;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * cc-anticheat — NoSlowCheck
 *
 * Wykrywa "NoSlow" — ignorowanie spowolnienia ruchu, które vanilla wymusza
 * podczas:
 *   - jedzenia / picia (żucie),
 *   - blokowania mieczem (przed 1.9 combat) lub tarczą,
 *   - napinania łuku / kuszy,
 *   - czołgania się (sneak) — spowolnienie do ~0.3x normalnej prędkości.
 *
 * Każdy z tych stanów ogranicza maksymalną prędkość poziomą gracza w vanilla.
 * Cheat "NoSlow" wysyła pakiety ruchu ignorujące tę granicę. Sprawdzamy to
 * przez porównanie faktycznej prędkości z limitem właściwym dla aktywnego stanu,
 * z buforem odpornym na pojedynczy tick przejściowy (np. moment rozpoczęcia/
 * zakończenia jedzenia, gdzie prędkość jeszcze się nie ustabilizowała).
 *
 * NAPRAWA (priorytet 🟡10): poprzednie limity były sztywnymi stałymi, które
 * NIE uwzględniały efektu Speed — legalny gracz z Speed II jedzący jabłko
 * porusza się szybciej niż sztywny próg 0.20, generując false-positive.
 * Wszystkie limity są teraz bazowane na PlayerPhysicsEngine (ta sama formuła
 * przyspieszenia, co Speed/Strafe check), przemnożonej przez odpowiedni
 * współczynnik spowolnienia dla danego stanu — spójne z resztą silnika
 * fizyki zamiast niezależnego zestawu magicznych liczb.
 */
public class NoSlowCheck extends Check {

    /** Spowolnienie podczas jedzenia/blokowania/naciągania łuku — vanilla: ok. 0.2x normalnej prędkości ruchu. */
    private static final double ACTION_SLOWDOWN_MULTIPLIER = 0.35; // margines ponad teoretyczne 0.2x na jitter i tick przejściowy
    private static final double SNEAKING_SLOWDOWN_MULTIPLIER = 0.35; // sneak: ok. 0.3x, z marginesem
    private static final double MIN_ABSOLUTE_TOLERANCE = 0.05;

    public NoSlowCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "NoSlow");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.1;
        this.vlDecayMultiplier = 0.95;
        this.flagThreshold = 4.0;
        this.setbackThreshold = Double.MAX_VALUE; // NoSlow tylko flaguje/cancel, nie robi setbacku
        this.requiredBuffer = 3;
        this.maxBuffer = 20;
    }

    public void onMovement(MovementData current) {
        Player player = data.player;

        if (tickExemption()) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (current.inWater || current.inLava || current.onClimbable || current.gliding) {
            reward();
            return;
        }

        double horizontalSpeed = current.horizontalDistance();
        boolean flagged = false;

        // Limit bazowy: to, co gracz MÓGŁBY osiągnąć bez żadnego spowolnienia
        // (uwzględnia już Speed/Slowness/sprint) — mnożymy przez współczynnik
        // spowolnienia właściwy dla aktywnego stanu, zamiast porównywać ze
        // sztywną stałą niezależną od efektów gracza.
        double unslowedLimit = PlayerPhysicsEngine.maxHorizontalAcceleration(player, current)
            + baselineMomentum(current);

        if (isEatingOrDrinking(player) || isBlocking(player) || isChargingBow(player)) {
            double limit = Math.max(unslowedLimit * ACTION_SLOWDOWN_MULTIPLIER, MIN_ABSOLUTE_TOLERANCE);
            if (horizontalSpeed > limit) {
                buffer(1.5, String.format("sub:Action speed:%.4f limit:%.4f", horizontalSpeed, limit));
                flagged = true;
            }
        }

        if (!flagged && current.sneaking && current.actuallyOnGround) {
            double limit = Math.max(unslowedLimit * SNEAKING_SLOWDOWN_MULTIPLIER, MIN_ABSOLUTE_TOLERANCE);
            if (horizontalSpeed > limit) {
                buffer(1.0, String.format("sub:Sneaking speed:%.4f limit:%.4f", horizontalSpeed, limit));
                flagged = true;
            }
        }

        if (!flagged) {
            reward();
        }
    }

    /**
     * Przybliżony "rozpęd" gracza z poprzedniego ruchu — pozwala limitowi nie
     * być zerowy dla gracza, który już się poruszał przed rozpoczęciem
     * jedzenia/blokowania (spowolnienie tłumi PRZYROST prędkości, nie
     * natychmiast zeruje istniejący pęd).
     */
    private double baselineMomentum(MovementData current) {
        MovementData previous = data.movementAgo(1);
        if (previous == null) return 0.0;
        return previous.horizontalDistance() * (current.actuallyOnGround ? current.blockFriction : 0.91) * 0.35;
    }

    // ── Pomocniki wykrywania stanu ─────────────────────────────────────────────

    private boolean isEatingOrDrinking(Player player) {
        ItemStack main = player.getInventory().getItemInMainHand();
        ItemStack off = player.getInventory().getItemInOffHand();
        return isFoodOrDrinkable(main.getType()) && player.isHandRaised()
            || isFoodOrDrinkable(off.getType()) && player.isHandRaised();
    }

    private boolean isFoodOrDrinkable(Material type) {
        return type.isEdible()
            || type == Material.POTION
            || type == Material.MILK_BUCKET
            || type == Material.HONEY_BOTTLE;
    }

    private boolean isBlocking(Player player) {
        ItemStack main = player.getInventory().getItemInMainHand();
        ItemStack off = player.getInventory().getItemInOffHand();
        return player.isHandRaised() && (isBlockingItem(main.getType()) || isBlockingItem(off.getType()));
    }

    private boolean isBlockingItem(Material type) {
        return type == Material.SHIELD
            || type.name().endsWith("_SWORD")
            || type == Material.TRIDENT;
    }

    private boolean isChargingBow(Player player) {
        ItemStack main = player.getInventory().getItemInMainHand();
        ItemStack off = player.getInventory().getItemInOffHand();
        return player.isHandRaised() && (isBowItem(main.getType()) || isBowItem(off.getType()));
    }

    private boolean isBowItem(Material type) {
        return type == Material.BOW || type == Material.CROSSBOW;
    }
}
