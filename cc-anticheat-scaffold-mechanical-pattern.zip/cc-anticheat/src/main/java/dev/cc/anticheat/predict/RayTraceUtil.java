/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.predict;

import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

/**
 * cc-anticheat — RayTraceUtil
 *
 * Prawdziwy raytrace ray/AABB (punkt 2 specyfikacji), zamiast przybliżenia
 * "odległość punktu od najbliższej krawędzi bounding boxa" — te dwa podejścia
 * dają RÓŻNE wyniki i dla anticheatu ta różnica ma znaczenie:
 *
 *   point-to-box distance: "jak blisko atakujący JEST od celu" — mówi coś o
 *     dystansie, ale NIE o tym, czy atakujący faktycznie PATRZY na cel. Gracz
 *     mógłby stać blisko celu, patrzeć zupełnie gdzie indziej, i wciąż
 *     "przejść" test dystansu — co pozwala part cheatom (np. atakującym
 *     bez pełnej rotacji w stronę celu) prześlizgnąć się przez samą
 *     weryfikację dystansu.
 *
 *   ray/AABB intersection: "czy promień wystrzelony z oka gracza W KIERUNKU,
 *     W KTÓRYM PATRZY, faktycznie przecina bounding box celu, i w jakiej
 *     odległości" — to jest to, co faktycznie robi klient/serwer Minecrafta
 *     przy określaniu trafienia (target selection), więc porównanie z tym
 *     jest wiernym odwzorowaniem legalnej mechaniki gry, a nie przybliżeniem.
 *
 * Implementacja: standardowa metoda "slab" (przecięcie promienia z trzema
 * parami równoległych płaszczyzn tworzących AABB) — ten sam algorytm, którego
 * używa m.in. wewnętrzny raytracer Minecrafta i większość silników gier.
 */
public final class RayTraceUtil {

    private RayTraceUtil() {}

    public static final class RayHit {
        public final boolean hit;
        /** Odległość od origin do punktu wejścia promienia w AABB (Double.MAX_VALUE jeśli brak trafienia). */
        public final double distance;

        private RayHit(boolean hit, double distance) {
            this.hit = hit;
            this.distance = distance;
        }

        private static final RayHit MISS = new RayHit(false, Double.MAX_VALUE);
    }

    /**
     * Przecina promień (origin, direction znormalizowany) z bounding boxem,
     * ograniczając test do maxDistance. Zwraca RayHit z dystansem do punktu
     * wejścia, jeśli promień przecina box w zasięgu [0, maxDistance].
     */
    public static RayHit intersect(Vector origin, Vector direction, BoundingBox box, double maxDistance) {
        double tMin = 0.0;
        double tMax = maxDistance;

        // Oś X
        RaySlabResult resX = intersectSlab(origin.getX(), direction.getX(), box.getMinX(), box.getMaxX(), tMin, tMax);
        if (!resX.valid) return RayHit.MISS;
        tMin = resX.tMin;
        tMax = resX.tMax;

        // Oś Y
        RaySlabResult resY = intersectSlab(origin.getY(), direction.getY(), box.getMinY(), box.getMaxY(), tMin, tMax);
        if (!resY.valid) return RayHit.MISS;
        tMin = resY.tMin;
        tMax = resY.tMax;

        // Oś Z
        RaySlabResult resZ = intersectSlab(origin.getZ(), direction.getZ(), box.getMinZ(), box.getMaxZ(), tMin, tMax);
        if (!resZ.valid) return RayHit.MISS;
        tMin = resZ.tMin;

        if (tMin < 0 || tMin > maxDistance) return RayHit.MISS;
        return new RayHit(true, tMin);
    }

    /**
     * Najmniejsza odległość promienia (odcinka [0, maxDistance]) od bounding
     * boxa, nawet gdy promień GO NIE PRZECINA — używane do oceny "o ile
     * gracz nie trafił", zamiast binarnego hit/miss.
     *
     * NAPRAWA (przegląd, punkt 🟠4): poprzednia wersja próbkowała promień w
     * 16 stałych krokach i brała minimum z tych punktów — to jest
     * PRZYBLIŻENIE, którego dokładność zależy od gęstości próbek (mogło
     * przeoczyć faktyczny punkt najbliższy między dwoma próbkami, szczególnie
     * przy dużym maxDistance względem rozmiaru bounding boxa celu). Zastąpione
     * analitycznym rozwiązaniem w zamkniętej formie:
     *
     *   1. Rzutujemy środek AABB na prostą promienia, żeby uzyskać wstępny
     *      parametr t (bez ograniczeń) — to jest punkt na LINII najbliższy
     *      środkowi boxa.
     *   2. Ograniczamy t do [0, maxDistance] (promień to odcinek, nie
     *      nieskończona prosta — atak ma ograniczony zasięg).
     *   3. Dla otrzymanego punktu na promieniu, odległość od AABB liczymy
     *      analitycznie (clamp punktu do każdej osi bryły, tak jak w
     *      clampDelta) — TO JEST dokładna odległość punkt-do-AABB, nie
     *      przybliżenie.
     *
     * Kroki 1-3 dają globalne minimum dla przypadku, gdy promień nie
     * przecina boxa: funkcja odległość(t) między punktem na promieniu a
     * najbliższym punktem AABB jest wypukła (AABB jest zbiorem wypukłym),
     * więc pojedyncze rzutowanie + clamp znajduje minimum bez potrzeby
     * próbkowania czy iteracji.
     */
    public static double missDistance(Vector origin, Vector direction, BoundingBox box, double maxDistance) {
        RayHit hit = intersect(origin, direction, box, maxDistance);
        if (hit.hit) return 0.0;

        Vector center = new Vector(
            (box.getMinX() + box.getMaxX()) / 2.0,
            (box.getMinY() + box.getMaxY()) / 2.0,
            (box.getMinZ() + box.getMaxZ()) / 2.0
        );

        // Rzut środka boxa na prostą promienia: t = dot(center - origin, direction).
        // direction jest znormalizowany (kontrakt tej metody, zgodny z resztą klasy).
        Vector toCenter = center.clone().subtract(origin);
        double t = toCenter.dot(direction);
        t = clamp(t, 0.0, maxDistance);

        Vector closestPointOnRay = origin.clone().add(direction.clone().multiply(t));

        double dx = clampDelta(closestPointOnRay.getX(), box.getMinX(), box.getMaxX());
        double dy = clampDelta(closestPointOnRay.getY(), box.getMinY(), box.getMaxY());
        double dz = clampDelta(closestPointOnRay.getZ(), box.getMinZ(), box.getMaxZ());
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private static double clampDelta(double v, double min, double max) {
        if (v < min) return min - v;
        if (v > max) return v - max;
        return 0.0;
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Ray → plane (block face) intersection — punkt 2 przeglądu: "Usuń
    // zależność od sztucznego FACE_SLAB_THICKNESS. Zastąp ją matematycznym
    // ray → plane intersection."
    // ═════════════════════════════════════════════════════════════════════════

    public static final class PlaneHit {
        public final boolean hit;
        /** Odległość od origin do punktu przecięcia z płaszczyzną (Double.MAX_VALUE jeśli brak trafienia). */
        public final double distance;
        /** Punkt przecięcia w globalnych współrzędnych świata. */
        public final Vector point;
        /**
         * Współrzędne lokalne U/V na powierzchni ściany, w zakresie [0,1] gdy
         * punkt mieści się w granicach bloku, wartości poza [0,1] oznaczają
         * że promień przeciął PŁASZCZYZNĘ, ale poza faktyczną powierzchnią
         * tej konkretnej ściany (np. przeciąłby sąsiedni blok).
         */
        public final double u, v;

        private PlaneHit(boolean hit, double distance, Vector point, double u, double v) {
            this.hit = hit;
            this.distance = distance;
            this.point = point;
            this.u = u;
            this.v = v;
        }

        private static final PlaneHit MISS = new PlaneHit(false, Double.MAX_VALUE, null, 0, 0);
    }

    /**
     * Przecina promień z płaszczyzną NIESKOŃCZONĄ, na której leży dana ściana
     * bloku (blockX/Y/Z, face — nazwa kierunku: "DOWN"/"UP"/"NORTH"/"SOUTH"/
     * "WEST"/"EAST", porównywana przez String zgodnie z resztą projektu, żeby
     * nie zależeć od dokładnej nazwy stałej EnumWrappers.Direction), po czym
     * sprawdza, czy punkt przecięcia mieści się w GRANICACH tej jednej,
     * konkretnej powierzchni 1x1 (nie całego nieskończonego planu).
     *
     * Algorytm (dokładnie zgodny z przeglądem):
     *   eye position + direction vector → płaszczyzna ściany → punkt
     *   przecięcia → sprawdzenie U/V w granicach powierzchni → valid hit.
     *
     * Zastępuje poprzednie podejście (sztuczny "plaster" o grubości
     * FACE_SLAB_THICKNESS testowany przez ray/AABB) — to było przybliżenie
     * geometrii ściany jako cienkiej bryły 3D, tutaj płaszczyzna jest
     * dokładna (2D, nieskończenie cienka), a "w granicach ściany" sprawdzane
     * jest przez rzeczywiste współrzędne lokalne, nie przez grubość bryły.
     */
    public static PlaneHit intersectFace(Vector origin, Vector direction,
                                          int blockX, int blockY, int blockZ, String faceName,
                                          double maxDistance) {
        // Punkt na płaszczyźnie i jej normalna, zależnie od ściany.
        Vector planePoint;
        Vector normal;
        switch (faceName) {
            case "DOWN":
                planePoint = new Vector(blockX, blockY, blockZ);
                normal = new Vector(0, -1, 0);
                break;
            case "UP":
                planePoint = new Vector(blockX, blockY + 1, blockZ);
                normal = new Vector(0, 1, 0);
                break;
            case "NORTH":
                planePoint = new Vector(blockX, blockY, blockZ);
                normal = new Vector(0, 0, -1);
                break;
            case "SOUTH":
                planePoint = new Vector(blockX, blockY, blockZ + 1);
                normal = new Vector(0, 0, 1);
                break;
            case "WEST":
                planePoint = new Vector(blockX, blockY, blockZ);
                normal = new Vector(-1, 0, 0);
                break;
            case "EAST":
                planePoint = new Vector(blockX + 1, blockY, blockZ);
                normal = new Vector(1, 0, 0);
                break;
            default:
                return PlaneHit.MISS; // nierozpoznana nazwa ściany — brak podstaw do testu płaszczyzny
        }

        double denom = normal.dot(direction);
        if (Math.abs(denom) < 1e-9) {
            // Promień równoległy do płaszczyzny — nigdy jej nie przetnie
            // (albo leży dokładnie na niej, co jest miarą zerową i traktujemy jako miss).
            return PlaneHit.MISS;
        }

        double t = planePoint.clone().subtract(origin).dot(normal) / denom;
        if (t < 0 || t > maxDistance) {
            return PlaneHit.MISS;
        }

        Vector point = origin.clone().add(direction.clone().multiply(t));

        // Współrzędne lokalne U/V na powierzchni 1x1 tej ściany — dwie osie
        // STYCZNE do normalnej (te same pary, których żąda punkt 1 przeglądu
        // dla hit-vector deviation: UP/DOWN→(x,z), NORTH/SOUTH→(x,y), EAST/WEST→(y,z)).
        double u, v;
        switch (faceName) {
            case "DOWN":
            case "UP":
                u = point.getX() - blockX;
                v = point.getZ() - blockZ;
                break;
            case "NORTH":
            case "SOUTH":
                u = point.getX() - blockX;
                v = point.getY() - blockY;
                break;
            default: // WEST / EAST
                u = point.getY() - blockY;
                v = point.getZ() - blockZ;
                break;
        }

        boolean withinFace = u >= 0.0 && u <= 1.0 && v >= 0.0 && v <= 1.0;
        return new PlaneHit(withinFace, t, point, u, v);
    }

    private static final class RaySlabResult {
        final boolean valid;
        final double tMin, tMax;

        RaySlabResult(boolean valid, double tMin, double tMax) {
            this.valid = valid;
            this.tMin = tMin;
            this.tMax = tMax;
        }
    }

    /**
     * Przecina promień z jedną parą równoległych płaszczyzn (jedna "warstwa"
     * slab metody) i zwęża istniejący przedział [tMin, tMax] do części
     * wspólnej z zakresem, w którym promień jest wewnątrz tej warstwy.
     */
    private static RaySlabResult intersectSlab(double originComponent, double dirComponent,
                                                 double slabMin, double slabMax,
                                                 double tMin, double tMax) {
        if (Math.abs(dirComponent) < 1e-9) {
            // Promień równoległy do tej pary płaszczyzn — trafienie tylko
            // jeśli origin już mieści się w zakresie slaba na tej osi.
            if (originComponent < slabMin || originComponent > slabMax) {
                return new RaySlabResult(false, tMin, tMax);
            }
            return new RaySlabResult(true, tMin, tMax);
        }

        double t1 = (slabMin - originComponent) / dirComponent;
        double t2 = (slabMax - originComponent) / dirComponent;
        if (t1 > t2) {
            double tmp = t1;
            t1 = t2;
            t2 = tmp;
        }

        double newTMin = Math.max(tMin, t1);
        double newTMax = Math.min(tMax, t2);

        if (newTMin > newTMax) {
            return new RaySlabResult(false, newTMin, newTMax);
        }
        return new RaySlabResult(true, newTMin, newTMax);
    }
}
