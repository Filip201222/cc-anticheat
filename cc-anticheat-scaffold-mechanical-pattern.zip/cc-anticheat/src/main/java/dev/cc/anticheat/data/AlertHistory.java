/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.data;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * cc-anticheat — AlertHistory
 *
 * In-memory, per-player (by name, case-insensitive) log of every AC alert
 * and every kick issued by cc-anticheat. Feeds /anticheat alertgui and the
 * player-info GUI opened by clicking a name in chat alerts.
 *
 * NOTE: this is intentionally in-memory only (cleared on restart). If you
 * need alerts to survive restarts, back this with a small SQLite/YAML store.
 */
public class AlertHistory {

    public static final int MAX_ENTRIES_PER_PLAYER = 200;

    private final Map<String, Deque<Entry>> history = new ConcurrentHashMap<>();

    public void record(String playerName, Entry.Type type, String check, String detail) {
        Deque<Entry> deque = history.computeIfAbsent(key(playerName), k -> new ArrayDeque<>());
        synchronized (deque) {
            deque.addFirst(new Entry(type, check, detail, System.currentTimeMillis()));
            while (deque.size() > MAX_ENTRIES_PER_PLAYER) {
                deque.removeLast();
            }
        }
    }

    /** Newest-first list of every recorded entry for a player. */
    public List<Entry> get(String playerName) {
        Deque<Entry> deque = history.get(key(playerName));
        if (deque == null) return List.of();
        synchronized (deque) {
            return new ArrayList<>(deque);
        }
    }

    public int countAlerts(String playerName) {
        int count = 0;
        for (Entry e : get(playerName)) if (e.type == Entry.Type.ALERT) count++;
        return count;
    }

    public int countKicks(String playerName) {
        int count = 0;
        for (Entry e : get(playerName)) if (e.type == Entry.Type.KICK) count++;
        return count;
    }

    public void clear(String playerName) {
        history.remove(key(playerName));
    }

    private static String key(String name) {
        return name.toLowerCase(Locale.ROOT);
    }

    public static class Entry {
        public enum Type { ALERT, KICK, BAN }

        public final Type type;
        public final String check;
        public final String detail;
        public final long timestamp;

        public Entry(Type type, String check, String detail, long timestamp) {
            this.type = type;
            this.check = check;
            this.detail = detail == null ? "" : detail;
            this.timestamp = timestamp;
        }
    }
}
