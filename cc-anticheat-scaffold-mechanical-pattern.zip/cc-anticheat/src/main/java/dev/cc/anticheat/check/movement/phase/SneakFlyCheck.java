/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.movement.phase;

import dev.cc.anticheat.CCAnticheat;
import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.predict.SetbackUtil;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

/**
 * cc-anticheat — SneakFlyCheck
 *
 * Wykrywa "SneakFly" — nadużycie mechaniki sneak-na-krawędzi (edge-sneaking)
 * do utrzymania się w powietrzu bez podparcia, wykorzystywane przez wiele
 * clientów cheatów jako "łagodniejsza" forma flight, trudniejsza do wykrycia
 * niż zwykły Flight, bo generuje niewielkie, powtarzające się mikro-ruchy
 * pionowe zamiast stałego zawisu.
 *
 * Sygnatura: gracz kuca (sneaking), nie ma bloku wystarczająco blisko pod
 * sobą (nasza AABB-owa weryfikacja gruntu mówi false), a mimo to jego pionowa
 * prędkość nie narasta zgodnie z grawitacją przez wiele ticków z rzędu —
 * jakby "łapał się" czegoś, czego tam nie ma.
 *
 * Różni się od FlightCheck tym, że skupia się WYŁĄCZNIE na kontekście
 * sneak+krawędź (gdzie klient often "zgadza się" z serwerem co do onGround
 * przez spoofing tego pola w pakiecie), więc weryfikujemy przez naszą
 * niezależną AABB (current.actuallyOnGround) zamiast polegać na deklaracji.
 */
public class SneakFlyCheck extends Check {

    private static final int SUSTAINED_TICKS_THRESHOLD = 8;

    private int suspiciousStreak = 0;

    private final CCAnticheat plugin;

    public SneakFlyCheck(PlayerData data, ViolationProcessor vp, CCAnticheat plugin) {
        super(data, vp, "SneakFly");
        this.plugin = plugin;
        this.vlIncrement = 1.0;
        this.vlDecay = 0.12;
        this.vlDecayMultiplier = 0.94;
        this.flagThreshold = 5.0;
        this.setbackThreshold = 12.0;
        this.requiredBuffer = 4;
        this.maxBuffer = 20;
    }

    public void onMovement(MovementData current) {
        Player player = data.player;

        if (tickExemption()) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (player.isFlying() || player.getAllowFlight()) return;
        if (data.awaitingTeleportConfirm) return;

        if (!current.sneaking) {
            suspiciousStreak = 0;
            reward();
            return;
        }

        boolean exemptContext = current.inWater || current.inLava || current.onClimbable
            || current.inWeb || current.gliding || current.inBubbleColumn
            || current.touchingPistonOrMovingBlock;

        if (exemptContext) {
            suspiciousStreak = 0;
            reward();
            return;
        }

        // Klient deklaruje onGround=true, ale nasza własna weryfikacja AABB mówi false
        // — klasyczna sygnatura spoofowania pola onGround w pakiecie ruchu.
        boolean groundMismatch = current.clientClaimsOnGround && !current.actuallyOnGround;

        boolean notFalling = current.deltaY > -0.03 && current.deltaY < 0.03;

        if (groundMismatch && notFalling) {
            suspiciousStreak++;
            if (suspiciousStreak > SUSTAINED_TICKS_THRESHOLD) {
                buffer(1.5, String.format("streak:%d deltaY:%.5f groundMismatch:%b",
                    suspiciousStreak, current.deltaY, groundMismatch));
            }
        } else {
            suspiciousStreak = Math.max(0, suspiciousStreak - 2);
            reward();
        }

        if (getViolationLevel() >= setbackThreshold) {
            SetbackUtil.performSetback(plugin, data, "SneakFly");
            suspiciousStreak = 0;
        }
    }

    @Override
    public void reset() {
        super.reset();
        suspiciousStreak = 0;
    }
}
