/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.movement.physics;

import dev.cc.anticheat.CCAnticheat;
import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.predict.MovementEnvelope;
import dev.cc.anticheat.predict.SetbackUtil;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

/**
 * cc-anticheat — FlightCheck
 *
 * Walidator ruchu pionowego oparty o pełną predykcję fizyki (PlayerPhysicsEngine)
 * zamiast pojedynczego progu na deltaY. Analizujemy SEKWENCJĘ ruchu pionowego
 * (kilka ostatnich ticków z historii), nie pojedynczy pakiet, żeby odróżnić
 * legalne odchylenie (np. rozpoczęcie skoku, wejście w wodę, ziemia
 * nierówna/schody) od utrzymującego się w czasie naruszenia grawitacji.
 *
 * Sub-checki:
 *   A. Vertical prediction  — porównanie realnej deltaY z przewidywaną przez
 *      silnik fizyki, z tolerancją zależną od kontekstu (woda/drabina/etc.)
 *   B. Sustained hover      — utrzymujący się brak spadku bez podparcia
 *      przez dłuższy czas (kilkanaście ticków z rzędu, nie jeden)
 *   C. NoFall               — client zgłasza onGround=true mimo że nasza
 *      własna weryfikacja AABB mówi inaczej
 *
 * Edge case'y jawnie obsłużone (patrz exemptContext i tolerancje per-kontekst):
 *   schody/półbloki/trapdoory (przez CollisionUtil.isOnGround AABB), slime
 *   (bounce w PlayerPhysicsEngine), honey (spowolnienie spadania przy zjeździe
 *   po ścianie), pistony/moving block (touchingPistonOrMovingBlock), levitation,
 *   slow falling, elytra (własna, luźniejsza tolerancja zamiast pełnego
 *   wykluczenia), vehicle, teleporty (exempt natychmiastowy + z eventu),
 *   SKOK (justJumped — priorytet 🟠5: naprawiony realny błąd, w którym
 *   każdy zwykły skok generował fałszywe naruszenie, bo silnik fizyki
 *   przewidywał deltaY=0 zamiast dopuszczać wysokość skoku z Jump Boost).
 */
public class FlightCheck extends Check {

    private static final double VERTICAL_TOLERANCE = 0.03;
    /** Elytra ma dużo bardziej zmienną krzywą lotu (zależną od pitch/roll gracza)
     *  niż zwykły spadek swobodny — luźniejsza tolerancja zamiast pełnego wykluczenia,
     *  żeby wciąż łapać rażące naruszenia (np. wznoszenie bez pique) podczas lotu. */
    private static final double ELYTRA_VERTICAL_TOLERANCE = 0.15;
    private static final int HOVER_TICKS_THRESHOLD = 10;

    private int hoverStreak = 0;
    private int consecutiveOffsetTicks = 0;

    private final CCAnticheat plugin;

    public FlightCheck(PlayerData data, ViolationProcessor vp, CCAnticheat plugin) {
        super(data, vp, "Flight/Vertical");
        this.plugin = plugin;
        this.vlIncrement = 1.0;
        this.vlDecay = 0.15;
        this.vlDecayMultiplier = 0.95;
        this.flagThreshold = 6.0;
        this.setbackThreshold = 16.0;
        this.requiredBuffer = 3;
        this.maxBuffer = 25;
    }

    public void onMovement(MovementData current) {
        Player player = data.player;

        if (tickExemption()) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (player.getAllowFlight() || player.isFlying()) return;
        if (data.awaitingTeleportConfirm) return;
        if (current.inVehicle) return;

        // ── Kontekst zwalniający detekcję pionową całkowicie (bez flagowania) ──
        boolean exemptContext = current.onClimbable
            || current.inWater || current.inLava || current.inBubbleColumn
            || current.touchingPistonOrMovingBlock || current.actuallyOnGround
            || hasLevitationOrSlowFalling(player);

        // Elytra dostaje własną, luźniejszą tolerancję zamiast całkowitego
        // wykluczenia, żeby dalej łapać rażące naruszenia w locie.
        double verticalTolerance = current.gliding ? ELYTRA_VERTICAL_TOLERANCE : VERTICAL_TOLERANCE;

        // ── A. Predykcja pionowa (przez MovementEnvelope) ────────────────────
        // Envelope (patrz PlayerPhysicsEngine#computeEnvelope) już poprawnie
        // obsługuje start skoku (deviationY=0 dla legalnej wysokości skoku z
        // Jump Boost) — nie musimy tu osobno wykrywać justJumped, bo ta logika
        // jest teraz scentralizowana w silniku fizyki, żeby Speed/Flight/NoSlow
        // nie utrzymywały każdy własnej, potencjalnie niespójnej kopii.
        MovementEnvelope envelope = current.envelope;
        double offset = envelope != null ? envelope.deviationY : 0.0;

        if (!exemptContext && offset > verticalTolerance) {
            consecutiveOffsetTicks++;
            // Waga rośnie z wielkością odchylenia ORAZ z tym, jak długo się
            // utrzymuje — pojedynczy duży skok offsetu (np. przez lag) waży
            // mniej niż ten sam offset utrzymujący się kilka ticków z rzędu.
            // confidenceWeightedSeverity tłumi karę, gdy sama predykcja była
            // niepewna (np. pierwszy tick po zmianie medium) — patrz javadoc
            // MovementEnvelope#confidenceWeightedSeverity.
            double rawSeverity = Math.min(offset * 8.0, 4.0) * (1.0 + Math.min(consecutiveOffsetTicks * 0.15, 1.5));
            double severity = envelope != null ? envelope.confidenceWeightedSeverity(rawSeverity) : rawSeverity;
            buffer(severity, String.format(
                "actualDy:%.4f expectedDy:%.4f offset:%.4f streak:%d gliding:%b confidence:%.2f",
                current.deltaY, envelope != null ? envelope.expectedVelocityY : 0.0,
                offset, consecutiveOffsetTicks, current.gliding,
                envelope != null ? envelope.confidence : 1.0));
        } else {
            consecutiveOffsetTicks = Math.max(0, consecutiveOffsetTicks - 1);
            reward();
        }

        // ── B. Sustained hover ──────────────────────────────────────────────
        // Elytra wyłączona z hover-checka: lot poziomy ze stabilną wysokością
        // jest w pełni legalny (glide bez pique), więc brak zmiany deltaY
        // podczas gliding nie jest sygnałem cheatowania.
        boolean floating = !current.actuallyOnGround && !exemptContext && !current.gliding
            && Math.abs(current.deltaY) < 0.001;
        if (floating) {
            hoverStreak++;
            if (hoverStreak > HOVER_TICKS_THRESHOLD) {
                buffer(2.0, String.format("hoverStreak:%d", hoverStreak));
            }
        } else {
            hoverStreak = 0;
        }

        // ── Setback jeśli VL przekroczyło próg ──────────────────────────────
        if (getViolationLevel() >= setbackThreshold) {
            SetbackUtil.performSetback(plugin, data, "Flight/Vertical");
        }
    }

    private boolean hasLevitationOrSlowFalling(Player player) {
        return player.hasPotionEffect(org.bukkit.potion.PotionEffectType.LEVITATION)
            || player.hasPotionEffect(org.bukkit.potion.PotionEffectType.SLOW_FALLING);
    }

    @Override
    public void reset() {
        super.reset();
        hoverStreak = 0;
        consecutiveOffsetTicks = 0;
    }
}
