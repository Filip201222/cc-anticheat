/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.movement.timer;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.violation.ViolationProcessor;

/**
 * cc-anticheat — TimerCheck
 *
 * Wykrywa manipulację prędkością upływu ticków klienta ("Timer" cheat: gracz
 * wysyła pakiety ruchu częściej niż raz na 50ms, symulując grę z wyższym TPS).
 *
 * Podejście: każdy klient (od Minecraft 1.21.2) wysyła jawny pakiet
 * client_tick_end dokładnie raz na każdy swój tick logiki gry — niezależnie od
 * tego, czy w danym ticku poruszył się. To jest niepodrabialne 1:1 źródło
 * częstotliwości ticków klienta, o wiele solidniejsze niż stara metoda oparta
 * o transakcje (WINDOW_CONFIRMATION), która w ogóle nie istnieje w tej wersji
 * protokołu.
 *
 * Algorytm:
 *   - Mierzymy realny czas serwera (nanoTime) między kolejnymi CLIENT_TICK_END.
 *   - Oczekiwana wartość to 50ms (1 tick = 1/20 s), skorygowana o aktualne TPS
 *     serwera (lag compensation — przy niskim TPS serwer sam przetwarza pakiety
 *     przychodzące z opóźnieniem, co zniekształca zmierzony odstęp mimo że
 *     klient faktycznie wysyłał je w regularnym tempie).
 *   - Jeśli klient zgłasza kolejne tick-end istotnie częściej niż oczekiwana
 *     wartość, bufor rośnie; wymagamy requiredBuffer kolejnych podejrzanych
 *     ticków, zanim VL faktycznie zacznie się liczyć (odporność na jitter).
 *
 * NAPRAWA (priorytet 🟠8, po analizie logicznej krok po kroku — nie mam w tym
 * środowisku możliwości uruchomienia JUnit, więc zamiast pisać niesprawdzalne
 * testy, prześledziłem algorytm ręcznie na typowych scenariuszach):
 *   - Tolerancja stała 8ms nie uwzględniała pingu gracza — jitter SIECIOWY
 *     (nie tylko serwerowy TPS) rośnie z pingiem, więc gracz z wyższym pingiem
 *     miał realną szansę na przypadkowe, legalne przekroczenie ciasnego progu.
 *     Dodano composite tolerance: stała baza + składnik proporcjonalny do pingu.
 *   - Brak twardego dolnego ogranicznika: przy EKSTREMALNYCH wartościach
 *     deltaMs (np. duplikat pakietu przez retransmisję TCP dający deltaMs≈0),
 *     poprzedni wzór na severity (proporcjonalny do różnicy) dawał tylko
 *     umiarkowaną karę zamiast bardzo wysokiej — dodano dodatkowy, silniejszy
 *     mnożnik dla skrajnych przypadków (deltaMs < 20ms, czyli >2x realnego przyspieszenia).
 */
public class TimerCheck extends Check {

    private static final double EXPECTED_TICK_MS = 50.0;
    /** Bazowa tolerancja na jitter harmonogramu JVM, niezależna od sieci. */
    private static final double BASE_TOLERANCE_MS = 6.0;
    /** Dodatkowa tolerancja proporcjonalna do pingu gracza — jitter sieciowy rośnie z opóźnieniem połączenia. */
    private static final double PING_TOLERANCE_FACTOR = 0.06;
    /** Twardy sufit tolerancji — nawet przy ekstremalnym pingu nie rozluźniamy progu w nieskończoność. */
    private static final double MAX_TOLERANCE_MS = 25.0;
    /** Próg dla "skrajnego" przyspieszenia (>2x realnej prędkości ticka) — silniejsza kara. */
    private static final double EXTREME_THRESHOLD_MS = 20.0;

    private long lastTickEndNs = -1;

    public TimerCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "Timer");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.05;
        this.vlDecayMultiplier = 0.97;
        this.flagThreshold = 8.0;
        this.setbackThreshold = Double.MAX_VALUE; // Timer nigdy sam nie robi setbacku, tylko cancel ruchu
        this.requiredBuffer = 6;
        this.maxBuffer = 30;
    }

    /**
     * Wołane przy odebraniu CLIENT_TICK_END. Główne źródło detekcji.
     *
     * @param currentTps  bieżące TPS serwera (do korekty progu przy lagu serwerowym)
     */
    public void onClientTickEnd(double currentTps) {
        long now = System.nanoTime();

        if (data.timerJoinExemptTicks > 0) {
            data.timerJoinExemptTicks--;
            lastTickEndNs = now;
            return;
        }

        if (tickExemption()) {
            lastTickEndNs = now;
            return;
        }

        if (lastTickEndNs < 0) {
            lastTickEndNs = now;
            return;
        }

        double deltaMs = (now - lastTickEndNs) / 1_000_000.0;
        lastTickEndNs = now;
        data.lastClientTickDeltaMs = deltaMs;

        // Korekta lag compensation: jeśli serwer sam działa poniżej 20 TPS,
        // rozluźniamy oczekiwaną wartość proporcjonalnie, bo klient fizycznie
        // nie może wysyłać ticków szybciej niż pozwala mu na to opóźniona
        // pętla serwera odbierająca te pakiety.
        double tpsCorrection = currentTps > 0 && currentTps < 19.5
            ? (20.0 / currentTps)
            : 1.0;
        double expected = EXPECTED_TICK_MS * tpsCorrection;

        // Tolerancja złożona: baza (jitter JVM) + składnik proporcjonalny do
        // pingu gracza (jitter sieciowy), z twardym sufitem żeby bardzo wysoki
        // ping nie czynił checka bezużytecznym.
        double pingTolerance = Math.min(data.averagePing() * PING_TOLERANCE_FACTOR, MAX_TOLERANCE_MS - BASE_TOLERANCE_MS);
        double tolerance = BASE_TOLERANCE_MS + pingTolerance;

        if (deltaMs < expected - tolerance) {
            double severity = Math.min((expected - deltaMs) / EXPECTED_TICK_MS, 3.0);
            if (deltaMs < EXTREME_THRESHOLD_MS) {
                // Ponad 2x realnej prędkości ticka — to nie jest już "trochę za
                // szybko", to ewidentna manipulacja timerem lub duplikat pakietu
                // wysłany celowo. Kara rośnie mocniej niż liniowo w tym zakresie.
                severity *= 1.8;
            }
            buffer(severity, String.format("deltaMs:%.1f expected:%.1f tolerance:%.1f tps:%.1f ping:%.0f",
                deltaMs, expected, tolerance, currentTps, data.averagePing()));
        } else {
            reward();
        }
    }

    @Override
    public void reset() {
        super.reset();
        lastTickEndNs = -1;
    }
}
