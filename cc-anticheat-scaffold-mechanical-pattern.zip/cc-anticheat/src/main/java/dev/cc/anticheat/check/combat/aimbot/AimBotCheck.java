/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.combat.aimbot;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.check.combat.CombatContext;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;

import java.util.ArrayDeque;

/**
 * cc-anticheat — AimBotCheck
 *
 * Gruntowna przebudowa (priorytet 🔴2). Problemy poprzedniej wersji i naprawy:
 *
 * A. GCD Analysis
 *    PROBLEM: liczony z pojedynczej serii 40 próbek bez filtrowania małych/
 *    zerowych rotacji — statyczne patrzenie (gracz stoi, prawie nie rusza
 *    myszą) sztucznie zaniżało GCD do 0/1, generując false-positive dla
 *    kompletnie biernych graczy. Też nie uwzględniał zmiany czułości myszy
 *    w trakcie sesji (legalna, częsta akcja).
 *    NAPRAWA: filtrujemy próbki poniżej minimalnego progu ruchu (szum), i
 *    zamiast JEDNEJ serii łączymy wynik z DWÓCH kolejnych, niezależnych
 *    okien — flagujemy tylko gdy OBA dają tę samą podejrzaną sygnaturę
 *    (spójność w czasie, nie przypadkowa jednorazowa zbieżność).
 *
 * B. Rotation Smoothness
 *    PROBLEM: próg SD był stały niezależnie od WIELKOŚCI ruchu — naturalne,
 *    powolne, drobne skanowanie celu ma z definicji małą drugą pochodną
 *    (mało miejsca na jitter przy małych ruchach), więc było masowo
 *    flagowane jako "bot" mimo bycia w pełni ludzkim zachowaniem.
 *    NAPRAWA: SD normalizowane względem ŚREDNIEJ WIELKOŚCI ruchu w oknie
 *    (współczynnik zmienności, nie surowe odchylenie), i wymagamy, żeby
 *    średni ruch był wystarczająco DUŻY, żeby jitter miał gdzie się
 *    ujawnić — małe ruchy są wyłączone z tego sub-checka całkowicie.
 *
 * C. Snap Detection
 *    PROBLEM: dowolny obrót >45°/tick w połączeniu z atakiem flagował,
 *    nawet gdy gracz normalnie szybko się odwrócił do NOWEGO celu (legalne
 *    przełączenie uwagi w walce) — nie sprawdzano, czy snap faktycznie
 *    kończył się WYCELOWANIEM w cel ataku, tylko sam fakt dużego obrotu.
 *    NAPRAWA: snap flaguje tylko gdy KOŃCOWA rotacja po dużym obrocie ląduje
 *    z bardzo małym błędem na celu ataku (idealne wycelowanie po skoku) —
 *    to jest właściwa sygnatura snap-aimbota, nie sam fakt szybkiego obrotu.
 *
 * D. Jerk Analysis (specyfikacja, punkt 5 — "jerk" jawnie wymieniony obok
 *    acceleration/deceleration jako osobna cecha do zbierania)
 *    Trzecia pochodna rotacji (zmiana przyspieszenia). Ludzki ruch myszy ma
 *    ciągłą krzywą jerku nawet przy szybkich, gwałtownych ruchach — silnik
 *    aimbota interpolujący liniowo/kwadratowo do celu generuje jerk bliski
 *    zeru (bo przyspieszenie jest stałe lub zmienia się skokowo w nielicznych
 *    punktach), a nie ciągłą, zaszumioną krzywą jak przy realnym ruchu ręki.
 *
 * E. Rotation Variance (specyfikacja: "rotation variance" jawnie wymieniona)
 *    Wariancja SAMEJ prędkości rotacji (nie tylko przyspieszenia jak w B) w
 *    dłuższym oknie — wykrywa boty utrzymujące stałą "prędkość śledzenia"
 *    celu (constant-speed tracking), co jest odrębną sygnaturą od
 *    "gładkiego przyspieszenia" (B) i od "identycznego kroku" (GCD, A).
 */
public class AimBotCheck extends Check {

    private static final int GCD_SAMPLE_MIN = 30;
    private static final double GCD_MIN_ROTATION = 0.05; // filtr szumu — poniżej tego rotacja jest pomijana w GCD
    private static final int SMOOTH_WINDOW = 20;
    private static final double SNAP_THRESHOLD = 45.0; // stopnie na tick
    /** Współczynnik zmienności (SD/mean) poniżej tego progu = podejrzanie gładko, przy odpowiednio dużym ruchu. */
    private static final double SMOOTH_CV_THRESHOLD = 0.08;
    /** Minimalna średnia wielkość ruchu w oknie, żeby smoothness check w ogóle miał sens statystyczny. */
    private static final double SMOOTH_MIN_MEAN_MOVEMENT = 1.5;
    /** Po snapie, jak blisko finalna rotacja musi być celu ataku, żeby uznać to za "idealne domknięcie". */
    private static final double SNAP_LOCK_TOLERANCE_DEGREES = 2.0;
    private static final int JERK_WINDOW = 15;
    /** Poniżej tego jerku przy odpowiednio dużym ruchu — podejrzanie "gładkie" przyspieszenie (interpolacja, nie ręka). */
    private static final double JERK_CV_THRESHOLD = 0.06;
    private static final double JERK_MIN_MEAN_MOVEMENT = 2.0;
    private static final int VARIANCE_WINDOW = 20;
    /** Bardzo niska wariancja prędkości rotacji przy odpowiednio dużej prędkości = stałe tempo śledzenia (bot). */
    private static final double VARIANCE_CV_THRESHOLD = 0.05;
    private static final double VARIANCE_MIN_MEAN_SPEED = 3.0;

    private final ArrayDeque<Float> yawHistory = new ArrayDeque<>(32);
    private final ArrayDeque<Float> pitchHistory = new ArrayDeque<>(32);

    private long gcdYaw = 0;
    private long gcdPitch = 0;
    private int gcdCount = 0;
    /** Wynik poprzedniego okna GCD — do wymogu spójności w dwóch kolejnych oknach. */
    private String previousGcdReason = null;

    /** Ostatni zarejestrowany duży obrót (snap) — czekamy na kolejny atak, żeby sprawdzić domknięcie. */
    private boolean pendingSnap = false;
    private float snapEndYaw = 0f;
    private float snapEndPitch = 0f;

    public AimBotCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "Aimbot");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.1;
        this.vlDecayMultiplier = 0.97;
        this.flagThreshold = 4.0;
        this.setbackThreshold = Double.MAX_VALUE;
        this.requiredBuffer = 2;
        this.maxBuffer = 15;
    }

    /**
     * Wołane na każdym pakiecie POSITION_LOOK lub LOOK.
     */
    public void onRotation(float newYaw, float newPitch) {
        if (tickExemption()) return;

        float deltaYaw = Math.abs(normalizeAngle(newYaw - data.lastYaw));
        float deltaPitch = Math.abs(newPitch - data.lastPitch);

        // ── A. GCD Analysis (z filtrem szumu i wymogiem spójności dwóch okien) ──
        if (deltaYaw > GCD_MIN_ROTATION && deltaPitch > GCD_MIN_ROTATION) {
            long rawYaw = Math.round(deltaYaw * 1_000_000L);
            long rawPitch = Math.round(deltaPitch * 1_000_000L);

            gcdYaw = gcd(gcdYaw == 0 ? rawYaw : gcdYaw, rawYaw);
            gcdPitch = gcd(gcdPitch == 0 ? rawPitch : gcdPitch, rawPitch);
            gcdCount++;
        }

        if (gcdCount >= GCD_SAMPLE_MIN) {
            checkGcd();
            gcdYaw = 0;
            gcdPitch = 0;
            gcdCount = 0;
        }

        // ── B. Rotation Smoothness (współczynnik zmienności, nie surowe SD) ──
        yawHistory.addLast(deltaYaw);
        pitchHistory.addLast(deltaPitch);
        if (yawHistory.size() > SMOOTH_WINDOW) yawHistory.pollFirst();
        if (pitchHistory.size() > SMOOTH_WINDOW) pitchHistory.pollFirst();

        if (yawHistory.size() >= SMOOTH_WINDOW) {
            checkSmoothness();
        }

        // ── D. Jerk Analysis ─────────────────────────────────────────────────
        if (yawHistory.size() >= JERK_WINDOW) {
            checkJerk();
        }

        // ── E. Rotation Variance ─────────────────────────────────────────────
        if (yawHistory.size() >= VARIANCE_WINDOW) {
            checkRotationVariance();
        }

        // ── C. Snap Detection (rejestracja — weryfikacja domknięcia przy ataku) ──
        if (deltaYaw > SNAP_THRESHOLD || deltaPitch > SNAP_THRESHOLD) {
            pendingSnap = true;
            snapEndYaw = newYaw;
            snapEndPitch = newPitch;
        } else if (pendingSnap) {
            // Rotacja kontynuowała się po snapie (gracz jeszcze doszlifowuje celowanie
            // ręcznie) — aktualizujemy punkt końcowy zamiast gubić informację o snapie,
            // ale tylko przez krótką chwilę zanim onAttack go skonsumuje lub wygaśnie.
            snapEndYaw = newYaw;
            snapEndPitch = newPitch;
        }
    }

    /**
     * Wołane gdy gracz atakuje. Snap flaguje TYLKO jeśli finalna rotacja po
     * dużym obrocie idealnie domyka się na celu ataku — to jest właściwa
     * sygnatura snap-aimbota (auto-lock), nie sam fakt szybkiego obrotu
     * (który jest normalny przy przełączaniu celu w realnej walce).
     */
    /** Wołane bez CombatContext (kompatybilność wsteczna) — tworzy jednorazowy, odrzucany kontekst. */
    public void onAttack(Entity target) {
        onAttack(target, new CombatContext());
    }

    /**
     * Wołane gdy gracz atakuje. Snap flaguje TYLKO jeśli finalna rotacja po
     * dużym obrocie idealnie domyka się na celu ataku. Zapisuje wynik do
     * wspólnego CombatContext dla korelacji z KillAuraCheck (przegląd,
     * punkt 🔴2).
     */
    public void onAttack(Entity target, CombatContext context) {
        if (!pendingSnap) return;
        pendingSnap = false;

        if (target == null) return;

        double angleError = angleToEntity(target, snapEndYaw, snapEndPitch);
        if (angleError <= SNAP_LOCK_TOLERANCE_DEGREES) {
            context.aimBotSnapAnomaly = true;
            buffer(2.5, String.format("sub:Snap angleError:%.2f tolerance:%.1f", angleError, SNAP_LOCK_TOLERANCE_DEGREES));
        }
    }

    // ── GCD check ─────────────────────────────────────────────────────────────

    private void checkGcd() {
        if (gcdYaw == 0 || gcdPitch == 0 || gcdCount < GCD_SAMPLE_MIN) {
            previousGcdReason = null;
            return;
        }

        boolean suspiciouslyLow = gcdYaw <= 1 || gcdPitch <= 1;
        boolean exactlySame = gcdYaw == gcdPitch;
        boolean impossiblyClean = gcdYaw % 1000 == 0 && gcdPitch % 1000 == 0;

        String reason = suspiciouslyLow ? "infinite_precision"
            : exactlySame ? "locked_sensitivity"
            : impossiblyClean ? "clean_multiple"
            : null;

        if (reason != null && reason.equals(previousGcdReason)) {
            // Ta sama podejrzana sygnatura w DWÓCH kolejnych, niezależnych oknach —
            // znacznie mniej podatne na przypadkową jednorazową zbieżność.
            buffer(2.0, String.format("sub:GCD gcdY:%d gcdP:%d n:%d reason:%s (confirmed x2)",
                gcdYaw, gcdPitch, gcdCount, reason));
        } else if (reason == null) {
            reward();
        }

        previousGcdReason = reason;
    }

    // ── Smoothness check ─────────────────────────────────────────────────────

    private void checkSmoothness() {
        float[] yaws = toArray(yawHistory);

        double meanMovement = mean(toDoubleArray(yaws));
        if (meanMovement < SMOOTH_MIN_MEAN_MOVEMENT) {
            // Ruch zbyt mały, żeby naturalny jitter miał się gdzie ujawnić —
            // sub-check pomijany zamiast fałszywie flagować bierne/powolne celowanie.
            return;
        }

        double[] accel = new double[yaws.length - 1];
        for (int i = 1; i < yaws.length; i++) {
            accel[i - 1] = yaws[i] - yaws[i - 1];
        }

        double mean = mean(accel);
        double sd = standardDeviation(accel, mean);
        double cv = meanMovement > 0 ? sd / meanMovement : 1.0;

        if (cv < SMOOTH_CV_THRESHOLD) {
            buffer(1.0, String.format("sub:Smoothness cv:%.4f meanMovement:%.3f", cv, meanMovement));
        } else {
            reward();
        }
    }

    // ── Jerk check (trzecia pochodna rotacji) ──────────────────────────────────

    private void checkJerk() {
        float[] yaws = toArray(yawHistory);
        double meanMovement = mean(toDoubleArray(yaws));
        if (meanMovement < JERK_MIN_MEAN_MOVEMENT) {
            // Zbyt mały ruch — jerk nie ma się gdzie ujawnić, pomijamy zamiast
            // fałszywie flagować powolne/bierne celowanie (ta sama logika co checkSmoothness).
            return;
        }

        // Przyspieszenie (pierwsza różnica delt), potem jerk (druga różnica delt).
        double[] accel = new double[yaws.length - 1];
        for (int i = 1; i < yaws.length; i++) {
            accel[i - 1] = yaws[i] - yaws[i - 1];
        }
        double[] jerk = new double[accel.length - 1];
        for (int i = 1; i < accel.length; i++) {
            jerk[i - 1] = Math.abs(accel[i] - accel[i - 1]);
        }

        double meanJerk = mean(jerk);
        double sdJerk = standardDeviation(jerk, meanJerk);
        double cv = meanJerk > 0 ? sdJerk / meanJerk : 1.0;

        if (cv < JERK_CV_THRESHOLD) {
            buffer(1.0, String.format("sub:Jerk cv:%.4f meanJerk:%.4f meanMovement:%.3f", cv, meanJerk, meanMovement));
        } else {
            reward();
        }
    }

    // ── Rotation variance check (wariancja prędkości, nie przyspieszenia) ──────

    private void checkRotationVariance() {
        float[] yaws = toArray(yawHistory);
        double[] speeds = toDoubleArray(yaws); // deltaYaw per tick JEST już prędkością rotacji

        double meanSpeed = mean(speeds);
        if (meanSpeed < VARIANCE_MIN_MEAN_SPEED) {
            return;
        }

        double sd = standardDeviation(speeds, meanSpeed);
        double cv = sd / meanSpeed;

        if (cv < VARIANCE_CV_THRESHOLD) {
            buffer(1.5, String.format("sub:RotationVariance cv:%.4f meanSpeed:%.3f", cv, meanSpeed));
        } else {
            reward();
        }
    }

    // ── Pomocniki ─────────────────────────────────────────────────────────────

    private double angleToEntity(Entity target, float yaw, float pitch) {
        double eyeHeight = target instanceof LivingEntity
            ? ((LivingEntity) target).getEyeHeight() : 0.9;

        double dx = target.getLocation().getX() - data.x;
        double dz = target.getLocation().getZ() - data.z;
        double dy = (target.getLocation().getY() + eyeHeight / 2.0) - (data.y + 1.62);

        double targetYaw = Math.toDegrees(Math.atan2(-dx, dz));
        double targetPitch = Math.toDegrees(-Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        double dyaw = Math.abs(normalizeAngle(yaw - (float) targetYaw));
        double dpitch = Math.abs(pitch - targetPitch);
        return Math.sqrt(dyaw * dyaw + dpitch * dpitch);
    }

    private static long gcd(long a, long b) {
        while (b != 0) { long t = b; b = a % b; a = t; }
        return Math.abs(a);
    }

    private static float normalizeAngle(float angle) {
        while (angle > 180) angle -= 360;
        while (angle < -180) angle += 360;
        return angle;
    }

    private static float[] toArray(ArrayDeque<Float> deque) {
        float[] arr = new float[deque.size()];
        int i = 0;
        for (float f : deque) arr[i++] = f;
        return arr;
    }

    private static double[] toDoubleArray(float[] arr) {
        double[] result = new double[arr.length];
        for (int i = 0; i < arr.length; i++) result[i] = arr[i];
        return result;
    }

    private static double mean(double[] arr) {
        double sum = 0;
        for (double d : arr) sum += d;
        return arr.length == 0 ? 0 : sum / arr.length;
    }

    private static double standardDeviation(double[] arr, double mean) {
        double sum = 0;
        for (double d : arr) sum += (d - mean) * (d - mean);
        return arr.length == 0 ? 0 : Math.sqrt(sum / arr.length);
    }

    @Override
    public void reset() {
        super.reset();
        yawHistory.clear();
        pitchHistory.clear();
        gcdYaw = 0;
        gcdPitch = 0;
        gcdCount = 0;
        previousGcdReason = null;
        pendingSnap = false;
    }
}
