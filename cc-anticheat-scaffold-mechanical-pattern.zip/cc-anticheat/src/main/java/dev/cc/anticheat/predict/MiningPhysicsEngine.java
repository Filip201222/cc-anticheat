/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.predict;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;

/**
 * cc-anticheat — MiningPhysicsEngine
 *
 * Oblicza oczekiwany czas łamania bloku zgodnie z formułą vanilla Minecraft,
 * uwzględniając narzędzie, jego enchanty (Efficiency, Silk Touch/Fortune nie
 * wpływają na czas), efekty mikstur (Haste, Mining Fatigue, Conduit Power),
 * hardness bloku, medium (woda/powietrze/na ziemi), oraz to, czy narzędzie
 * jest "właściwe" dla danego bloku (co daje 1/3 czasu zamiast 1/1.5).
 *
 * Formuła vanilla (uproszczona, ale kompletna dla naszych celów):
 *   1. baseSpeed = 1.0 (gołe ręce) lub wartość bazowa narzędzia (patrz toolSpeed)
 *   2. Jeśli narzędzie jest właściwe dla bloku: speed = baseSpeed, inaczej speed = 1.0
 *   3. Efficiency: speed += level^2 + 1 (jeśli narzędzie jest właściwe LUB Efficiency
 *      działa też na niewłaściwe narzędzia w niektórych przypadkach — pomijamy ten
 *      brzeżny wyjątek dla uproszczenia, jest kosmetyczny dla anticheat)
 *   4. Haste: speed *= 1 + 0.2 * (level) — a ściślej: speed *= 1 + 0.2*(hasteAmplifier+1)
 *      dla Haste i Conduit Power (te dwa się nie sumują, bierzemy wyższy)
 *   5. Mining Fatigue: speed *= 0.3^min(amplifier+1, 4) (przybliżenie tabeli vanilla:
 *      poziom 1 = *0.3, poziom 2 = *0.09, poziom 3 = *0.027, poziom 4+ = *0.0081)
 *   6. Jeśli gracz nie jest na ziemi (w powietrzu, spada): speed /= 5
 *   7. Jeśli gracz jest w wodzie bez Aqua Affinity: speed /= 5
 *   8. damage = speed / hardness / (correctTool ? 30.0 : 100.0) — a dokładniej:
 *      jeśli narzędzie NIE jest właściwe LUB gracz nie może dropić bloku gołymi
 *      rękami, dzielimy przez większy próg (blok "twardszy" do przebicia)
 *
 * Czas łamania (w tickach) = ceil(1.0 / damagePerTick), z wyjątkiem instant-break
 * (damage >= 1.0 na pierwszy tick — blok pęka natychmiast, np. trawa złotą motyką).
 */
public final class MiningPhysicsEngine {

    private MiningPhysicsEngine() {}

    public static final class MiningResult {
        /** Oczekiwany czas łamania w milisekundach. */
        public final double expectedMs;
        /** Czy blok powinien pęknąć natychmiast (instant break, damage >= 1.0 pierwszego ticka). */
        public final boolean instantBreak;
        /** Czy narzędzie jest "właściwe" dla tego bloku (wpływa na drop, nie tylko czas). */
        public final boolean correctTool;

        MiningResult(double expectedMs, boolean instantBreak, boolean correctTool) {
            this.expectedMs = expectedMs;
            this.instantBreak = instantBreak;
            this.correctTool = correctTool;
        }
    }

    /**
     * Oblicza oczekiwany czas złamania danego bloku przez gracza, uwzględniając
     * cały kontekst wymieniony w klasowym javadocu.
     */
    public static MiningResult computeBreakTime(Player player, Block block, boolean onGround) {
        Material blockType = block.getType();
        float hardness = block.getType().getHardness();

        if (hardness < 0) {
            // Bedrock i podobne (hardness = -1) — nie do złamania w survivalu.
            return new MiningResult(Double.MAX_VALUE, false, false);
        }

        if (hardness == 0.0f) {
            // Trawa, kwiaty, płytki śniegu warstwa 1 itd. — zawsze instant break.
            return new MiningResult(0.0, true, true);
        }

        ItemStack tool = player.getInventory().getItemInMainHand();
        boolean correctTool = isCorrectToolForDrops(tool, blockType);
        boolean canHarvest = correctTool || !requiresToolToHarvest(blockType);

        double speed = baseToolSpeed(tool, blockType);

        int efficiencyLevel = tool != null ? tool.getEnchantmentLevel(Enchantment.EFFICIENCY) : 0;
        if (efficiencyLevel > 0) {
            speed += (double) (efficiencyLevel * efficiencyLevel) + 1.0;
        }

        double hasteMultiplier = hasteOrConduitMultiplier(player);
        speed *= hasteMultiplier;

        double fatigueMultiplier = miningFatigueMultiplier(player);
        speed *= fatigueMultiplier;

        if (!onGround) {
            speed /= 5.0;
        }
        if (isInWaterWithoutAquaAffinity(player)) {
            speed /= 5.0;
        }

        double divisor = canHarvest ? 30.0 : 100.0;
        double damagePerTick = speed / hardness / divisor;

        if (damagePerTick >= 1.0) {
            return new MiningResult(0.0, true, correctTool);
        }

        double ticksNeeded = Math.ceil(1.0 / damagePerTick);
        double ms = ticksNeeded * 50.0;
        return new MiningResult(ms, false, correctTool);
    }

    /**
     * Bazowa prędkość narzędzia dla danego bloku, PRZED uwzględnieniem
     * enchantów/efektów. Jeśli narzędzie nie jest odpowiedniego typu dla
     * bloku (np. kilof na drewno), zwracamy 1.0 (jak gołe ręce) zgodnie
     * z vanilla — niewłaściwe narzędzie nie daje bonusu prędkości.
     */
    private static double baseToolSpeed(ItemStack tool, Material blockType) {
        if (tool == null || tool.getType() == Material.AIR) return 1.0;
        if (!isEffectiveToolCategory(tool.getType(), blockType)) return 1.0;

        String name = tool.getType().name();
        double tierSpeed;
        if (name.startsWith("WOODEN_") || name.startsWith("GOLDEN_")) {
            // Złoto ma wysoką bazową prędkość mimo niskiej trwałości/tier wydobycia.
            tierSpeed = name.startsWith("GOLDEN_") ? 12.0 : 2.0;
        } else if (name.startsWith("STONE_")) {
            tierSpeed = 4.0;
        } else if (name.startsWith("IRON_")) {
            tierSpeed = 6.0;
        } else if (name.startsWith("DIAMOND_")) {
            tierSpeed = 8.0;
        } else if (name.startsWith("NETHERITE_")) {
            tierSpeed = 9.0;
        } else {
            tierSpeed = 1.0; // gołe ręce lub nierozpoznane narzędzie
        }
        return tierSpeed;
    }

    /** Czy dana kategoria narzędzia (kilof/siekiera/łopata/miecz/nożyce) jest efektywna dla tego bloku. */
    private static boolean isEffectiveToolCategory(Material toolType, Material blockType) {
        String toolName = toolType.name();
        boolean isPickaxe = toolName.endsWith("_PICKAXE");
        boolean isAxe = toolName.endsWith("_AXE") && !toolName.endsWith("_PICKAXE");
        boolean isShovel = toolName.endsWith("_SHOVEL");
        boolean isHoe = toolName.endsWith("_HOE");
        boolean isShears = toolType == Material.SHEARS;

        if (isPickaxe) return isPickaxeBlock(blockType);
        if (isAxe) return isAxeBlock(blockType);
        if (isShovel) return isShovelBlock(blockType);
        if (isHoe) return isHoeBlock(blockType);
        if (isShears) return isShearsBlock(blockType);
        return false;
    }

    private static boolean isPickaxeBlock(Material type) {
        String n = type.name();
        return n.contains("STONE") || n.contains("ORE") || n.contains("IRON")
            || n.contains("GOLD") || n.contains("DIAMOND") || n.contains("NETHERITE")
            || n.contains("OBSIDIAN") || n.contains("CONCRETE") || n.contains("TERRACOTTA")
            || n.contains("BASALT") || n.contains("DEEPSLATE") || n.contains("RAIL")
            || n.contains("ANVIL") || n.contains("BRICK") || n.contains("COPPER");
    }

    private static boolean isAxeBlock(Material type) {
        String n = type.name();
        return n.contains("LOG") || n.contains("WOOD") || n.contains("PLANKS")
            || (n.contains("STAIRS") && isWoodenVariant(n)) || n.contains("FENCE") || n.contains("DOOR")
            || n.contains("PUMPKIN") || n.contains("MELON") || n.contains("BOOKSHELF")
            || n.contains("BEEHIVE") || n.contains("BEE_NEST");
    }

    /** Rozróżnia drewniane warianty bloków (schody/płoty/drzwi) od kamiennych, w oparciu o nazwę materiału. */
    private static boolean isWoodenVariant(String materialName) {
        return materialName.contains("OAK") || materialName.contains("SPRUCE")
            || materialName.contains("BIRCH") || materialName.contains("JUNGLE")
            || materialName.contains("ACACIA") || materialName.contains("DARK_OAK")
            || materialName.contains("MANGROVE") || materialName.contains("CHERRY")
            || materialName.contains("BAMBOO") || materialName.contains("CRIMSON")
            || materialName.contains("WARPED");
    }

    private static boolean isShovelBlock(Material type) {
        return type == Material.DIRT || type == Material.GRASS_BLOCK || type == Material.SAND
            || type == Material.GRAVEL || type == Material.CLAY || type == Material.SNOW
            || type == Material.SNOW_BLOCK || type == Material.SOUL_SAND || type == Material.SOUL_SOIL
            || type == Material.MYCELIUM || type == Material.PODZOL || type == Material.MUD
            || type == Material.ROOTED_DIRT || type == Material.FARMLAND;
    }

    private static boolean isHoeBlock(Material type) {
        String n = type.name();
        return n.contains("LEAVES") || n.contains("HAY_BLOCK") || n.contains("SPONGE")
            || n.contains("NETHER_WART") || n.contains("MOSS") || n.contains("SCULK") && !n.contains("SHRIEKER") && !n.contains("CATALYST");
    }

    private static boolean isShearsBlock(Material type) {
        String n = type.name();
        return n.contains("WOOL") || n.contains("LEAVES") || n.contains("VINE")
            || n.contains("COBWEB") || n.equals("COBWEB");
    }

    /**
     * Czy blok WYMAGA narzędzia do zdropienia (a nie tylko do przyspieszenia
     * kopania) — np. kamień wymaga kilofa, ziemia nie wymaga niczego.
     */
    private static boolean requiresToolToHarvest(Material type) {
        String n = type.name();
        return n.contains("ORE") || n.contains("STONE") || n.contains("OBSIDIAN")
            || n.contains("CONCRETE") || n.equals("ANCIENT_DEBRIS") || n.contains("NETHERITE");
    }

    /**
     * Uproszczona heurystyka "czy narzędzie jest właściwe dla dropów tego bloku"
     * — dla naszych potrzeb (czas kopania) traktujemy to tożsamo z kategorią
     * narzędzia efektywną dla bloku.
     */
    private static boolean isCorrectToolForDrops(ItemStack tool, Material blockType) {
        if (tool == null) return false;
        return isEffectiveToolCategory(tool.getType(), blockType);
    }

    /**
     * Haste i Conduit Power dają ten sam bonus prędkości (+20% na poziom) i
     * NIE sumują się w vanilla — bierzemy wyższy z dwóch dostępnych poziomów.
     */
    private static double hasteOrConduitMultiplier(Player player) {
        int hasteLevel = 0;
        if (player.hasPotionEffect(PotionEffectType.HASTE)) {
            hasteLevel = player.getPotionEffect(PotionEffectType.HASTE).getAmplifier() + 1;
        }
        int conduitLevel = 0;
        if (player.hasPotionEffect(PotionEffectType.CONDUIT_POWER)) {
            conduitLevel = player.getPotionEffect(PotionEffectType.CONDUIT_POWER).getAmplifier() + 1;
        }
        int effectiveLevel = Math.max(hasteLevel, conduitLevel);
        return 1.0 + 0.2 * effectiveLevel;
    }

    /**
     * Mining Fatigue redukuje prędkość kopania wykładniczo: *0.3 na poziom,
     * ograniczone do poziomu 4 (przy wyższych poziomach efekt się nie pogłębia
     * dalej w praktyce gry, choć teoretycznie mnożnik dalej maleje — vanilla
     * ogranicza wizualnie/mechanicznie w okolicach tej wartości).
     */
    private static double miningFatigueMultiplier(Player player) {
        if (!player.hasPotionEffect(PotionEffectType.MINING_FATIGUE)) return 1.0;
        int amplifier = player.getPotionEffect(PotionEffectType.MINING_FATIGUE).getAmplifier();
        int level = Math.min(amplifier + 1, 4);
        return Math.pow(0.3, level);
    }

    /**
     * Czy gracz jest w wodzie BEZ hełmu z Aqua Affinity — w takim wypadku
     * kopanie jest 5x wolniejsze (poza sytuacjami, gdy Aqua Affinity to neguje).
     */
    private static boolean isInWaterWithoutAquaAffinity(Player player) {
        boolean inWater = player.getEyeLocation().getBlock().getType() == Material.WATER
            || player.isSwimming();
        if (!inWater) return false;

        ItemStack helmet = player.getInventory().getHelmet();
        boolean hasAquaAffinity = helmet != null
            && helmet.getEnchantmentLevel(Enchantment.AQUA_AFFINITY) > 0;
        return !hasAquaAffinity;
    }
}
