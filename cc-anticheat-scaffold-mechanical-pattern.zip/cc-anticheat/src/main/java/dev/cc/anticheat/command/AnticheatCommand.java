/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.command;

import dev.cc.anticheat.CCAnticheat;
import dev.cc.anticheat.bait.BaitEspManager;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.gui.PlayerInfoGUI;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /anticheat <info|reload|verbose|stats|alert|alertgui|spectate|bait>
 */
public class AnticheatCommand implements CommandExecutor, TabCompleter {

    private final CCAnticheat plugin;

    public AnticheatCommand(CCAnticheat plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("ccanticheat.admin")) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }

        String header = ChatColor.DARK_GRAY + "[" + ChatColor.AQUA + "cc-anticheat" + ChatColor.DARK_GRAY + "] ";

        if (args.length == 0 || args[0].equalsIgnoreCase("info")) {
            sender.sendMessage(header + ChatColor.WHITE + "cc-anticheat v" + plugin.getDescription().getVersion());
            sender.sendMessage(ChatColor.GRAY + "  Combat:   " + ChatColor.GREEN + "Intave-model (click patterns, KillAura, AimBot, Reach)");
            sender.sendMessage(ChatColor.GRAY + "  Movement: " + ChatColor.GREEN + "Grim-model (timer, flight, velocity)");
            sender.sendMessage(ChatColor.GRAY + "  Players online: " + ChatColor.WHITE + Bukkit.getOnlinePlayers().size());
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload":
                plugin.reloadConfig();
                sender.sendMessage(header + ChatColor.GREEN + "Config reloaded.");
                break;

            case "verbose":
                handleVerbose(sender, header, args);
                break;

            case "stats":
                handleStats(sender, header);
                break;

            case "alert":
                handleAlertToggle(sender);
                break;

            case "alertgui":
                handleAlertGui(sender, args);
                break;

            case "spectate":
                handleSpectate(sender, args);
                break;

            case "bait":
                handleBait(sender, args);
                break;

            default:
                sender.sendMessage(header + ChatColor.RED + "Unknown sub-command. Use: info, reload, verbose, stats, alert, alertgui, spectate, bait");
        }
        return true;
    }

    // ── Sub-command handlers ────────────────────────────────────────────────

    private void handleVerbose(CommandSender sender, String header, String[] args) {
        if (args.length < 2) { sender.sendMessage(header + ChatColor.RED + "Usage: /anticheat verbose <player>"); return; }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { sender.sendMessage(header + ChatColor.RED + "Player not found."); return; }
        PlayerData data = plugin.getCheckManager().getData(target);
        if (data == null) { sender.sendMessage(header + ChatColor.RED + "No data."); return; }
        sender.sendMessage(header + ChatColor.YELLOW + target.getName() + ChatColor.GRAY + " verbose:");
        sender.sendMessage(ChatColor.GRAY + "  ClickPattern: " + ChatColor.WHITE + f(plugin.getCheckManager().getCheckVl(target, "clickpattern")));
        sender.sendMessage(ChatColor.GRAY + "  KillAura: " + ChatColor.WHITE + f(plugin.getCheckManager().getCheckVl(target, "killaura"))
            + ChatColor.GRAY + "  AimBot: " + ChatColor.WHITE + f(plugin.getCheckManager().getCheckVl(target, "aimbot")));
        sender.sendMessage(ChatColor.GRAY + "  Reach: " + ChatColor.WHITE + f(plugin.getCheckManager().getCheckVl(target, "reach"))
            + ChatColor.GRAY + "  Flight: " + ChatColor.WHITE + f(plugin.getCheckManager().getCheckVl(target, "flight")));
        sender.sendMessage(ChatColor.GRAY + "  Timer: " + ChatColor.WHITE + f(plugin.getCheckManager().getCheckVl(target, "timer"))
            + ChatColor.GRAY + "  Velocity: " + ChatColor.WHITE + f(plugin.getCheckManager().getCheckVl(target, "velocity")));
        sender.sendMessage(ChatColor.GRAY + "  BoatFly: " + ChatColor.WHITE + f(plugin.getCheckManager().getCheckVl(target, "boatfly"))
            + ChatColor.GRAY + "  AutoTotem: " + ChatColor.WHITE + f(plugin.getCheckManager().getCheckVl(target, "autototem")));
        sender.sendMessage(ChatColor.GRAY + "  GlobalPts: " + ChatColor.WHITE + f(plugin.getCheckManager().getGlobalPoints(target)));
    }

    private void handleStats(CommandSender sender, String header) {
        sender.sendMessage(header + ChatColor.WHITE + "Online players:");
        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerData d = plugin.getCheckManager().getData(p);
            if (d == null) continue;
            double points = plugin.getCheckManager().getGlobalPoints(p);
            String color = points > 20 ? "" + ChatColor.RED : points > 5 ? "" + ChatColor.YELLOW : "" + ChatColor.GREEN;
            sender.sendMessage(ChatColor.GRAY + "  " + p.getName() + " → globalPts:" + color + f(points));
        }
    }

    /** /anticheat alert — toggles the sender's own alert stream on/off. */
    private void handleAlertToggle(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Tylko gracze mogą przełączać alerty.");
            return;
        }
        Player staff = (Player) sender;
        boolean nowOn = plugin.getAlertManager().toggle(staff);
        plugin.getAlertManager().sendTo(staff, nowOn
                ? ChatColor.GREEN + "alerty włączone"
                : ChatColor.RED + "alerty wyłączone");
    }

    /** /anticheat alertgui <player> — opens the player-info GUI. */
    private void handleAlertGui(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Tylko gracze mogą otwierać GUI.");
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Użycie: /anticheat alertgui <gracz>");
            return;
        }
        Player staff = (Player) sender;
        String targetName = resolveName(args[1]);
        PlayerInfoGUI gui = new PlayerInfoGUI(plugin, targetName);
        staff.openInventory(gui.getInventory());
    }

    /** /anticheat spectate <player> — teleports staff into spectator mode on the target. */
    private void handleSpectate(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Tylko gracze mogą używać spectate.");
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Użycie: /anticheat spectate <gracz>");
            return;
        }
        Player staff = (Player) sender;
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            plugin.getAlertManager().sendTo(staff, ChatColor.RED + "Gracz nie jest online.");
            return;
        }
        boolean nowSpectating = plugin.getSpectateManager().toggleSpectate(staff, target);
        plugin.getAlertManager().sendTo(staff, nowSpectating
                ? ChatColor.GREEN + "Obserwujesz " + ChatColor.WHITE + target.getName()
                : ChatColor.YELLOW + "Zakończono obserwację.");
    }

    /** /anticheat bait esp <up|down|stop> <player> */
    private void handleBait(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Tylko gracze mogą używać bait.");
            return;
        }
        Player staff = (Player) sender;

        if (args.length < 4 || !args[1].equalsIgnoreCase("esp")) {
            plugin.getAlertManager().sendTo(staff, ChatColor.RED + "Użycie: /anticheat bait esp <up|down|stop> <gracz>");
            return;
        }

        String mode = args[2].toLowerCase();
        Player viewer = Bukkit.getPlayer(args[3]);
        if (viewer == null) {
            plugin.getAlertManager().sendTo(staff, ChatColor.RED + "Gracz nie jest online.");
            return;
        }

        BaitEspManager bait = plugin.getBaitEspManager();
        switch (mode) {
            case "up":
                bait.start(viewer, BaitEspManager.Direction.UP);
                plugin.getAlertManager().sendTo(staff, ChatColor.GREEN + "Bait ESP (góra) uruchomiony dla "
                        + ChatColor.WHITE + viewer.getName());
                break;
            case "down":
                bait.start(viewer, BaitEspManager.Direction.DOWN);
                plugin.getAlertManager().sendTo(staff, ChatColor.GREEN + "Bait ESP (dół) uruchomiony dla "
                        + ChatColor.WHITE + viewer.getName());
                break;
            case "stop":
                boolean stopped = bait.stop(viewer);
                plugin.getAlertManager().sendTo(staff, stopped
                        ? ChatColor.YELLOW + "Bait ESP zatrzymany."
                        : ChatColor.GRAY + "Nie było aktywnego baita dla tego gracza.");
                break;
            default:
                plugin.getAlertManager().sendTo(staff, ChatColor.RED + "Użycie: /anticheat bait esp <up|down|stop> <gracz>");
        }
    }

    /** Resolves online-player-or-literal-name (offline players can still be looked up in the GUI). */
    private String resolveName(String input) {
        Player online = Bukkit.getPlayer(input);
        return online != null ? online.getName() : input;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            return Arrays.asList("info", "reload", "verbose", "stats", "alert", "alertgui", "spectate", "bait").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (sub.equals("verbose") || sub.equals("stats") || sub.equals("alertgui") || sub.equals("spectate")) {
                return onlinePlayerNames(args[1]);
            }
            if (sub.equals("bait")) {
                return filterStarts(List.of("esp"), args[1]);
            }
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("bait")) {
            return filterStarts(List.of("up", "down", "stop"), args[2]);
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("bait")) {
            return onlinePlayerNames(args[3]);
        }
        return List.of();
    }

    private List<String> onlinePlayerNames(String prefix) {
        return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                .filter(n -> n.toLowerCase().startsWith(prefix.toLowerCase())).collect(Collectors.toList());
    }

    private List<String> filterStarts(List<String> options, String prefix) {
        List<String> out = new ArrayList<>();
        for (String o : options) if (o.startsWith(prefix.toLowerCase())) out.add(o);
        return out;
    }

    private static String f(double v) { return String.format("%.1f", v); }
}
