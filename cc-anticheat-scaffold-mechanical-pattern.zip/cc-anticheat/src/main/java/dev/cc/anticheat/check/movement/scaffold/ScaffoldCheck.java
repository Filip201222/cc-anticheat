/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.movement.scaffold;

import com.comphenix.protocol.wrappers.EnumWrappers;
import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.predict.RayTraceUtil;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;

/**
 * cc-anticheat — ScaffoldCheck
 *
 * Wykrywa Scaffold/Tower — automatyczne, botowe kładzenie bloków pod stopami
 * podczas chodzenia (scaffold) lub skakania w miejscu (tower).
 *
 * Sub-checki:
 *   A. Raytrace ray→plane na KONKRETNY block face + hit position 2D
 *      (NAPRAWA kolejnej iteracji przeglądu, punkty 1-2: "Usuń zależność od
 *      sztucznego FACE_SLAB_THICKNESS, zastąp matematycznym ray → plane
 *      intersection" + "odchylenie hit-vector liczone w 2D na powierzchni
 *      ściany, bez składowej wzdłuż normalnej"). Wcześniejsza wersja
 *      testowała promień przeciwko sztucznemu "plastrowi" 3D (bryła o małej
 *      grubości) i liczyła odchylenie punktu trafienia jako dystans 3D do
 *      środka ściany — to MIESZAŁO odchylenie boczne (faktycznie istotne:
 *      "czy kliknął blisko krawędzi") z odchyleniem wzdłuż normalnej
 *      (nieistotne dla oceny precyzji celowania — to tylko artefakt kąta
 *      padania promienia). Teraz: RayTraceUtil#intersectFace liczy
 *      dokładne przecięcie promienia z PŁASZCZYZNĄ danej ściany (2D,
 *      nieskończenie cienka), zwraca lokalne współrzędne U/V w [0,1] na
 *      powierzchni 1x1, a odchylenie od środka (0.5, 0.5) jest policzone
 *      WYŁĄCZNIE w tych dwóch osiach stycznych — składowa normalna nie
 *      istnieje w tym układzie współrzędnych, więc nie da się jej przypadkiem
 *      domieszać do wyniku. Trafienie w sąsiednią ścianę tego samego bloku
 *      (co przechodziłoby najstarszy test całego AABB) nadal nie wystarcza —
 *      U/V muszą mieścić się w granicach TEJ KONKRETNEJ powierzchni.
 *   B. Placement rhythm — bloki kładzione w idealnie równych odstępach
 *      czasowych, typowych dla auto-clickera/makra, a nie ręcznego kładzenia.
 *   C. Tower — FAZA SKOKU zamiast samego czasu (NAPRAWA 🟠, przegląd: "Tower
 *      → faza skoku zamiast samego czasu"). Poprzednia wersja mierzyła tylko
 *      CZAS między odbiciem a kładzeniem, co nie odróżnia "kładzenia w
 *      apogeum skoku" (legalne — gracz naturalnie czeka na szczyt trajektorii,
 *      żeby mieć miejsce na blok) od "kładzenia w losowym momencie trajektorii
 *      niezależnie od fazy skoku" (fizycznie dziwne — bot reaguje na stały
 *      interwał czasowy, nie na TO, GDZIE w trajektorii aktualnie jest gracz).
 *      Liczymy fazę skoku jako wysokość ponad start skoku znormalizowaną do
 *      przewidywanego apogeum (0 = start, 1 = szczyt) i wymagamy, żeby
 *      WARIANCJA FAZY (nie czasu) była podejrzanie niska — legalne tower ma
 *      naturalny rozrzut fazy, bo różne sytuacje/gracze czekają na nieco
 *      inny moment trajektorii.
 *   D. Sneak requirement — w vanilla, stawianie bloku bezpośrednio pod
 *      własnymi stopami podczas stania na krawędzi wymaga kucania (inaczej
 *      serwer odrzuca placement, bo gracz "wypchnąłby się" z pozycji before
 *      blok się pojawi) — Scaffold cheat często ignoruje ten wymóg, więc
 *      wielokrotne kładzenie bloków blisko stóp BEZ kucania jest sygnałem.
 *   E. Rotation/Movement Correlation (NAPRAWA 🟠, przegląd: "Scaffold
 *      correlation z rotation/movement") — łączy sygnały A-D z tego samego
 *      placementu w jeden wynik zamiast każdy sub-check niezależnie
 *      eskalujący swój VL: jeśli promień idealnie trafia w face ORAZ rytm
 *      jest podejrzanie regularny ORAZ ruch w tym samym oknie jest
 *      nienaturalnie stabilny (niska wariancja horizontalDistance w
 *      ostatnich kilku tickach, sygnatura "zamrożonego" ruchu podczas
 *      budowania) ORAZ faza tower jest podejrzanie stała, suma tych
 *      niezależnych sygnałów generuje SILNIEJSZĄ karę niż każdy z osobna.
 *
 * Zgodnie z pierwotną specyfikacją: "Sama regularność kliknięć lub
 * placementów nie może być wystarczającym dowodem" — dlatego żaden
 * pojedynczy sub-check nie eskaluje natychmiast do wysokiego VL, a
 * interpretacja "regularność = bot" jest zawsze łączona z drugim wymiarem
 * (rytm + geometria + ruch, nie sam rytm) — sub-check E to formalizuje.
 */
public class ScaffoldCheck extends Check {

    private static final int RHYTHM_WINDOW = 8;
    private static final double RHYTHM_CV_THRESHOLD = 0.05; // bardzo niska zmienność = bot
    /** Maksymalny zasięg raytrace na block face — zgodny z zasięgiem interakcji vanilla (~4.5 bloku, z marginesem). */
    private static final double RAYTRACE_MAX_DISTANCE = 5.0;

    private static final int TOWER_SAMPLE_MIN = 5;
    private static final double TOWER_PHASE_CV_THRESHOLD = 0.08;
    /** Ile ticków tolerancji na "naturalne opóźnienie reakcji" między odbiciem a kładzeniem podczas tower. */
    private static final long TOWER_TIMING_WINDOW_MS = 600L;
    /** Przybliżona wysokość skoku vanilla (bez Jump Boost) — używana do normalizacji fazy trajektorii. */
    private static final double JUMP_APEX_HEIGHT = 1.25;

    private static final int NO_SNEAK_STREAK_THRESHOLD = 4;
    /** Próg sumy korelacyjnej sub-checka E, powyżej którego wynik jest wystarczająco silny by karać samodzielnie. */
    private static final double CORRELATION_THRESHOLD = 3.0;
    private static final int MOVEMENT_STABILITY_WINDOW = 5;
    private static final double MOVEMENT_STABILITY_CV_THRESHOLD = 0.04;
    /** Ile ostatnich placementów bierzemy pod uwagę przy ocenie systematycznego wyśrodkowania hit position. */
    private static final int HIT_DEVIATION_WINDOW = 6;
    /**
     * Powyżej jakiego odchylenia (w lokalnych jednostkach U/V — 0 = środek
     * ściany, 0.5 = krawędź) hit position uznajemy za "wyśrodkowane" — 0.15
     * to wyraźnie bliżej centrum niż typowe naturalne kliknięcie (które ma
     * spory rozrzut po całej widocznej powierzchni ściany).
     */
    private static final double HIT_CENTERED_THRESHOLD = 0.15;
    /** Poniżej tej wariancji (współczynnik zmienności) odchyleń w oknie — trafienia są PODEJRZANIE JEDNAKOWO wyśrodkowane, nie tylko przypadkiem blisko środka raz. */
    private static final double HIT_DEVIATION_CV_THRESHOLD = 0.25;

    // ── Sub-check F: movement → rotation → placement pattern (przegląd, punkt 4:
    // "Połącz placement z ruchem gracza... analizuj zależność movement → rotation
    // → placement... szczególnie wykrywaj powtarzające się, mechaniczne wzorce") ──
    /** Ile ostatnich pełnych snapshotów placementu przechowujemy do analizy wzorca. */
    private static final int PATTERN_HISTORY_SIZE = 10;
    /** Ile par kolejnych placementów musi wykazać "mechaniczną" powtarzalność (patrz isMechanicallyIdentical), zanim to przestaje być zbiegiem okoliczności. */
    private static final int MECHANICAL_PATTERN_MIN_REPEATS = 5;
    /** Tolerancja na różnicę yaw (stopnie) między kolejnymi placementami, żeby uznać rotację za "tę samą". */
    private static final double PATTERN_YAW_TOLERANCE = 1.0;
    /** Tolerancja na różnicę prędkości poziomej (bloki/tick) między kolejnymi placementami. */
    private static final double PATTERN_VELOCITY_TOLERANCE = 0.01;

    private final ArrayDeque<Long> placeDelays = new ArrayDeque<>(32);
    private long lastPlaceMs = 0L;
    private int perfectSnapStreak = 0;
    /** Historia hit position deviation z ostatnich placementów — patrz sub-check E, faktyczne wykorzystanie hit vector. */
    private final ArrayDeque<Double> hitDeviationHistory = new ArrayDeque<>(HIT_DEVIATION_WINDOW + 2);
    /** Pełna historia snapshotów placementu — patrz sub-check F. */
    private final ArrayDeque<PlacementSnapshot> placementHistory = new ArrayDeque<>(PATTERN_HISTORY_SIZE + 2);
    private int mechanicalPatternStreak = 0;

    /** Moment i pozycja Y odbicia od ziemi (do fazy skoku, sub-check C). */
    private long lastJumpMs = 0L;
    private double lastJumpStartY = 0;
    private final ArrayDeque<Double> towerJumpPhases = new ArrayDeque<>(16);
    private int noSneakPlacementStreak = 0;
    private final ArrayDeque<Double> recentHorizontalMovement = new ArrayDeque<>(MOVEMENT_STABILITY_WINDOW + 2);
    /** Ostatnia znana prędkość pozioma gracza — zasilana przez onMovement, konsumowana przy zapisie snapshotu placementu. */
    private double lastKnownHorizontalVelocity = 0;

    public ScaffoldCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "Scaffold");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.08;
        this.vlDecayMultiplier = 0.95;
        this.flagThreshold = 5.0;
        this.setbackThreshold = Double.MAX_VALUE; // Scaffold tylko flaguje/cancel, nie robi setbacku
        this.requiredBuffer = 2;
        this.maxBuffer = 15;
    }

    /**
     * Pełny snapshot pojedynczego placementu — wszystkie pola wymagane przez
     * przegląd (punkt 4): timestamp, player position, velocity, yaw, pitch,
     * block position, BlockFace, hit vector. Używany przez sub-check F do
     * wykrywania mechanicznych wzorców w SEKWENCJI placementów, nie tylko
     * pojedynczych statystyk (CV) per-sygnał jak w sub-checkach B/C/E.
     */
    private static final class PlacementSnapshot {
        final long timestampMs;
        final double playerX, playerY, playerZ;
        final double horizontalVelocity;
        final float yaw, pitch;
        final int blockX, blockY, blockZ;
        final String face;
        final double hitU, hitV;

        PlacementSnapshot(long timestampMs, double playerX, double playerY, double playerZ,
                           double horizontalVelocity, float yaw, float pitch,
                           int blockX, int blockY, int blockZ, String face, double hitU, double hitV) {
            this.timestampMs = timestampMs;
            this.playerX = playerX;
            this.playerY = playerY;
            this.playerZ = playerZ;
            this.horizontalVelocity = horizontalVelocity;
            this.yaw = yaw;
            this.pitch = pitch;
            this.blockX = blockX;
            this.blockY = blockY;
            this.blockZ = blockZ;
            this.face = face;
            this.hitU = hitU;
            this.hitV = hitV;
        }
    }

    /**
     * Wołane na każdym ticku ruchu — rejestruje moment/wysokość odbicia od
     * ziemi (dla fazy skoku, sub-check C) oraz zasila krótką historię ruchu
     * poziomego wykorzystywaną przez sub-check E (movement correlation).
     */
    public void onMovement(MovementData current) {
        boolean justJumped = !current.actuallyOnGround && current.deltaY > 0.3;
        if (justJumped) {
            lastJumpMs = System.currentTimeMillis();
            lastJumpStartY = current.y - current.deltaY; // pozycja Y PRZED odbiciem
        }

        double horizontalVelocity = current.horizontalDistance();
        recentHorizontalMovement.addLast(horizontalVelocity);
        while (recentHorizontalMovement.size() > MOVEMENT_STABILITY_WINDOW) recentHorizontalMovement.pollFirst();
        lastKnownHorizontalVelocity = horizontalVelocity;
    }

    /** Wołane bez pozycji bloku (kompatybilność wsteczna) — pomija raytrace (sub-check A), reszta działa normalnie. */
    public void onBlockPlace(Vector placedAgainst) {
        onBlockPlace(placedAgainst, Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE);
    }

    /** Wołane z pozycją bloku, ale bez jawnego face (kompatybilność wsteczna) — raytrace testuje cały blok. */
    public void onBlockPlace(Vector placedAgainst, int blockX, int blockY, int blockZ) {
        onBlockPlace(placedAgainst, blockX, blockY, blockZ, null);
    }

    /**
     * Wołane, gdy gracz kładzie blok bezpośrednio pod/obok siebie w trakcie
     * ruchu (scaffold) lub skoku w miejscu (tower).
     *
     * @param placedAgainst wektor od gracza do bloku, na którym kładziony jest nowy blok
     * @param blockX/Y/Z    współrzędne bloku, na którym stawiany jest nowy (dla raytrace, sub-check A)
     * @param face          konkretna ściana klikniętego bloku, wprost z pakietu BLOCK_PLACE (może być null jeśli nieznana)
     */
    public void onBlockPlace(Vector placedAgainst, int blockX, int blockY, int blockZ, EnumWrappers.Direction face) {
        if (tickExemption()) return;

        long now = System.currentTimeMillis();
        long delay = now - lastPlaceMs;
        lastPlaceMs = now;

        boolean placedBelow = placedAgainst.getY() < -0.3; // blok jest wyraźnie poniżej gracza

        // ── B. Placement rhythm ───────────────────────────────────────────
        double rhythmCv = Double.NaN;
        if (delay < 3000) { // ignorujemy zbyt duże przerwy (nie jest to sekwencja kładzenia)
            placeDelays.addLast(delay);
            while (placeDelays.size() > RHYTHM_WINDOW) placeDelays.pollFirst();

            if (placeDelays.size() >= RHYTHM_WINDOW) {
                double mean = mean(placeDelays);
                double sd = standardDeviation(placeDelays, mean);
                rhythmCv = mean > 0 ? sd / mean : 1.0;

                if (rhythmCv < RHYTHM_CV_THRESHOLD && mean < 400) {
                    buffer(1.5, String.format("sub:Rhythm cv:%.4f mean:%.1f", rhythmCv, mean));
                }
            }
        } else {
            placeDelays.clear();
        }

        // ── A. Raytrace na KONKRETNY block face + hit position (2D, na powierzchni ściany) ──
        // NAPRAWA (przegląd, punkty 1-2): poprzednia wersja budowała sztuczny
        // "plaster" 3D (FACE_SLAB_THICKNESS) testowany przez ray/AABB, a hit
        // position mierzyła jako odległość 3D punkt-do-punktu (co MIESZAŁO
        // odchylenie na powierzchni z odchyleniem wzdłuż normalnej — punkt
        // trafiony dokładnie w centrum, ale z promieniem lekko "wchodzącym"
        // pod kątem, dawał niezerowy dystans 3D nawet bez żadnego bocznego
        // przesunięcia). Zastąpione matematycznym ray→plane intersection
        // (RayTraceUtil#intersectFace): płaszczyzna DOKŁADNEJ ściany, punkt
        // przecięcia, współrzędne lokalne U/V sprawdzone względem granic
        // powierzchni 1x1 — a odchylenie od środka liczone WYŁĄCZNIE w
        // płaszczyźnie stycznej (2D: du, dv), bez składowej normalnej.
        boolean hasBlockPosition = blockX != Integer.MIN_VALUE;
        boolean raytraceHit = true; // domyślnie "nie flaguj", gdy nie mamy pozycji bloku (kompatybilność wsteczna)
        double hitPositionDeviation = 0.0;
        // Współrzędne U/V faktycznego trafienia — NaN jeśli nieznane (brak
        // pozycji bloku/face lub promień nie trafił w ogóle). Wyniesione na
        // poziom metody, żeby sub-check F (movement→rotation→placement
        // pattern) mógł zapisać PRAWDZIWE dane trafienia w PlacementSnapshot,
        // nie sztuczne stałe.
        double hitU = Double.NaN, hitV = Double.NaN;
        if (hasBlockPosition && face != null) {
            Vector eye = new Vector(data.x, data.y + 1.62, data.z);
            Vector direction = directionFromRotation(data.yaw, data.pitch);
            RayTraceUtil.PlaneHit hit = RayTraceUtil.intersectFace(
                eye, direction, blockX, blockY, blockZ, face.name(), RAYTRACE_MAX_DISTANCE);
            raytraceHit = hit.hit;

            if (raytraceHit) {
                // Odchylenie 2D na powierzchni ściany: środek to (u,v)=(0.5,0.5),
                // odległość liczona TYLKO w płaszczyźnie stycznej — bez żadnej
                // składowej wzdłuż normalnej (ta oś w ogóle nie istnieje w
                // lokalnym układzie U/V, więc nie da się jej przypadkiem domieszać).
                hitU = hit.u;
                hitV = hit.v;
                double du = hitU - 0.5;
                double dv = hitV - 0.5;
                hitPositionDeviation = Math.sqrt(du * du + dv * dv);

                hitDeviationHistory.addLast(hitPositionDeviation);
                while (hitDeviationHistory.size() > HIT_DEVIATION_WINDOW) hitDeviationHistory.pollFirst();
            }
        } else if (hasBlockPosition) {
            // face nieznane (kompatybilność wsteczna) — fallback na test
            // całego bloku, bez precyzji na konkretną ścianę.
            BoundingBox wholeBlock = new BoundingBox(blockX, blockY, blockZ, blockX + 1, blockY + 1, blockZ + 1);
            Vector eye = new Vector(data.x, data.y + 1.62, data.z);
            Vector direction = directionFromRotation(data.yaw, data.pitch);
            raytraceHit = RayTraceUtil.intersect(eye, direction, wholeBlock, RAYTRACE_MAX_DISTANCE).hit;
        }

        if (raytraceHit) {
            perfectSnapStreak++;
            if (perfectSnapStreak > 5) {
                buffer(1.0, String.format("sub:RaytraceSnap streak:%d hasBlockPos:%b hasFace:%b",
                    perfectSnapStreak, hasBlockPosition, face != null));
            }
        } else {
            perfectSnapStreak = Math.max(0, perfectSnapStreak - 1);
        }

        // ── C. Tower — faza skoku, nie sam czas ─────────────────────────────
        double towerPhaseCv = Double.NaN;
        if (placedBelow && !data.player.isOnGround() && lastJumpMs > 0) {
            long reactionMs = now - lastJumpMs;
            if (reactionMs >= 0 && reactionMs <= TOWER_TIMING_WINDOW_MS) {
                // Faza trajektorii: 0 = start skoku, 1 = przewidywany apogeum.
                // Liczona z RZECZYWISTEJ pozycji Y w momencie kładzenia względem
                // startu skoku i teoretycznej wysokości apogeum — to odróżnia
                // "położył na starcie skoku" od "położył dokładnie w szczycie",
                // czego sam czas reakcji (poprzednia wersja) nie rozróżniał.
                double currentHeightAboveJumpStart = data.y - lastJumpStartY;
                double phase = clamp(currentHeightAboveJumpStart / JUMP_APEX_HEIGHT, 0.0, 1.0);

                towerJumpPhases.addLast(phase);
                while (towerJumpPhases.size() > 16) towerJumpPhases.pollFirst();

                if (towerJumpPhases.size() >= TOWER_SAMPLE_MIN) {
                    double meanPhase = meanDouble(towerJumpPhases);
                    double sdPhase = standardDeviationDouble(towerJumpPhases, meanPhase);
                    towerPhaseCv = meanPhase > 0.05 ? sdPhase / meanPhase : 1.0;

                    if (towerPhaseCv < TOWER_PHASE_CV_THRESHOLD) {
                        buffer(2.0, String.format("sub:TowerPhase cv:%.4f meanPhase:%.3f n:%d",
                            towerPhaseCv, meanPhase, towerJumpPhases.size()));
                    }
                }
            }
        }

        // ── F. Movement → rotation → placement mechanical pattern ────────────
        // Zapisujemy PEŁNY snapshot tego placementu (przegląd, punkt 4) i
        // porównujemy go z poprzednim — szukamy MECHANICZNEJ powtarzalności
        // kombinacji cech (nie tylko pojedynczej statystyki jak CV w B/C/E).
        PlacementSnapshot snapshot = new PlacementSnapshot(
            now, data.x, data.y, data.z, lastKnownHorizontalVelocity, data.yaw, data.pitch,
            blockX, blockY, blockZ, face != null ? face.name() : "UNKNOWN", hitU, hitV
        );

        PlacementSnapshot previousSnapshot = placementHistory.peekLast();
        if (previousSnapshot != null && isMechanicallyIdentical(previousSnapshot, snapshot)) {
            mechanicalPatternStreak++;
        } else {
            mechanicalPatternStreak = Math.max(0, mechanicalPatternStreak - 1);
        }

        placementHistory.addLast(snapshot);
        while (placementHistory.size() > PATTERN_HISTORY_SIZE) placementHistory.pollFirst();

        boolean mechanicalPatternDetected = mechanicalPatternStreak >= MECHANICAL_PATTERN_MIN_REPEATS;
        if (mechanicalPatternDetected) {
            buffer(2.2, String.format("sub:MechanicalPattern streak:%d historySize:%d",
                mechanicalPatternStreak, placementHistory.size()));
        }

        // ── D. Sneak requirement ─────────────────────────────────────────────
        if (placedBelow) {
            if (!data.player.isSneaking()) {
                noSneakPlacementStreak++;
                if (noSneakPlacementStreak >= NO_SNEAK_STREAK_THRESHOLD) {
                    buffer(1.5, String.format("sub:NoSneak streak:%d", noSneakPlacementStreak));
                }
            } else {
                noSneakPlacementStreak = 0;
            }
        }

        // ── E. Rotation/Movement Correlation ─────────────────────────────────
        double movementStabilityCv = movementStabilityCv();
        double correlationScore = 0.0;
        int strongSignalCount = 0; // liczba sygnałów NIEZALEŻNYCH od hit-vector — patrz wymóg poniżej
        StringBuilder correlationReasons = new StringBuilder();

        if (raytraceHit && perfectSnapStreak > 3) {
            correlationScore += 1.2;
            strongSignalCount++;
            correlationReasons.append("raytrace;");
        }
        if (!Double.isNaN(rhythmCv) && rhythmCv < RHYTHM_CV_THRESHOLD * 1.5) {
            correlationScore += 1.0;
            strongSignalCount++;
            correlationReasons.append("rhythm;");
        }
        if (!Double.isNaN(movementStabilityCv) && movementStabilityCv < MOVEMENT_STABILITY_CV_THRESHOLD) {
            correlationScore += 1.0;
            strongSignalCount++;
            correlationReasons.append("movementFrozen;");
        }
        if (!Double.isNaN(towerPhaseCv) && towerPhaseCv < TOWER_PHASE_CV_THRESHOLD * 1.5) {
            correlationScore += 1.0;
            strongSignalCount++;
            correlationReasons.append("towerPhase;");
        }

        // NAPRAWA (przegląd, punkt 3 kolejnej iteracji: "Nie traktuj samego
        // hit vector deviation jako mocnego dowodu. Hit vector ma być tylko
        // jednym z sygnałów... nie może sam powodować wysokiego violation").
        // Poprzednia waga (1.3) była WYŻSZA niż każdy inny pojedynczy sygnał,
        // więc hit-vector + JEDEN dowolny inny sygnał już prawie osiągał
        // CORRELATION_THRESHOLD — dokładnie to, czego przegląd zabrania.
        // Naprawa dwutorowa: (1) waga obniżona PONIŻEJ każdego pojedynczego
        // innego sygnału, (2) hit-vector wnosi swój wkład do sumy TYLKO gdy
        // co najmniej dwa NIEZALEŻNE (nie-hit-vector) sygnały już są obecne —
        // czyli hit-vector może jedynie WZMOCNIĆ już wystarczająco podejrzany
        // przypadek, nigdy nie jest tym, co samo przechyla szalę.
        if (hitDeviationHistory.size() >= HIT_DEVIATION_WINDOW && strongSignalCount >= 2) {
            double meanDeviation = meanDouble(hitDeviationHistory);
            double sdDeviation = standardDeviationDouble(hitDeviationHistory, meanDeviation);
            double deviationCv = meanDeviation > 0.01 ? sdDeviation / meanDeviation : 1.0;

            if (meanDeviation < HIT_CENTERED_THRESHOLD && deviationCv < HIT_DEVIATION_CV_THRESHOLD) {
                correlationScore += 0.6;
                correlationReasons.append(String.format("hitVector(mean:%.3f cv:%.3f);", meanDeviation, deviationCv));
            }
        }

        if (correlationScore >= CORRELATION_THRESHOLD) {
            buffer(correlationScore, String.format("sub:Correlation score:%.2f reasons:%s hitDev:%.3f",
                correlationScore, correlationReasons, hitPositionDeviation));
        }

        // Reward tylko jeśli żaden sub-check w tym wywołaniu nie zgłosił naruszenia
        // — uproszczone: liczymy na to, że buffer() już podniosło VL gdy trzeba,
        // a reward() tutaj dotyczy ogólnej "czystości" tego konkretnego placementu.
        if (!raytraceHit && noSneakPlacementStreak == 0 && correlationScore < CORRELATION_THRESHOLD) {
            reward();
        }
    }

    // ── Pomocniki geometrii ──────────────────────────────────────────────────

    /** Wektor kierunku patrzenia z yaw/pitch (stopnie) — standardowa konwersja Minecrafta, spójna z ReachCheck/KillAuraCheck. */
    private Vector directionFromRotation(float yaw, float pitch) {
        double yawRad = Math.toRadians(yaw);
        double pitchRad = Math.toRadians(pitch);
        double x = -Math.sin(yawRad) * Math.cos(pitchRad);
        double y = -Math.sin(pitchRad);
        double z = Math.cos(yawRad) * Math.cos(pitchRad);
        return new Vector(x, y, z).normalize();
    }

    /** Współczynnik zmienności ostatnich kilku próbek ruchu poziomego — niska wartość sugeruje "zamrożony" ruch przy stawianiu bloków. */
    private double movementStabilityCv() {
        if (recentHorizontalMovement.size() < MOVEMENT_STABILITY_WINDOW) return Double.NaN;
        double mean = meanDouble(recentHorizontalMovement);
        if (mean < 0.01) return Double.NaN; // gracz stoi w miejscu — brak sensownej bazy do oceny stabilności
        double sd = standardDeviationDouble(recentHorizontalMovement, mean);
        return sd / mean;
    }

    /**
     * Sub-check F: porównuje DWA kolejne pełne snapshoty placementu i ocenia,
     * czy kombinacja cech (rotacja, prędkość, hit position, ten sam face) jest
     * "mechanicznie identyczna" — czyli tak blisko siebie na WIELU niezależnych
     * osiach naraz, że to wskazuje na deterministyczny algorytm generujący
     * kolejne placementy, a nie naturalną, zawsze nieco inną sekwencję ruchów
     * ręki/ciała. Wymagamy zgodności na TRZECH niezależnych osiach (yaw,
     * prędkość, hit position) jednocześnie — pojedyncza zgodność (np. sama
     * podobna prędkość przy stałym sprincie) jest kompletnie normalna.
     */
    private boolean isMechanicallyIdentical(PlacementSnapshot a, PlacementSnapshot b) {
        if (!a.face.equals(b.face)) return false;

        double yawDiff = Math.abs(normalizeAngle(a.yaw - b.yaw));
        boolean yawMatches = yawDiff < PATTERN_YAW_TOLERANCE;

        double velocityDiff = Math.abs(a.horizontalVelocity - b.horizontalVelocity);
        boolean velocityMatches = velocityDiff < PATTERN_VELOCITY_TOLERANCE;

        boolean hitMatches = false;
        if (!Double.isNaN(a.hitU) && !Double.isNaN(b.hitU)) {
            double hitDiff = Math.sqrt(Math.pow(a.hitU - b.hitU, 2) + Math.pow(a.hitV - b.hitV, 2));
            hitMatches = hitDiff < 0.02; // bardzo ciasna tolerancja — naturalne kliknięcie nie trafia dwa razy niemal identycznie
        }

        int matchCount = (yawMatches ? 1 : 0) + (velocityMatches ? 1 : 0) + (hitMatches ? 1 : 0);
        return matchCount >= 3;
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    private float normalizeAngle(float angle) {
        while (angle > 180) angle -= 360;
        while (angle < -180) angle += 360;
        return angle;
    }

    private double mean(Iterable<Long> values) {
        double sum = 0;
        int count = 0;
        for (long v : values) { sum += v; count++; }
        return count == 0 ? 0 : sum / count;
    }

    private double standardDeviation(Iterable<Long> values, double mean) {
        double sum = 0;
        int count = 0;
        for (long v : values) { sum += (v - mean) * (v - mean); count++; }
        return count == 0 ? 0 : Math.sqrt(sum / count);
    }

    private double meanDouble(Iterable<Double> values) {
        double sum = 0;
        int count = 0;
        for (double v : values) { sum += v; count++; }
        return count == 0 ? 0 : sum / count;
    }

    private double standardDeviationDouble(Iterable<Double> values, double mean) {
        double sum = 0;
        int count = 0;
        for (double v : values) { sum += (v - mean) * (v - mean); count++; }
        return count == 0 ? 0 : Math.sqrt(sum / count);
    }

    @Override
    public void reset() {
        super.reset();
        placeDelays.clear();
        perfectSnapStreak = 0;
        lastPlaceMs = 0L;
        lastJumpMs = 0L;
        lastJumpStartY = 0;
        towerJumpPhases.clear();
        noSneakPlacementStreak = 0;
        recentHorizontalMovement.clear();
        hitDeviationHistory.clear();
        placementHistory.clear();
        mechanicalPatternStreak = 0;
        lastKnownHorizontalVelocity = 0;
    }
}
