/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.data;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * cc-anticheat — PlayerData
 *
 * Centralny magazyn stanu per-gracz.
 *
 * UWAGA ARCHITEKTONICZNA: wcześniejsza wersja opierała się na pakiecie
 * WINDOW_CONFIRMATION do budowy "zegara gracza" (transaction sandwich).
 * Ten pakiet NIE ISTNIEJE w protokole Minecraft od wersji 1.17+ (usunięty
 * wraz z starym systemem potwierdzeń okien) i ProtocolLib 5.3.0 go nie
 * udostępnia dla klienta 1.21.x. Timing gracza budujemy teraz na podstawie
 * CLIENT_TICK_END (od 1.21.2 klient wysyła jawny pakiet końca ticka) jako
 * podstawowego źródła, z fallbackiem na zliczanie pakietów ruchu względem
 * czasu serwerowego skorygowanego o TPS — patrz TimerCheck.
 */
public class PlayerData {

    // ── Identity ────────────────────────────────────────────────────────────
    public final Player player;
    public final UUID uuid;

    // ── Tick counter ────────────────────────────────────────────────────────
    /** Monotoniczny licznik ticków ruchu tego gracza, niezależny od TPS serwera. */
    public long movementTickCount = 0;

    // ── Pozycja bieżąca (aktualizowana przez PacketListener) ─────────────────
    public double x, y, z;
    public double lastX, lastY, lastZ;
    public float yaw, pitch;
    public float lastYaw, lastPitch;
    public boolean onGround;
    public boolean lastOnGround;

    /** Aktualny wektor ruchu (delta pozycji tego ticka). */
    public Vector actualMovement = new Vector();

    // ── Historia ruchu (ring buffer) ─────────────────────────────────────────
    /** Ostatnie N snapshotów ruchu — pozwala checkom analizować sekwencje, nie pojedyncze pakiety. */
    private static final int MOVEMENT_HISTORY_SIZE = 40;
    public final Deque<MovementData> movementHistory = new ArrayDeque<>(MOVEMENT_HISTORY_SIZE);

    public void pushMovement(MovementData m) {
        movementHistory.addFirst(m);
        while (movementHistory.size() > MOVEMENT_HISTORY_SIZE) {
            movementHistory.removeLast();
        }
    }

    public MovementData lastMovement() {
        return movementHistory.peekFirst();
    }

    public MovementData movementAgo(int ticksAgo) {
        int i = 0;
        for (MovementData m : movementHistory) {
            if (i == ticksAgo) return m;
            i++;
        }
        return null;
    }

    // ── Timing / Timer (przebudowane, bez transakcji) ────────────────────────
    /** Czas (ns) ostatniego przetworzonego pakietu ruchu. */
    public long lastMovementPacketNs = System.nanoTime();
    /** Akumulator balansu czasu — dodatni oznacza gracza wysyłającego pakiety za szybko. */
    public double timerBalanceMs = 0.0;
    /** Ticki zwolnienia timera po dołączeniu (10 s = 200 ticków). */
    public int timerJoinExemptTicks = 200;
    /** Ostatni zmierzony klient-side tick delta (ms) — do detekcji zarówno Timer jak i Freecam/NoSlow. */
    public double lastClientTickDeltaMs = 50.0;

    // ── Lag compensation ──────────────────────────────────────────────────────
    /** Ostatni znany ping gracza (ms), aktualizowany przez PingManager z natywnego API Paper. */
    public volatile int pingMs = 0;
    /** Krótka historia pingu do wygładzania (unikanie false-positive przy skokach pingu). */
    public final Deque<Integer> pingHistory = new ArrayDeque<>(20);

    public void pushPing(int ping) {
        pingMs = ping;
        pingHistory.addFirst(ping);
        while (pingHistory.size() > 20) pingHistory.removeLast();
    }

    public double averagePing() {
        if (pingHistory.isEmpty()) return pingMs;
        double sum = 0;
        for (int p : pingHistory) sum += p;
        return sum / pingHistory.size();
    }

    // ── Velocity / Knockback tracking (uproszczony model bez transakcji) ─────
    /**
     * Kolejka oczekujących wektorów knockback. Zamiast "kanapki transakcyjnej"
     * (niemożliwej bez WINDOW_CONFIRMATION), wiążemy KB z konkretnym numerem
     * ticka ruchu, w którym zostało wysłane, i dajemy graczowi okno tolerancji
     * (ticksToApply) proporcjonalne do jego pingu — patrz VelocityCheck.
     */
    public final Deque<VelocityData> pendingKnockback = new ArrayDeque<>();

    // ── Combat — click patterns ────────────────────────────────────────────
    public final ArrayDeque<Long> swingDelays = new ArrayDeque<>(128);
    public long lastSwingMs = 0L;
    public boolean inBreakProcess = false;
    public long lastBreakMs = 0L;
    public boolean holdingFishingRod = false;

    // ── Combat — reach / raytrace ──────────────────────────────────────────
    public final List<PendingAttack> pendingAttacks = new ArrayList<>();

    // ── Combat — KillAura ────────────────────────────────────────────────────
    public final ArrayDeque<Long> recentAttackTimestamps = new ArrayDeque<>(32);
    public final Set<Integer> entitiesAttackedWindow = new HashSet<>();

    // ── Combat — AimBot ──────────────────────────────────────────────────────
    public final ArrayDeque<float[]> rotationSamples = new ArrayDeque<>(60);
    public long gcdAccumulatorYaw = 0;
    public long gcdAccumulatorPitch = 0;
    public int gcdSampleCount = 0;

    // ── Combat — AntiFireball ────────────────────────────────────────────────
    /** entityId fireballa -> timestamp (ms), w którym wszedł w zasięg ataku gracza. */
    public final Map<Integer, Long> fireballsInRange = new ConcurrentHashMap<>();

    // ── Combat — TriggerBot ──────────────────────────────────────────────────
    /** Ostatnia znana encja pod celownikiem gracza — aktualizowana przez raytrace na każdym ticku ruchu/rotacji. */
    public Entity currentCrosshairTarget = null;

    // ── Mining (Etap 4: Nuke / FastBreak) ─────────────────────────────────────
    public boolean isBreakingBlock = false;
    public long breakStartMs = 0L;
    public int breakBlockX, breakBlockY, breakBlockZ;
    public String breakBlockType = "";
    public double breakExpectedTicks = 0;
    public int breakServerTicksElapsed = 0;

    // ── World / environment exemption state ────────────────────────────────
    public boolean inVehicle = false;
    public boolean spectating = false;
    /** Ustawiane true, gdy serwer wysłał korekcyjny teleport i czeka na potwierdzenie klienta. */
    public boolean awaitingTeleportConfirm = false;
    public int pendingTeleportId = -1;
    public double setbackX, setbackY, setbackZ;
    public float setbackYaw, setbackPitch;

    // ── Misc ────────────────────────────────────────────────────────────────
    public long joinTime = System.currentTimeMillis();
    /** Rejestr instancji checków — wypełniany przez CheckManager, używany do globalnego reset/exempt. */
    public final List<dev.cc.anticheat.check.Check> allChecks = new ArrayList<>();

    public PlayerData(Player player) {
        this.player = player;
        this.uuid = player.getUniqueId();
        this.x = player.getLocation().getX();
        this.y = player.getLocation().getY();
        this.z = player.getLocation().getZ();
        this.lastX = x;
        this.lastY = y;
        this.lastZ = z;
        this.yaw = player.getLocation().getYaw();
        this.pitch = player.getLocation().getPitch();
        this.onGround = player.isOnGround();
        this.lastOnGround = this.onGround;
    }

    /**
     * Wywołuje exempt(ticks) na wszystkich zarejestrowanych checkach naraz.
     * Używane przy teleportach, respawnie, zmianie świata/gamemode/pojazdu.
     */
    public void exemptAll(int ticks) {
        for (dev.cc.anticheat.check.Check check : allChecks) {
            check.exempt(ticks);
        }
    }

    public boolean isClickCheckDeactivated(long swingDelay) {
        return swingDelay > 4000L
            || inBreakProcess
            || (System.currentTimeMillis() - lastBreakMs) < 3000L
            || holdingFishingRod;
    }

    // ── Inner types ───────────────────────────────────────────────────────────

    public static class PendingAttack {
        public final int entityId;
        public final long timestampNs;
        public final long timestampMs;
        public final boolean prelimSucceeded;
        /** Pozycja gracza W MOMENCIE ataku — nie "obecna" pozycja w momencie przetwarzania kolejki. */
        public final double attackerX, attackerY, attackerZ;
        public final float attackerYaw, attackerPitch;

        public PendingAttack(int entityId, boolean prelimSucceeded, double x, double y, double z, float yaw, float pitch) {
            this.entityId = entityId;
            this.timestampNs = System.nanoTime();
            this.timestampMs = System.currentTimeMillis();
            this.prelimSucceeded = prelimSucceeded;
            this.attackerX = x;
            this.attackerY = y;
            this.attackerZ = z;
            this.attackerYaw = yaw;
            this.attackerPitch = pitch;
        }
    }

    public static class VelocityData {
        public final int entityId;
        public final long sentAtTickCount;
        public final Vector knockback;
        /** Ile ticków ruchu dajemy graczowi na zaaplikowanie KB, zależnie od pingu. */
        public final int toleranceTicks;
        /** Źródło impulsu — wpływa na naturalną wariancję aplikacji (patrz VelocityCheck). */
        public final KnockbackSource source;
        /**
         * Prędkość gracza (delta ostatniego ticka ruchu) TUŻ PRZED tym KB —
         * początek łańcucha "velocity przed → KB → expected → actual"
         * (patrz PlayerPhysicsEngine#predictPostKnockbackVelocity). 0 jeśli
         * gracz nie miał jeszcze żadnej zarejestrowanej historii ruchu.
         */
        public final double velBeforeX, velBeforeY, velBeforeZ;

        /** Konstruktor zachowany dla kompatybilności wstecznej — domyślne źródło MELEE, zerowa velocity przed KB. */
        public VelocityData(int entityId, long sentAtTickCount, Vector knockback, int toleranceTicks) {
            this(entityId, sentAtTickCount, knockback, toleranceTicks, KnockbackSource.MELEE, 0, 0, 0);
        }

        /** Konstruktor zachowany dla kompatybilności wstecznej — bez jawnej velocity przed KB. */
        public VelocityData(int entityId, long sentAtTickCount, Vector knockback, int toleranceTicks, KnockbackSource source) {
            this(entityId, sentAtTickCount, knockback, toleranceTicks, source, 0, 0, 0);
        }

        public VelocityData(int entityId, long sentAtTickCount, Vector knockback, int toleranceTicks,
                             KnockbackSource source, double velBeforeX, double velBeforeY, double velBeforeZ) {
            this.entityId = entityId;
            this.sentAtTickCount = sentAtTickCount;
            this.knockback = knockback;
            this.toleranceTicks = toleranceTicks;
            this.source = source;
            this.velBeforeX = velBeforeX;
            this.velBeforeY = velBeforeY;
            this.velBeforeZ = velBeforeZ;
        }
    }

    /** Źródło impulsu velocity — każde ma inną naturalną wariancję legalnej aplikacji, patrz VelocityCheck. */
    public enum KnockbackSource {
        MELEE, EXPLOSION, PROJECTILE, OTHER
    }
}
