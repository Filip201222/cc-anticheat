/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.manager;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.ListenerPriority;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;
import dev.cc.anticheat.CCAnticheat;
import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.predict.CollisionUtil;
import dev.cc.anticheat.predict.EntityLookup;
import dev.cc.anticheat.predict.PlayerPhysicsEngine;
import dev.cc.anticheat.predict.WorldStateUtil;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * cc-anticheat — PacketListener
 *
 * Hookuje się w ProtocolLib, aby przechwytywać pakiety klienta zanim trafią
 * do logiki Bukkit/Paper.
 *
 * UWAGA: poprzednia wersja nasłuchiwała WINDOW_CONFIRMATION do budowy timera
 * transakcyjnego — ten pakiet nie istnieje we współczesnym protokole (usunięty
 * z Minecrafta dawno temu, ProtocolLib go nie eksponuje dla 1.21.x). Timing
 * budujemy teraz na podstawie CLIENT_TICK_END (nowy pakiet od 1.21.2, klient
 * jawnie informuje serwer o końcu swojego ticka) — patrz TimerCheck.
 *
 * Cała ciężka logika jest delegowana do CheckManager; PacketListener tylko
 * wyciąga surowe pola z pakietu i buduje spójny snapshot MovementData.
 */
public class PacketListener {

    private final CCAnticheat plugin;
    private final CheckManager cm;
    private final ProtocolManager pm;

    /** Śledzi, czy gracz wykonał ARM_ANIMATION w obrębie bieżącego ticka ruchu. */
    private final Map<UUID, Boolean> swungThisTick = new ConcurrentHashMap<>();

    public PacketListener(CCAnticheat plugin, CheckManager cm) {
        this.plugin = plugin;
        this.cm = cm;
        this.pm = ProtocolLibrary.getProtocolManager();
        register();
    }

    private void register() {
        registerSwing();
        registerAttack();
        registerMovement();
        registerClientTickEnd();
        registerBlockPlace();
        registerDigging();
    }

    // ── ARM_ANIMATION ────────────────────────────────────────────────────────

    private void registerSwing() {
        pm.addPacketListener(new PacketAdapter(plugin,
            ListenerPriority.NORMAL,
            PacketType.Play.Client.ARM_ANIMATION) {
            @Override
            public void onPacketReceiving(PacketEvent event) {
                Player player = event.getPlayer();
                PlayerData data = cm.getData(player);
                if (data == null) return;

                swungThisTick.put(player.getUniqueId(), true);
                cm.onSwing(data, true);
            }
        });
    }

    // ── USE_ENTITY (attack) ──────────────────────────────────────────────────

    private void registerAttack() {
        pm.addPacketListener(new PacketAdapter(plugin,
            ListenerPriority.NORMAL,
            PacketType.Play.Client.USE_ENTITY) {
            @Override
            public void onPacketReceiving(PacketEvent event) {
                Player player = event.getPlayer();
                PlayerData data = cm.getData(player);
                if (data == null) return;

                // EnumWrappers.EntityUseAction: ATTACK = 0 w nowoczesnym mapowaniu ProtocolLib
                com.comphenix.protocol.wrappers.EnumWrappers.EntityUseAction action =
                    event.getPacket().getEntityUseActions().readSafely(0);
                if (action != com.comphenix.protocol.wrappers.EnumWrappers.EntityUseAction.ATTACK) return;

                int entityId = event.getPacket().getIntegers().read(0);
                Entity target = findEntity(entityId);
                if (target == null) return;

                boolean hadSwing = swungThisTick.getOrDefault(player.getUniqueId(), false);

                boolean cancel = cm.onAttack(data, target, hadSwing);
                if (cancel) event.setCancelled(true);
            }
        });
    }

    // ── BLOCK_PLACE (użycie itemu na bloku — kładzenie bloków) ────────────────

    private void registerBlockPlace() {
        PacketType blockPlace = safePacketType("Client", "BLOCK_PLACE");
        if (blockPlace == null) {
            plugin.getLogger().warning(
                "BLOCK_PLACE packet type not found in this ProtocolLib version — "
                + "ScaffoldCheck will not receive block placement events.");
            return;
        }

        pm.addPacketListener(new PacketAdapter(plugin,
            ListenerPriority.NORMAL,
            blockPlace) {
            @Override
            public void onPacketReceiving(PacketEvent event) {
                Player player = event.getPlayer();
                PlayerData data = cm.getData(player);
                if (data == null) return;

                try {
                    com.comphenix.protocol.wrappers.BlockPosition pos =
                        event.getPacket().getBlockPositionModifier().readSafely(0);
                    if (pos == null) return;

                    org.bukkit.util.Vector placedAgainst = new org.bukkit.util.Vector(
                        pos.getX() + 0.5 - data.x,
                        pos.getY() + 0.5 - data.y,
                        pos.getZ() + 0.5 - data.z
                    );

                    // Direction (block face) — dokładnie KTÓRĄ ścianę bloku
                    // kliknął gracz, potwierdzone, stabilne API ProtocolLib
                    // (getDirections(), używane też w oficjalnych PacketWrapper
                    // dla BLOCK_DIG z identyczną konwencją). Bez tego pola
                    // ScaffoldCheck może tylko sprawdzić "czy promień trafia w
                    // blok w ogóle", nie "czy trafia w face zgodny z tym, co
                    // faktycznie wysłał protokół" (przegląd, punkt 🔴 "Scaffold
                    // raytrace → konkretny BlockFace").
                    com.comphenix.protocol.wrappers.EnumWrappers.Direction face =
                        event.getPacket().getDirections().readSafely(0);

                    cm.onBlockPlace(data, placedAgainst, pos.getX(), pos.getY(), pos.getZ(), face);
                } catch (Exception ignored) {
                    // Struktura pakietu BLOCK_PLACE różni się nieznacznie między wersjami
                    // ProtocolLib — jeśli odczyt się nie powiedzie, po prostu pomijamy
                    // tę próbkę zamiast psuć resztę przetwarzania pakietu.
                }
            }
        });
    }

    /**
     * O(1) lookup przez EntityLookup (punkt 14 specyfikacji) zamiast O(n)
     * iteracji po world.getEntities() na KAŻDY pakiet ataku.
     */
    private Entity findEntity(int entityId) {
        return EntityLookup.get(entityId);
    }

    // ── BLOCK_DIG (PLAYER_DIGGING — start/stop kopania bloku) ─────────────────

    /**
     * Nasłuchuje pakietu BLOCK_DIG (protokołowo: player_action), który klient
     * wysyła przy rozpoczęciu kopania (START_DESTROY_BLOCK), zakończeniu
     * (STOP_DESTROY_BLOCK) oraz anulowaniu (ABORT_DESTROY_BLOCK). To jest
     * źródło danych dla FastBreakCheck — mierzymy realny czas między
     * START_DESTROY_BLOCK a faktycznym BlockBreakEvent.
     */
    private void registerDigging() {
        pm.addPacketListener(new PacketAdapter(plugin,
            ListenerPriority.NORMAL,
            PacketType.Play.Client.BLOCK_DIG) {
            @Override
            public void onPacketReceiving(PacketEvent event) {
                Player player = event.getPlayer();
                PlayerData data = cm.getData(player);
                if (data == null) return;

                com.comphenix.protocol.wrappers.EnumWrappers.PlayerDigType action =
                    event.getPacket().getPlayerDigTypes().readSafely(0);
                if (action == null) return;

                com.comphenix.protocol.wrappers.BlockPosition pos =
                    event.getPacket().getBlockPositionModifier().readSafely(0);

                switch (action) {
                    case START_DESTROY_BLOCK:
                        if (pos != null) {
                            org.bukkit.block.Block block = player.getWorld().getBlockAt(
                                pos.getX(), pos.getY(), pos.getZ());
                            cm.onDigStart(data, block);
                        }
                        break;
                    case ABORT_DESTROY_BLOCK:
                    case STOP_DESTROY_BLOCK:
                        cm.onDigCancel(data);
                        break;
                    default:
                        // DROP_ITEM, RELEASE_USE_ITEM, SWAP_HELD_ITEMS itd. — nieistotne dla FastBreak.
                        break;
                }
            }
        });
    }

    // ── FLYING / POSITION / POSITION_LOOK / LOOK ─────────────────────────────

    private void registerMovement() {
        pm.addPacketListener(new PacketAdapter(plugin,
            ListenerPriority.NORMAL,
            PacketType.Play.Client.FLYING,
            PacketType.Play.Client.POSITION,
            PacketType.Play.Client.POSITION_LOOK,
            PacketType.Play.Client.LOOK) {
            @Override
            public void onPacketReceiving(PacketEvent event) {
                handleMovementPacket(event);
            }
        });
    }

    private void handleMovementPacket(PacketEvent event) {
        Player player = event.getPlayer();
        PlayerData data = cm.getData(player);
        if (data == null) return;

        PacketType type = event.getPacketType();
        boolean hasPos = type == PacketType.Play.Client.POSITION
            || type == PacketType.Play.Client.POSITION_LOOK;
        boolean hasLook = type == PacketType.Play.Client.LOOK
            || type == PacketType.Play.Client.POSITION_LOOK;

        // ── Aktualizacja pozycji ───────────────────────────────────────────
        if (hasPos) {
            data.lastX = data.x;
            data.lastY = data.y;
            data.lastZ = data.z;

            data.x = event.getPacket().getDoubles().read(0);
            data.y = event.getPacket().getDoubles().read(1);
            data.z = event.getPacket().getDoubles().read(2);

            data.actualMovement.setX(data.x - data.lastX);
            data.actualMovement.setY(data.y - data.lastY);
            data.actualMovement.setZ(data.z - data.lastZ);
        } else {
            // Pakiet bez pozycji (FLYING/LOOK) — pozycja się nie zmienia, ale
            // wciąż liczy się jako pełny tick ruchu dla timera i predykcji.
            data.lastX = data.x;
            data.lastY = data.y;
            data.lastZ = data.z;
            data.actualMovement.setX(0);
            data.actualMovement.setY(0);
            data.actualMovement.setZ(0);
        }

        // ── Aktualizacja rotacji ────────────────────────────────────────────
        if (hasLook) {
            data.lastYaw = data.yaw;
            data.lastPitch = data.pitch;
            int offset = hasPos ? 3 : 0;
            data.yaw = event.getPacket().getFloat().read(offset);
            data.pitch = event.getPacket().getFloat().read(offset + 1);
            cm.onRotation(data, data.yaw, data.pitch);
        }

        boolean onGround = readOnGround(event);
        data.lastOnGround = data.onGround;
        data.onGround = onGround;
        data.movementTickCount++;

        // ── Budowa pełnego snapshotu MovementData ──────────────────────────
        MovementData movement = new MovementData(
            data.x, data.y, data.z,
            data.lastX, data.lastY, data.lastZ,
            data.yaw, data.pitch,
            onGround,
            data.movementTickCount
        );

        // Weryfikacja gruntu przez AABB, niezależna od deklaracji klienta.
        movement.actuallyOnGround = CollisionUtil.isOnGround(player.getWorld(), data.x, data.y, data.z);
        movement.horizontalCollision = CollisionUtil.hasHorizontalCollision(
            player.getWorld(), data.x, data.y, data.z, playerHeight(player));

        WorldStateUtil.populate(player, movement, playerHeight(player));

        // Envelope liczony PRZED pushMovement — w tym momencie data.lastMovement()
        // wciąż zwraca POPRZEDNI tick (head kolejki), bo bieżący jeszcze nie został
        // dopisany. To jest właściwy "previous" do predykcji tego ticka.
        MovementData previousForEnvelope = data.lastMovement();
        movement.envelope = PlayerPhysicsEngine.computeEnvelope(player, data, movement, previousForEnvelope);
        movement.envelope.computeDeviation(movement.deltaX, movement.deltaY, movement.deltaZ);

        data.pushMovement(movement);

        cm.onMovement(data, data.lastY, hasPos, onGround, movement);

        swungThisTick.remove(player.getUniqueId());
    }

    private double playerHeight(Player player) {
        if (player.isSwimming() || player.isGliding()) return CollisionUtil.PLAYER_HEIGHT_SWIMMING;
        if (player.isSneaking()) return CollisionUtil.PLAYER_HEIGHT_SNEAKING;
        return CollisionUtil.PLAYER_HEIGHT_STANDING;
    }

    /**
     * Pole "onGround" jest zawsze ostatnim booleanem w rodzinie pakietów FLYING,
     * niezależnie od tego, czy pakiet niesie pozycję/rotację — indeks 0 w tablicy
     * booleans jest stabilny w ProtocolLib dla całej rodziny PLAYER_POSITION*.
     */
    private boolean readOnGround(PacketEvent event) {
        return event.getPacket().getBooleans().readSafely(0) != null
            && event.getPacket().getBooleans().read(0);
    }

    // ── CLIENT_TICK_END ──────────────────────────────────────────────────────

    /**
     * Od Minecraft 1.21.2 klient wysyła jawny pakiet końca swojego ticka
     * (client_tick_end). To jest teraz nasze główne, wiarygodne źródło do
     * budowy timera — o wiele dokładniejsze niż liczenie samych pakietów ruchu,
     * bo jest wysyłany dokładnie raz na każdy tick klienta niezależnie od tego,
     * czy w danym ticku w ogóle doszło do zmiany pozycji.
     */
    private void registerClientTickEnd() {
        PacketType tickEnd = safePacketType("Client", "CLIENT_TICK_END");
        if (tickEnd == null) {
            plugin.getLogger().warning(
                "CLIENT_TICK_END packet type not found in this ProtocolLib version — "
                + "TimerCheck will fall back to movement-packet-based timing only.");
            return;
        }

        pm.addPacketListener(new PacketAdapter(plugin, ListenerPriority.NORMAL, tickEnd) {
            @Override
            public void onPacketReceiving(PacketEvent event) {
                Player player = event.getPlayer();
                PlayerData data = cm.getData(player);
                if (data == null) return;
                cm.onClientTickEnd(data);
            }
        });
    }

    /**
     * Bezpieczne (odporne na różnice wersji ProtocolLib) pobranie stałej
     * PacketType przez refleksję. Odwołanie się bezpośrednio do pola, które
     * nie istnieje w danej wersji ProtocolLib, powoduje NoSuchFieldError już
     * przy weryfikacji bajtkodu metody odwołującej się do tego pola — więc
     * zwykły try/catch wokół bezpośredniego odwołania NIE wystarcza. Refleksja
     * pozwala bezpiecznie zwrócić null zamiast wywalić cały listener.
     *
     * @param clientOrServer "Client" lub "Server" — która podklasa PacketType.Play
     * @param fieldName      nazwa stałej, np. "BLOCK_PLACE", "CLIENT_TICK_END"
     */
    private PacketType safePacketType(String clientOrServer, String fieldName) {
        try {
            Class<?> holder = clientOrServer.equals("Client")
                ? PacketType.Play.Client.class
                : PacketType.Play.Server.class;
            java.lang.reflect.Field field = holder.getField(fieldName);
            Object value = field.get(null);
            return value instanceof PacketType ? (PacketType) value : null;
        } catch (ReflectiveOperationException e) {
            return null;
        }
    }

    public void unregister() {
        pm.removePacketListeners(plugin);
    }
}
