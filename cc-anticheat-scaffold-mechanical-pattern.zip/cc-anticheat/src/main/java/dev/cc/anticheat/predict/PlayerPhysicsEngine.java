/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.predict;

import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

/**
 * cc-anticheat — PlayerPhysicsEngine
 *
 * Własna implementacja symulacji fizyki gracza vanilla Minecraft, inspirowana
 * podejściem GrimAC (predykcja tick-po-ticku zamiast prostych progów), ale
 * napisana od zera pod nasz model danych.
 *
 * Ta klasa oblicza, jaki wektor ruchu (deltaX, deltaY, deltaZ) POWINIEN wygenerować
 * klient w danym ticku, na podstawie:
 *   - poprzedniej prędkości gracza,
 *   - inputu (sprint/sneak/jump — wnioskowanego z historii ruchu, bo surowy input
 *     WASD nie jest przesyłany do serwera w wanilla protokole),
 *   - grawitacji,
 *   - tarcia bloku pod graczem (śliskość lodu, gleby duszy itd.),
 *   - oporu środowiska (woda, lawa, drabina, sieć pajęcza, bąbelki),
 *   - efektów mikstur (Speed, Slowness, Jump Boost, Levitation, Dolphin's Grace).
 *
 * Wynik porównywany jest przez checki z faktycznym ruchem gracza — różnica
 * (offset) ponad tolerancję oznacza fizyczną niemożliwość i jest podstawą do
 * narastania VL w danym checku.
 */
public final class PlayerPhysicsEngine {

    // ── Stałe fizyki vanilla ─────────────────────────────────────────────────
    public static final double GRAVITY = 0.08;
    public static final double AIR_DRAG = 0.98;
    public static final double WATER_GRAVITY = 0.02;
    public static final double LAVA_GRAVITY = 0.02;

    public static final double DEFAULT_GROUND_FRICTION = 0.6;
    public static final double ICE_FRICTION = 0.98;
    public static final double PACKED_ICE_FRICTION = 0.98;
    public static final double BLUE_ICE_FRICTION = 0.989;
    public static final double SLIME_FRICTION = 0.8;
    public static final double SOUL_SAND_FRICTION = 0.6; // sam blok nie jest śliski — spowalnia ruch przez kolizję hitboxa (0.4375 wysokości), nie przez friction

    public static final double WALK_SPEED = 0.1;
    public static final double SPRINT_MULTIPLIER = 1.3;
    public static final double SNEAK_MULTIPLIER = 0.3;
    public static final double SOUL_SPEED_MULTIPLIER_PER_LEVEL = 0.105; // na soul sand/soul soil z butami Soul Speed

    public static final double JUMP_VELOCITY = 0.42;
    public static final double JUMP_BOOST_PER_LEVEL = 0.1;
    public static final double SPRINT_JUMP_BOOST_X = 0.2;

    public static final double LIQUID_HORIZONTAL_DRAG = 0.8;

    /** Prędkość opadania ograniczona przez Slow Falling — maksymalny (najbardziej ujemny) dopuszczalny spadek/tick. */
    public static final double SLOW_FALLING_MAX_DESCENT = -0.3;
    /** Honey Block przy zjeździe po ścianie: maksymalny (najbardziej ujemny) dopuszczalny spadek/tick. */
    public static final double HONEY_MAX_DESCENT = -0.08;

    private PlayerPhysicsEngine() {}

    /**
     * Wynik pojedynczej predykcji ruchu — przewidywana delta oraz przewidywany
     * bounding stan (czy powinien być na ziemi po tym ticku).
     */
    public static final class Prediction {
        public double deltaX, deltaY, deltaZ;
        public double horizontalOffset;
        public double verticalOffset;

        public Prediction(double dx, double dy, double dz) {
            this.deltaX = dx;
            this.deltaY = dy;
            this.deltaZ = dz;
        }
    }

    /**
     * Główna metoda predykcji: na podstawie poprzedniego ruchu (last) i kontekstu
     * bloków, próbuje odtworzyć, jaki powinien być NASTĘPNY wektor ruchu w warunkach
     * w pełni legalnej gry. Nie zna dokładnego inputu WASD gracza, więc dla ruchu
     * poziomego szacuje na podstawie ostatniej znanej prędkości + tarcia + ewentualnego
     * przyspieszenia sprintem — dając wynik jako GÓRNĄ GRANICĘ możliwego przyspieszenia,
     * z którą checki porównują faktyczny ruch (offset ponad granicę = flaga).
     *
     * Kolejność sprawdzania stanów jest istotna i odzwierciedla priorytet w
     * vanilla EntityLiving#travel(): elytra > climbable > levitation >
     * ciecz (z Dolphin's Grace) > bubble column > honey (zjazd po ścianie) >
     * slow falling > on-ground > swobodny spadek (z ew. slime bounce).
     */
    public static Prediction predictNextMovement(Player player, PlayerData data, MovementData current, MovementData previous) {
        double lastDx = previous != null ? previous.deltaX : 0;
        double lastDy = previous != null ? previous.deltaY : 0;
        double lastDz = previous != null ? previous.deltaZ : 0;

        // ── Oś Y ────────────────────────────────────────────────────────────
        double predictedY;
        if (current.gliding) {
            predictedY = predictElytraY(player, lastDy);
        } else if (current.onClimbable) {
            predictedY = clamp(lastDy, -0.13, 0.2);
        } else if (hasLevitation(player)) {
            int amp = player.getPotionEffect(PotionEffectType.LEVITATION).getAmplifier() + 1;
            predictedY = (0.05 * amp - lastDy) * 0.2 + lastDy;
        } else if (current.inWater || current.inLava) {
            double liquidGravity = current.inLava ? LAVA_GRAVITY : WATER_GRAVITY;
            predictedY = (lastDy - liquidGravity) * LIQUID_HORIZONTAL_DRAG;
            if (hasDolphinsGrace(player) && current.inWater) {
                predictedY = Math.max(predictedY, 0.0);
            }
        } else if (current.inBubbleColumn) {
            predictedY = predictBubbleColumnY(current, lastDy);
        } else if (current.onHoneyBlock && isSlidingDownWall(current) && lastDy < 0) {
            // Honey Block: zjazd po pionowej ścianie miodu ogranicza prędkość
            // opadania do stałej wartości niezależnie od czasu swobodnego spadku
            // wcześniej — analogicznie do drabiny, ale tylko przy kolizji poziomej.
            predictedY = Math.max(lastDy - GRAVITY, HONEY_MAX_DESCENT);
        } else if (hasSlowFalling(player)) {
            // Slow Falling: przyspieszenie grawitacyjne ograniczone do 0.01/tick
            // zamiast 0.08/tick, z maksymalną prędkością opadania ograniczoną.
            predictedY = Math.max(lastDy - 0.01, SLOW_FALLING_MAX_DESCENT) * AIR_DRAG;
        } else if (current.actuallyOnGround) {
            predictedY = handleGroundContactY(current, lastDy);
        } else {
            // Swobodny spadek / kontynuacja skoku — pełna formuła grawitacji vanilla.
            predictedY = (lastDy - GRAVITY) * AIR_DRAG;
            // Honey Block na dole ogranicza prędkość UDERZENIA (nie samego spadania w locie) —
            // obsłużone w handleGroundContactY, gdy actuallyOnGround stanie się true na bloku miodu.
        }

        // ── Oś pozioma: tarcie + ewentualne przyspieszenie ────────────────────
        double frictionFactor = current.actuallyOnGround
            ? current.blockFriction
            : 0.91; // opór powietrza w locie (vanilla: 0.91 nie-na-ziemi)

        double speedMultiplier = frictionFactor;
        if (current.inWater) speedMultiplier = LIQUID_HORIZONTAL_DRAG;
        if (current.onHoneyBlock && current.actuallyOnGround) speedMultiplier *= 0.4; // spowolnienie poziome na miodzie (vanilla: ~0.4x)

        double predictedX = lastDx * speedMultiplier;
        double predictedZ = lastDz * speedMultiplier;

        // Maksymalny teoretyczny przyrost prędkości w jednym ticku od inputu
        // (sprint+jump boost+speed potion+soul speed) — górna granica używana
        // jako tolerancja, NIE jako dokładna wartość (nie znamy realnego inputu WASD).
        double maxAccel = maxHorizontalAcceleration(player, current);

        Prediction result = new Prediction(predictedX, predictedY, predictedZ);
        result.horizontalOffset = maxAccel;
        return result;
    }

    /**
     * Oblicza deltaY w ticku, w którym gracz jest (lub właśnie staje się)
     * on-ground.
     *
     * WAŻNA NAPRAWA (priorytet 🟠5): poprzednia wersja tej metody ZAWSZE
     * zwracała 0.0 (lub bounce na slime) dla gracza na ziemi — co oznacza,
     * że KAŻDY legalny skok (deltaY skacze z ~0 do JUMP_VELOCITY=0.42 w
     * jednym ticku) był interpretowany przez FlightCheck/SpeedCheck jako
     * ogromne, fizycznie niemożliwe odchylenie od przewidywania (offset
     * ~0.42 przy tolerancji ~0.03-0.15) — to był PRAWDOPODOBNIE GŁÓWNY
     * ŹRÓDŁOWY BŁĄD wywołujący false-positive we Flight/Speed przy zwykłym,
     * powtarzającym się skakaniu (bunny-hop, żabki, granie na wzniesieniach).
     *
     * Skok nie jest bezpośrednio obserwowalny w protokole (klient nie wysyła
     * "skacz teraz"), ale JEST WNIOSKOWALNY: jeśli gracz jest na ziemi w
     * poprzednim ticku, a w BIEŻĄCYM ticku deltaY nagle staje się dodatnia i
     * bliska JUMP_VELOCITY (z uwzględnieniem Jump Boost), to jest to legalny
     * skok — pozwalamy na deltaY do (JUMP_VELOCITY + jumpBoostBonus), nie
     * tylko na 0.
     */
    private static double handleGroundContactY(MovementData current, double lastDy) {
        if (current.onSlimeBlock && !current.sneaking && lastDy < -0.08) {
            return -lastDy * 1.0; // odbicie ~1:1, tłumione minimalnie przez silnik gry w praktyce pomijalnie
        }

        // Skok — nie znamy dokładnie CZY gracz skoczył w tym ticku (input nie
        // jest przesyłany), więc zwracamy 0.0 jako wartość NOMINALNĄ (brak
        // skoku), ale sam offset dopuszczalny na tej osi jest rozszerzony w
        // maxVerticalJumpAllowance() — używanej przez checki zamiast sztywnej,
        // stałej tolerancji, żeby rozróżnić "stoi" (offset ~0) od "właśnie
        // skoczył" (offset do pełnej wysokości skoku z Jump Boost).
        return 0.0;
    }

    /**
     * Maksymalna dopuszczalna deltaY w ticku, w którym gracz odbija się od
     * ziemi (uwzględniając Jump Boost). Checki ruchu (Flight, Speed) powinny
     * używać TEJ wartości jako alternatywnej, szerszej tolerancji na osi Y
     * zamiast pojedynczego sztywnego progu — offset mieszczący się w tym
     * zakresie jest legalnym skokiem, nie naruszeniem.
     */
    public static double maxVerticalJumpAllowance(Player player) {
        double jump = JUMP_VELOCITY;
        if (player.hasPotionEffect(PotionEffectType.JUMP_BOOST)) {
            int amp = player.getPotionEffect(PotionEffectType.JUMP_BOOST).getAmplifier() + 1;
            jump += JUMP_BOOST_PER_LEVEL * amp;
        }
        // Margines bezpieczeństwa na zaokrąglenia protokołu i jitter sieci.
        return jump + 0.03;
    }

    /**
     * Wykrywa, czy gracz "zjeżdża" po pionowej ścianie honey block — warunek
     * to kolizja pozioma (horizontalCollision) połączona z obecnością honey
     * block w bloku, z którym koliduje, przybliżone tutaj przez sam fakt
     * dotknięcia honey blocku podczas ruchu w powietrzu z kolizją poziomą.
     */
    private static boolean isSlidingDownWall(MovementData current) {
        return current.horizontalCollision && !current.actuallyOnGround;
    }

    /**
     * Maksymalne możliwe przyspieszenie poziome w jednym ticku, uwzględniając
     * sprint, potion Speed/Slowness, sneak, Soul Speed (na soul sand/soul soil)
     * oraz efekt bloku (lód/slime pozwalają zachować prędkość, ale nie
     * zwiększają samo przyspieszenie z inputu — to zwiększenie GRANICY, nie
     * przyrostu na tick).
     */
    public static double maxHorizontalAcceleration(Player player, MovementData current) {
        double base = 0.02; // bazowe przyspieszenie inputu vanilla (moveSpeed default 0.1 / 5 kroków rozpędu)

        double speedMultiplier = 1.0;
        if (player.hasPotionEffect(PotionEffectType.SPEED)) {
            int amp = player.getPotionEffect(PotionEffectType.SPEED).getAmplifier() + 1;
            speedMultiplier += 0.2 * amp;
        }
        if (player.hasPotionEffect(PotionEffectType.SLOWNESS)) {
            int amp = player.getPotionEffect(PotionEffectType.SLOWNESS).getAmplifier() + 1;
            speedMultiplier -= 0.15 * amp;
            speedMultiplier = Math.max(speedMultiplier, 0.0);
        }
        if (current.sprinting) {
            speedMultiplier *= SPRINT_MULTIPLIER;
        }
        if (current.sneaking && current.actuallyOnGround) {
            speedMultiplier *= SNEAK_MULTIPLIER + 0.7; // sneak nie blokuje pełnego przyspieszenia natychmiast
        }
        if (current.onSoulSand && current.actuallyOnGround) {
            int soulSpeedLevel = soulSpeedLevel(player);
            if (soulSpeedLevel > 0) {
                // Soul Speed neguje spowolnienie soul sand i dodaje bonus prędkości.
                speedMultiplier *= 1.0 + SOUL_SPEED_MULTIPLIER_PER_LEVEL * soulSpeedLevel;
            } else {
                // Bez Soul Speed, soul sand spowalnia ruch poziomy (~0.4x realnej prędkości wynikowej).
                speedMultiplier *= 0.4;
            }
        }

        double accel = base * speedMultiplier * 6.0; // margines bezpieczeństwa na rozpęd wielotickowy + jitter sieci

        // Sprint-jump boost: vanilla dodaje jednorazowy impuls poziomy
        // (SPRINT_JUMP_BOOST_X w kierunku patrzenia) dokładnie w ticku, w
        // którym gracz sprintujący odbija się od ziemi. Bez tego bonusu,
        // każdy bunny-hop (bardzo częsty, w pełni legalny styl gry — skakanie
        // podczas sprintu dla nieznacznego zysku prędkości) generował fałszywy
        // offset w SpeedCheck, bo przewidywana górna granica nie uwzględniała
        // tego dodatkowego impulsu w ticku odbicia.
        boolean justJumpedWhileSprinting = current.sprinting && !current.actuallyOnGround
            && current.deltaY > 0.2; // pierwszy tick po odbiciu — deltaY bliska pełnej wysokości skoku
        if (justJumpedWhileSprinting) {
            accel += SPRINT_JUMP_BOOST_X;
        }

        // Efekt bloku pod nogami (lód/slime pozwalają zachować prędkość, nie zwiększają input-accel)
        return accel;
    }

    /** Poziom enchantu Soul Speed na butach gracza (0 jeśli brak). */
    private static int soulSpeedLevel(Player player) {
        org.bukkit.inventory.ItemStack boots = player.getInventory().getBoots();
        if (boots == null) return 0;
        return boots.getEnchantmentLevel(org.bukkit.enchantments.Enchantment.SOUL_SPEED);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Movement envelope — pełny expected state (punkt 1 specyfikacji: expected
    // state / expected position / expected velocity / legal movement envelope /
    // actual state / deviation, zamiast pojedynczej wartości + próg).
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Buduje pełny MovementEnvelope dla bieżącego ticka: expected velocity
     * (środek) + legalny zakres min/max per oś + confidence predykcji.
     *
     * Zbudowane NA ISTNIEJĄCEJ predictNextMovement/maxHorizontalAcceleration
     * (nie duplikuje tej logiki) — envelope to po prostu {expected ± tolerancja}
     * z tolerancją i confidence dobranymi per-kontekst zamiast jednego
     * globalnego marginesu.
     */
    public static MovementEnvelope computeEnvelope(Player player, PlayerData data, MovementData current, MovementData previous) {
        Prediction prediction = predictNextMovement(player, data, current, previous);

        double confidence = 1.0;
        StringBuilder note = new StringBuilder();

        if (previous == null) {
            // Brak historii (dopiero co dołączył / pierwszy przetworzony tick) —
            // nie mamy PRZED-tickowej prędkości, z której cokolwiek ekstrapolować.
            confidence = 0.3;
            note.append("no-history;");
        } else {
            boolean environmentChanged = previous.actuallyOnGround != current.actuallyOnGround
                || previous.inWater != current.inWater
                || previous.inLava != current.inLava
                || previous.onClimbable != current.onClimbable
                || previous.inBubbleColumn != current.inBubbleColumn
                || previous.gliding != current.gliding
                || previous.inVehicle != current.inVehicle;
            if (environmentChanged) {
                // Pierwszy tick po zmianie medium (wejście do wody, odbicie od
                // ziemi, wejście na drabinę...) — model fizyki dla NOWEGO stanu
                // dopiero zaczyna obowiązywać, a serwer nie zna dokładnego
                // input gracza w tym przejściowym momencie.
                confidence *= 0.55;
                note.append("environment-change;");
            }
        }

        boolean justJumped = previous != null && previous.actuallyOnGround
            && !current.actuallyOnGround && current.deltaY > 0;
        if (justJumped) {
            // Moment odbicia: kierunek/siła strafe'a w chwili skoku (nieznane
            // serwerowi) ma nieproporcjonalnie duży wpływ na wynikowy wektor
            // poziomy względem zwykłego lotu ustalonego.
            confidence *= 0.7;
            note.append("jump-impulse;");
        }

        if (current.touchingPistonOrMovingBlock) {
            // Ruchome bloki mogą legalnie przesunąć gracza w sposób, którego
            // ten silnik (skupiony na fizyce SAMEGO gracza) nie modeluje.
            confidence *= 0.4;
            note.append("moving-block;");
        }

        confidence = clamp(confidence, 0.15, 1.0); // nigdy nie spadamy do zera — patrz javadoc confidenceWeightedSeverity

        double horizontalTolerance = prediction.horizontalOffset;
        // Przy niskiej confidence zakres jest proporcjonalnie szerszy — mniej
        // pewna predykcja powinna generować SZERSZY, nie węższy envelope,
        // żeby nie karać za odchylenia wynikające z samej niepewności modelu.
        double confidenceWidening = 1.0 + (1.0 - confidence) * 1.5;
        double hTol = horizontalTolerance * confidenceWidening;

        double centerY, minY, maxY;
        if (justJumped) {
            // W momencie odbicia prediction.deltaY (z gałęzi "swobodny spadek"
            // w predictNextMovement) NIE jest właściwym środkiem envelope —
            // ta gałąź zakłada kontynuację lotu, nie start nowego skoku.
            // Envelope dla tego ticka to [0, maxVerticalJumpAllowance] — od
            // "wcale nie skoczył jeszcze w tym pakiecie" (0) do "pełna
            // wysokość skoku z Jump Boost" (maxVerticalJumpAllowance), z
            // centrum w połowie tego zakresu jako najbardziej prawdopodobną
            // wartością (przeciętny skok).
            double jumpMax = maxVerticalJumpAllowance(player);
            centerY = jumpMax / 2.0;
            minY = -0.03 * confidenceWidening;
            maxY = jumpMax * confidenceWidening;
        } else {
            double verticalTolerance = 0.03 * confidenceWidening;
            centerY = prediction.deltaY;
            minY = prediction.deltaY - verticalTolerance;
            maxY = prediction.deltaY + verticalTolerance;
        }

        return new MovementEnvelope(
            prediction.deltaX, centerY, prediction.deltaZ,
            prediction.deltaX - hTol, prediction.deltaX + hTol,
            minY, maxY,
            prediction.deltaZ - hTol, prediction.deltaZ + hTol,
            confidence, note.toString()
        );
    }

    private static double predictElytraY(Player player, double lastDy) {
        // Uproszczona formuła lotu elytry: opór zależny od kąta patrzenia (pitch).
        float pitch = player.getLocation().getPitch();
        double lookY = -Math.sin(Math.toRadians(pitch));
        double predicted = lastDy;
        if (lookY < 0 && predicted < JUMP_VELOCITY) {
            predicted += (lookY - predicted) * 0.08 - GRAVITY * 0.6;
        } else {
            predicted -= GRAVITY;
        }
        return predicted * 0.99;
    }

    private static double predictBubbleColumnY(MovementData current, double lastDy) {
        // Kolumna bąbelków: przyspiesza w górę (drag) lub w dół (source), granica 0.7-0.9 vanilla.
        return clamp(lastDy + (current.onClimbable ? 0.0 : 0.03), -0.3, 0.9);
    }

    private static boolean hasLevitation(Player player) {
        return player.hasPotionEffect(PotionEffectType.LEVITATION);
    }

    private static boolean hasSlowFalling(Player player) {
        return player.hasPotionEffect(PotionEffectType.SLOW_FALLING);
    }

    private static boolean hasDolphinsGrace(Player player) {
        return player.hasPotionEffect(PotionEffectType.DOLPHINS_GRACE);
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Knockback velocity prediction — pełny łańcuch zamiast pomiaru
    // "największego przemieszczenia w oknie" (VelocityCheck, priorytet 🔴1
    // z przeglądu). Model: velocity przed KB + wektor KB = velocity chwilę po
    // uderzeniu; następnie JEDEN TICK tej samej fizyki, której używa reszta
    // silnika (grawitacja/tarcie/opór wody), daje oczekiwaną velocity PO
    // ticku — to jest dokładnie to, co robi vanilla EntityLiving#push(), a
    // nie tylko "czy gracz przemieścił się wystarczająco daleko".
    // ═════════════════════════════════════════════════════════════════════════

    public static final class VelocityPrediction {
        public final double expectedVx, expectedVy, expectedVz;
        VelocityPrediction(double vx, double vy, double vz) {
            this.expectedVx = vx;
            this.expectedVy = vy;
            this.expectedVz = vz;
        }
    }

    /**
     * Przewiduje wypadkową prędkość gracza JEDEN tick po zaaplikowaniu
     * knockbacku, na podstawie prędkości SPRZED uderzenia i kontekstu
     * środowiska w tym ticku (grunt/woda/lawa/kolizja pozioma).
     *
     * Łańcuch: velocityBeforeKb + kb → (tarcie/opór właściwy dla środowiska,
     * ta sama tabela co reszta silnika) → expected velocity po ticku.
     * VelocityCheck porównuje TO z rzeczywistą zaobserwowaną deltą ruchu,
     * zamiast — jak poprzednio — z samym surowym wektorem KB przez stały
     * współczynnik ratio.
     */
    public static VelocityPrediction predictPostKnockbackVelocity(
            double velBeforeX, double velBeforeY, double velBeforeZ,
            Vector knockback, MovementData environment) {

        double vx = velBeforeX + knockback.getX();
        double vy = velBeforeY + knockback.getY();
        double vz = velBeforeZ + knockback.getZ();

        // Oś Y: ta sama grawitacja/opór co reszta silnika, zależnie od medium.
        double predictedVy;
        if (environment.inWater || environment.inLava) {
            double liquidGravity = environment.inLava ? LAVA_GRAVITY : WATER_GRAVITY;
            predictedVy = (vy - liquidGravity) * LIQUID_HORIZONTAL_DRAG;
        } else if (environment.actuallyOnGround && vy <= 0) {
            // KB pionowe do góry nadal działa nawet stojąc na ziemi (to jest
            // WŁAŚNIE ten impuls, który ma gracza unieść) — ale jeśli po
            // zsumowaniu z KB prędkość pionowa jest ujemna/zerowa, grunt ją
            // pochłania w tym samym ticku (nie ma "podłogowego odbicia" KB).
            predictedVy = 0.0;
        } else {
            predictedVy = (vy - GRAVITY) * AIR_DRAG;
        }

        // Oś pozioma: tarcie gruntu/opór wody/opór powietrza — identyczne
        // źródło co maxHorizontalAcceleration i predictNextMovement, żeby
        // Velocity i Speed/Flight nigdy nie rozjeżdżały się w ocenie tego
        // samego zjawiska fizycznego (punkt "Physics Engine" z przeglądu).
        double horizontalFactor;
        if (environment.inWater) {
            horizontalFactor = LIQUID_HORIZONTAL_DRAG;
        } else if (environment.actuallyOnGround) {
            horizontalFactor = environment.blockFriction;
        } else {
            horizontalFactor = 0.91;
        }

        double predictedVx = vx * horizontalFactor;
        double predictedVz = vz * horizontalFactor;

        // Kolizja pozioma (ściana/przeszkoda) pochłania składową ruchu
        // prostopadłą do przeszkody — nie znamy dokładnej normalnej ściany
        // tutaj (to wymagałoby raytrace bloku), więc konserwatywnie tłumimy
        // obie składowe poziome proporcjonalnie, dając VelocityCheck env
        // (przez CONTEXT_COLLISION_MULTIPLIER) dodatkowy margines zamiast
        // fałszywego zawyżenia oczekiwanej wartości.
        if (environment.horizontalCollision) {
            predictedVx *= 0.4;
            predictedVz *= 0.4;
        }

        return new VelocityPrediction(predictedVx, predictedVy, predictedVz);
    }

    // ── Tarcie bloku ──────────────────────────────────────────────────────────

    /**
     * Zwraca współczynnik tarcia bloku pod graczem, zgodny z tabelą vanilla.
     * Wpływa bezpośrednio na to, jak szybko gracz traci/zachowuje prędkość poziomą.
     * Soul sand NIE jest śliski — jego spowolnienie działa przez zmniejszenie
     * bazowej prędkości ruchu (patrz maxHorizontalAcceleration), nie przez friction,
     * dlatego tutaj zwraca zwykłe tarcie gruntu.
     */
    public static double frictionForBlock(Material type) {
        switch (type) {
            case ICE:
            case FROSTED_ICE:
                return ICE_FRICTION;
            case PACKED_ICE:
                return PACKED_ICE_FRICTION;
            case BLUE_ICE:
                return BLUE_ICE_FRICTION;
            case SLIME_BLOCK:
                return SLIME_FRICTION;
            case SOUL_SAND:
                return SOUL_SAND_FRICTION;
            default:
                return DEFAULT_GROUND_FRICTION;
        }
    }

    /**
     * Sprawdza blok bezpośrednio pod graczem (na potrzeby tarcia) i zwraca
     * jego współczynnik. Używane przez checki Speed/Strafe/Ice.
     */
    public static double frictionAt(World world, double x, double y, double z) {
        Block block = world.getBlockAt(
            (int) Math.floor(x), (int) Math.floor(y - 0.01), (int) Math.floor(z));
        return frictionForBlock(block.getType());
    }
}
