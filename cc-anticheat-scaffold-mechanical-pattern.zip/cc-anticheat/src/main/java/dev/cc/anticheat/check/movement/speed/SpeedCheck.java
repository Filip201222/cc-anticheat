/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.movement.speed;

import dev.cc.anticheat.CCAnticheat;
import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.predict.MovementEnvelope;
import dev.cc.anticheat.predict.PlayerPhysicsEngine;
import dev.cc.anticheat.predict.SetbackUtil;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

/**
 * cc-anticheat — SpeedCheck
 *
 * Wykrywa nadmierną prędkość poziomą, porównując faktyczny ruch gracza z górną
 * granicą fizycznie możliwego przyspieszenia w danym ticku (PlayerPhysicsEngine).
 *
 * W przeciwieństwie do prostego "if (horizontalSpeed > 0.29) flag()", ten check:
 *   - buduje oczekiwaną prędkość z poprzedniego wektora ruchu * tarcie bloku
 *     pod graczem + maksymalne możliwe przyspieszenie z inputu (sprint/potion/sneak),
 *   - analizuje SEKWENCJĘ ticków (accumulator), nie pojedynczy pakiet — jeden
 *     szybki tick po nierównej podłodze (np. zejście ze schodów) nie flaguje,
 *     ale utrzymująca się nadwyżka prędkości przez kilka ticków rośnie w VL,
 *   - uwzględnia efekty mikstur, sprint, sneak, oraz tarcie bloku (lód/slime
 *     legalnie pozwalają zachować dużą prędkość bez przyspieszania z inputu).
 */
public class SpeedCheck extends Check {

    private static final double BASE_TOLERANCE = 0.06;
    /** Na lodzie/lodzie spakowanym/niebieskim gracz zachowuje prędkość znacznie
     *  dłużej (tarcie 0.98-0.989) — legalne krótkotrwałe skoki prędkości przy
     *  zmianie kierunku na śliskiej powierzchni wymagają szerszej tolerancji. */
    private static final double ICE_TOLERANCE_BONUS = 0.05;
    /** Honey Block spowalnia ruch bardzo mocno i nierównomiernie w pierwszym
     *  ticku kontaktu (kolizja z niższym hitboxem) — dajemy margines na przejście. */
    private static final double HONEY_TOLERANCE_BONUS = 0.04;

    /** Akumulator nadwyżki prędkości w czasie — rośnie z utrzymującym się naruszeniem. */
    private double excessAccumulator = 0;

    private final CCAnticheat plugin;

    public SpeedCheck(PlayerData data, ViolationProcessor vp, CCAnticheat plugin) {
        super(data, vp, "Speed/Horizontal");
        this.plugin = plugin;
        this.vlIncrement = 1.0;
        this.vlDecay = 0.1;
        this.vlDecayMultiplier = 0.96;
        this.flagThreshold = 5.0;
        this.setbackThreshold = 14.0;
        this.requiredBuffer = 4;
        this.maxBuffer = 25;
    }

    public void onMovement(MovementData current) {
        Player player = data.player;

        if (tickExemption()) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (player.isFlying() || player.getAllowFlight()) return;
        if (data.awaitingTeleportConfirm) return;
        if (current.inVehicle || current.inWater || current.inLava || current.onClimbable
            || current.inWeb || current.inBubbleColumn || current.gliding) {
            // Te środowiska mają własne checki (Jesus/Spider/Climb) z inną fizyką pozioma.
            excessAccumulator = Math.max(0, excessAccumulator - 0.3);
            reward();
            return;
        }

        MovementData previous = data.movementAgo(1);
        if (previous == null) return;

        PlayerPhysicsEngine.Prediction prediction =
            PlayerPhysicsEngine.predictNextMovement(player, data, current, previous);

        double actualHorizontal = current.horizontalDistance();
        double predictedBase = Math.sqrt(prediction.deltaX * prediction.deltaX + prediction.deltaZ * prediction.deltaZ);

        double tolerance = BASE_TOLERANCE + contextualToleranceBonus(current);
        double maxAllowed = predictedBase + prediction.horizontalOffset + tolerance;

        double excess = actualHorizontal - maxAllowed;

        if (excess > 0) {
            excessAccumulator += excess;
            double rawSeverity = Math.min(excess * 15.0, 4.0) * (1.0 + Math.min(excessAccumulator * 2.0, 2.0));
            // confidenceWeightedSeverity (patrz MovementEnvelope) tłumi karę,
            // gdy envelope tego ticka miało obniżoną pewność (np. tuż po
            // zmianie środowiska) — ten sam surowy excess znaczy mniej, gdy
            // sama predykcja była z natury niepewna.
            MovementEnvelope envelope = current.envelope;
            double severity = envelope != null ? envelope.confidenceWeightedSeverity(rawSeverity) : rawSeverity;
            buffer(severity, String.format(
                "actual:%.4f maxAllowed:%.4f excess:%.4f accum:%.4f tolerance:%.3f confidence:%.2f",
                actualHorizontal, maxAllowed, excess, excessAccumulator, tolerance,
                envelope != null ? envelope.confidence : 1.0));
        } else {
            excessAccumulator = Math.max(0, excessAccumulator - 0.05);
            reward();
        }

        if (getViolationLevel() >= setbackThreshold) {
            SetbackUtil.performSetback(plugin, data, "Speed/Horizontal");
            excessAccumulator = 0;
        }
    }

    /**
     * Dodatkowy margines tolerancji zależny od bloku pod graczem — lód i honey
     * mają nietypową dynamikę zachowania/utraty prędkości, którą pełna predykcja
     * fizyki przybliża, ale nie modeluje co do ticka idealnie (m.in. przez to,
     * że nie znamy dokładnego inputu WASD gracza).
     */
    private double contextualToleranceBonus(MovementData current) {
        if (!current.actuallyOnGround) return 0.0;
        if (current.onIce) return ICE_TOLERANCE_BONUS;
        if (current.onHoneyBlock) return HONEY_TOLERANCE_BONUS;
        return 0.0;
    }

    @Override
    public void reset() {
        super.reset();
        excessAccumulator = 0;
    }
}
