/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat;

import dev.cc.anticheat.bait.BaitEspManager;
import dev.cc.anticheat.command.AnticheatCommand;
import dev.cc.anticheat.data.AlertHistory;
import dev.cc.anticheat.gui.GuiListener;
import dev.cc.anticheat.manager.AlertManager;
import dev.cc.anticheat.manager.BukkitListener;
import dev.cc.anticheat.manager.CheckManager;
import dev.cc.anticheat.manager.PacketListener;
import dev.cc.anticheat.manager.SpectateManager;
import dev.cc.anticheat.predict.EntityHistoryTracker;
import dev.cc.anticheat.predict.EntityLookup;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * cc-anticheat — Main Plugin Class
 *
 * Hybrid anticheat combining:
 *   COMBAT   → Intave's statistical click analysis, raytrace, KillAura, AimBot detection
 *   MOVEMENT → Grim-inspired transaction-free timer, physics prediction, velocity tracking
 *
 * Plus staff tooling:
 *   ALERTS   → clickable, Intave-style chat alerts with on/off toggle
 *   GUI      → player-info GUI (head, alert/kick/ban history, spectate button)
 *   SPECTATE → jump into spectator mode on a suspect and back
 *   BAIT ESP → decoy player visible only to one client, for catching ESP/X-ray cheats
 *
 * Requires: ProtocolLib
 */
public class CCAnticheat extends JavaPlugin {

    private static CCAnticheat instance;

    private ViolationProcessor violationProcessor;
    private CheckManager       checkManager;
    private PacketListener     packetListener;
    private BukkitListener     bukkitListener;

    private AlertHistory    alertHistory;
    private AlertManager    alertManager;
    private SpectateManager spectateManager;
    private BaitEspManager  baitEspManager;

    /** Ostatnio zmierzone TPS serwera, odświeżane cyklicznie — patrz startTpsTracking(). */
    private volatile double currentTps = 20.0;

    @Override
    public void onEnable() {
        instance = this;

        // Dependency check
        if (!Bukkit.getPluginManager().isPluginEnabled("ProtocolLib")) {
            getLogger().severe("ProtocolLib not found! cc-anticheat requires ProtocolLib.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        saveDefaultConfig();

        // Init subsystems
        alertHistory    = new AlertHistory();
        alertManager    = new AlertManager(this, alertHistory);
        spectateManager = new SpectateManager(this);
        baitEspManager  = new BaitEspManager(this);

        violationProcessor = new ViolationProcessor(this);
        checkManager       = new CheckManager(this, violationProcessor);
        packetListener     = new PacketListener(this, checkManager);
        bukkitListener     = new BukkitListener(this, checkManager);

        Bukkit.getPluginManager().registerEvents(bukkitListener, this);
        Bukkit.getPluginManager().registerEvents(new GuiListener(this), this);

        // Register /anticheat command
        AnticheatCommand cmd = new AnticheatCommand(this);
        getCommand("anticheat").setExecutor(cmd);
        getCommand("anticheat").setTabCompleter(cmd);

        // Register online players (reload support)
        Bukkit.getOnlinePlayers().forEach(checkManager::onJoin);

        startTpsTracking();
        startPingTracking();
        startViolationDecay();
        startEntityHistoryTracking();

        getLogger().info("cc-anticheat enabled. Combat: Intave-model | Movement: physics-prediction model");
    }

    @Override
    public void onDisable() {
        if (packetListener != null) packetListener.unregister();
        getLogger().info("cc-anticheat disabled.");
    }

    /**
     * Śledzenie TPS serwera przez natywne Paper API (Bukkit#getTPS()), odświeżane
     * co sekundę. Używane przez TimerCheck do korekty progu przy lagu serwerowym
     * (lag compensation) — patrz CheckManager#onClientTickEnd.
     */
    private void startTpsTracking() {
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            try {
                double[] tps = Bukkit.getTPS();
                if (tps != null && tps.length > 0) {
                    currentTps = Math.min(20.0, tps[0]);
                }
            } catch (NoSuchMethodError | Exception ignored) {
                // Bukkit#getTPS() niedostępne na tym forku serwera — zostajemy przy ostatniej znanej wartości.
            }
        }, 20L, 20L);
    }

    /**
     * Aktualizacja pingu graczy co sekundę przez natywne Paper API (Player#getPing()),
     * zasilająca PlayerData#pingHistory dla VelocityCheck i innych checków
     * korzystających z lag compensation.
     */
    private void startPingTracking() {
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (checkManager == null) return;
            for (Player player : Bukkit.getOnlinePlayers()) {
                dev.cc.anticheat.data.PlayerData data = checkManager.getData(player);
                if (data == null) continue;
                try {
                    data.pushPing(player.getPing());
                } catch (NoSuchMethodError ignored) {
                    // Starszy fork bez Player#getPing() — ping zostaje na ostatniej znanej wartości.
                }
            }
        }, 20L, 20L);
    }

    /**
     * Cykliczny zanik globalnych punktów karnych (patrz ViolationProcessor) —
     * zapobiega kumulacji drobnych, dawnych incydentów w nieskończoność.
     */
    private void startViolationDecay() {
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                violationProcessor.decayGlobalPoints(player.getUniqueId());
            }
        }, 20L, 20L);
    }

    /**
     * Nagrywa pozycję każdej żywej encji CO TICK (nie co sekundę — dokładność
     * co do ticka jest kluczowa dla lag-compensated angle/reach checków w
     * combat, patrz EntityHistoryTracker). Osobny task co 5 sekund sprząta
     * historię encji, które dawno przestały być aktualizowane (despawn/wyjście
     * z załadowanego chunka), żeby mapa nie rosła w nieskończoność.
     */
    /**
     * Nagrywa pozycję każdej żywej encji CO TICK (nie co sekundę — dokładność
     * co do ticka jest kluczowa dla lag-compensated angle/reach checków w
     * combat, patrz EntityHistoryTracker). Osobny task co 5 sekund sprząta
     * historię encji, które dawno przestały być aktualizowane (despawn/wyjście
     * z załadowanego chunka), żeby mapa nie rosła w nieskończoność.
     *
     * Ten sam przebieg zasila też EntityLookup (entityId → Entity, punkt 14
     * specyfikacji) — rejestrujemy WSZYSTKIE encje (nie tylko LivingEntity,
     * bo atak może celować też np. w ArmorStand/ItemFrame), żeby
     * ReachCheck/CheckManager miały O(1) lookup zamiast world.getEntities()
     * przy każdym pakiecie ataku. Zero dodatkowego kosztu iteracji — mapa
     * jest budowana przy okazji tej samej pętli, która i tak już przechodzi
     * po wszystkich encjach dla EntityHistoryTracker.
     */
    private void startEntityHistoryTracking() {
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            java.util.Set<Integer> seenThisTick = new java.util.HashSet<>();
            for (World world : Bukkit.getWorlds()) {
                for (Entity entity : world.getEntities()) {
                    if (!entity.isValid()) continue;

                    EntityLookup.register(entity);
                    seenThisTick.add(entity.getEntityId());

                    if (entity instanceof LivingEntity) {
                        EntityHistoryTracker.recordPosition(entity);
                    }
                }
            }
            EntityLookup.purgeMissing(seenThisTick);
        }, 1L, 1L);

        Bukkit.getScheduler().runTaskTimer(this, () -> EntityHistoryTracker.purgeStale(10_000L), 100L, 100L);
    }

    public double getCurrentTps() {
        return currentTps;
    }

    public static CCAnticheat getInstance()           { return instance; }
    public CheckManager       getCheckManager()       { return checkManager; }
    public ViolationProcessor getViolationProcessor() { return violationProcessor; }
    public AlertHistory       getAlertHistory()       { return alertHistory; }
    public AlertManager       getAlertManager()       { return alertManager; }
    public SpectateManager    getSpectateManager()    { return spectateManager; }
    public BaitEspManager     getBaitEspManager()     { return baitEspManager; }
}
