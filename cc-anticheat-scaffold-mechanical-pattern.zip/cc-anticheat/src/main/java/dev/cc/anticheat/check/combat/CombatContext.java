/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.combat;

/**
 * cc-anticheat — CombatContext
 *
 * Wspólny kontekst POJEDYNCZEGO ataku, dzielony między KillAuraCheck i
 * AimBotCheck (przegląd, punkt 🔴2 "AimBot + CombatContext — połącz AimBot,
 * KillAura i Reach przez wspólny kontekst ataku").
 *
 * Wcześniej te checki analizowały ten sam atak w pełnej izolacji od siebie —
 * każdy miał własne obliczenie kąta/rotacji i własny VL, bez możliwości
 * stwierdzenia "te niezależne anomalie dotyczą TEGO SAMEGO ataku".
 * CombatContext to naprawia dla KillAura i AimBot (oba dają wynik
 * SYNCHRONICZNIE w momencie ataku): każdy z nich, przetwarzając atak,
 * ZAPISUJE swój wynik tutaj, a CheckManager na końcu dispatchu sprawdza,
 * czy WIĘCEJ NIŻ JEDEN zgłosił coś podejrzanego — jeśli tak, przekazuje to
 * jako dodatkowy sygnał korelacji do ViolationProcessor (punkt 🟠6 z
 * przeglądu: "jeśli jednocześnie Aim anomaly + Reach anomaly, confidence
 * powinien rosnąć mocniej niż przy dwóch całkowicie niezależnych flagach").
 *
 * Instancja jest tworzona raz na atak (nie per-gracza-na-stałe) i odrzucana
 * zaraz po odczytaniu — nie ma żadnego trwałego stanu, więc nie wpływa na
 * pamięć/wydajność (punkt "performance" z przeglądu).
 */
public final class CombatContext {

    /** Czy KillAuraCheck naliczył korelacyjne punkty powyżej progu w tym ataku. */
    public boolean killAuraAnomaly;
    /** Czy AimBotCheck wykrył snap kończący się idealnym domknięciem na celu w tym ataku. */
    public boolean aimBotSnapAnomaly;

    /** Liczba niezależnych checków combat, które zgłosiły anomalię w tym ataku. */
    public int anomalyCount() {
        int count = 0;
        if (killAuraAnomaly) count++;
        if (aimBotSnapAnomaly) count++;
        return count;
    }

    /**
     * Mnożnik korelacji do zastosowania na globalnych punktach karnych
     * (patrz ViolationProcessor#flag) — rośnie, gdy WIĘCEJ NIŻ JEDEN
     * niezależny check combat zgłasza anomalię w tym samym ataku, bo
     * skorelowany sygnał jest silniejszym dowodem niż suma tych samych
     * incydentów rozproszonych w czasie.
     *
     * ReachCheck świadomie NIE uczestniczy w tym kontekście — jego
     * weryfikacja jest z natury opóźniona (kolejkowana do momentu, w którym
     * pozycja atakującego jest w pełni potwierdzona przez serwer, patrz
     * ReachCheck#onMovement), więc nie da się jej ocenić SYNCHRONICZNIE w
     * chwili ataku tak jak KillAura/AimBot. Reach nadal wzmacnia globalną
     * eskalację przez współdzielone globalPoints w ViolationProcessor,
     * tylko bez natychmiastowego mnożnika korelacji tego konkretnego ataku.
     */
    public double correlationMultiplier() {
        return anomalyCount() >= 2 ? 1.8 : 1.0;
    }
}
