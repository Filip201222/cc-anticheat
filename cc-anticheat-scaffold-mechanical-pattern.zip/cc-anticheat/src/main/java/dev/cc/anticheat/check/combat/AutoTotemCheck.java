/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.combat;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

/**
 * cc-anticheat — AutoTotemCheck
 *
 * Wykrywa automatyczne wkładanie totema do ręki po jego użyciu.
 *
 * Zasada działania:
 *   Kiedy gracz używa totema (animacja odrodzenia), serwer rejestruje czas
 *   zdarzenia oraz liczbę totemów w ekwipunku. Następnie obserwujemy zmianę
 *   zawartości offhand. Jeśli nowy totem pojawił się w czasie krótszym niż
 *   próg ludzkiej reakcji, jest to fizycznie niemożliwe do wykonania ręcznie.
 *
 * Sub-checki:
 *   A. Reaction Time — czas między użyciem totema a pojawieniem się nowego
 *      w offhand jest poniżej progu ludzkiej reakcji (< 105 ms)
 *   B. Inventory Slot Swap — gracz miał ≥2 totemy w ekwipunku i swap
 *      nastąpił w ciągu jednego ticka (≤50ms)
 */
public class AutoTotemCheck extends Check {

    private static final long HUMAN_REACTION_MIN_MS = 105L;
    private static final long SWAP_WINDOW_MS = 2000L;

    private long lastTotemUseMs = 0L;
    private boolean awaitingSwap = false;
    private int totemsAtUse = 0;

    public AutoTotemCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "AutoTotem");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.1;
        this.vlDecayMultiplier = 0.9;
        this.flagThreshold = 3.0;
        this.setbackThreshold = Double.MAX_VALUE;
        this.requiredBuffer = 0; // AutoTotem jest dyskretnym zdarzeniem — flaguj natychmiast, nie ma "sekwencji"
        this.maxBuffer = 5;
    }

    /**
     * Wywołane gdy gracz użył totema (EntityResurrectEvent).
     */
    public void onTotemUse() {
        if (tickExemption()) return;
        lastTotemUseMs = System.currentTimeMillis();
        awaitingSwap = true;
        totemsAtUse = countTotems(data.player);
    }

    /**
     * Wywołane przy akcji w ekwipunku (window click / item swap), z opóźnieniem
     * 1 ticka od PacketListener/BukkitListener, żeby slot zdążył się zaktualizować.
     */
    public void onInventoryAction() {
        if (!awaitingSwap) return;

        long now = System.currentTimeMillis();
        long elapsed = now - lastTotemUseMs;

        if (elapsed > SWAP_WINDOW_MS) {
            awaitingSwap = false;
            return;
        }

        Player player = data.player;
        ItemStack offhand = player.getInventory().getItemInOffHand();
        boolean newTotemInOffhand = offhand != null && offhand.getType() == Material.TOTEM_OF_UNDYING;

        if (!newTotemInOffhand) return;

        boolean flagged = false;

        // ── A. Czas reakcji ────────────────────────────────────────────────
        if (elapsed < HUMAN_REACTION_MIN_MS) {
            buffer(3.5, String.format("sub:ReactionTime swapMs:%d threshold:%d", elapsed, HUMAN_REACTION_MIN_MS));
            flagged = true;
        }

        // ── B. Natychmiastowy swap z wielu totemów ──────────────────────────
        if (totemsAtUse >= 2 && elapsed <= 50L) {
            buffer(5.0, String.format("sub:InstantSwap swapMs:%d totemsHeld:%d", elapsed, totemsAtUse));
            flagged = true;
        }

        if (!flagged) {
            reward();
        }

        awaitingSwap = false;
    }

    // ── Pomocniki ─────────────────────────────────────────────────────────────

    private static int countTotems(Player player) {
        PlayerInventory inv = player.getInventory();
        int count = 0;
        for (ItemStack item : inv.getContents()) {
            if (item != null && item.getType() == Material.TOTEM_OF_UNDYING) {
                count += item.getAmount();
            }
        }
        ItemStack off = inv.getItemInOffHand();
        if (off != null && off.getType() == Material.TOTEM_OF_UNDYING) {
            count += off.getAmount();
        }
        return count;
    }

    @Override
    public void reset() {
        super.reset();
        awaitingSwap = false;
        totemsAtUse = 0;
    }
}
