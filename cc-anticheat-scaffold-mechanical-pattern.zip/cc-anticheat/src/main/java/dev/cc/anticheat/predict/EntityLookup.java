/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.predict;

import org.bukkit.entity.Entity;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * cc-anticheat — EntityLookup
 *
 * Szybki lookup entityId → Entity, zastępujący wzorzec
 * "for (Entity e : world.getEntities()) if (e.getEntityId() == id)" — który
 * jest O(n) i był wykonywany PRZY KAŻDYM ataku/pakiecie (USE_ENTITY, BLOCK_DIG
 * po celowniku itd.), więc przy dużej liczbie encji na serwerze (moby, itemy,
 * pociski) i wielu graczach walczących jednocześnie stawał się realnym
 * wąskim gardłem.
 *
 * Zasilany raz na tick przez ten sam task, który już iteruje po wszystkich
 * encjach dla EntityHistoryTracker#recordPosition (CCAnticheat#startEntityHistoryTracking)
 * — więc lookup nie kosztuje ŻADNEJ dodatkowej iteracji ponad to, co i tak
 * już się dzieje; tylko dopisujemy encję do mapy przy okazji.
 *
 * Wpisy o encjach, które przestały być zwracane przez World#getEntities()
 * (despawn, wyjście z załadowanego chunka) są usuwane w tym samym cyklu
 * przez porównanie z poprzednim stanem — patrz refresh().
 */
public final class EntityLookup {

    private static final Map<Integer, Entity> byId = new ConcurrentHashMap<>();

    private EntityLookup() {}

    /** Wołane raz na encję, raz na tick — patrz CCAnticheat#startEntityHistoryTracking. */
    public static void register(Entity entity) {
        byId.put(entity.getEntityId(), entity);
    }

    /** O(1) lookup — zastępuje pętlę po world.getEntities(). Zwraca null jeśli encja nieznana/despawnięta. */
    public static Entity get(int entityId) {
        Entity entity = byId.get(entityId);
        if (entity != null && !entity.isValid()) {
            // Encja despawnęła między ostatnim tickiem rejestracji a tym
            // lookupem — sprzątamy od razu zamiast czekać na następny purge,
            // żeby wywołujący nie dostał martwej referencji.
            byId.remove(entityId, entity);
            return null;
        }
        return entity;
    }

    /**
     * Usuwa z mapy wpisy, które nie zostały odświeżone w bieżącym cyklu
     * (encja despawnęła / opuściła załadowany chunk od ostatniego ticka).
     * Wołane raz na tick, PO przejściu register() dla wszystkich aktualnie
     * widocznych encji — seenIds to zbiór ID zarejestrowanych w tym przebiegu.
     */
    public static void purgeMissing(java.util.Set<Integer> seenIds) {
        byId.keySet().removeIf(id -> !seenIds.contains(id));
    }

    public static void forget(int entityId) {
        byId.remove(entityId);
    }

    public static int size() {
        return byId.size();
    }
}
