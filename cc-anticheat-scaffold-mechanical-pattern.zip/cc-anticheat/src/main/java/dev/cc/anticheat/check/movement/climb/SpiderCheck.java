/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.movement.climb;

import dev.cc.anticheat.CCAnticheat;
import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.predict.SetbackUtil;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

/**
 * cc-anticheat — SpiderCheck
 *
 * Wykrywa "Spider" — wspinanie się po pionowej ścianie bez bloku wspinaczkowego
 * (drabina/pnącze/scaffolding) pod/obok gracza.
 *
 * W vanilla, wznoszenie się (deltaY > 0) bez skoku jest możliwe wyłącznie gdy:
 *   - gracz jest na climbable (drabina, pnącze, scaffolding, cave vines),
 *   - gracz jest w cieczy z bąbelkami (bubble column w górę),
 *   - gracz właśnie skoczył (krótka, opadająca krzywa paraboliczna),
 *   - gracz ma Levitation.
 *
 * Spider cheat pozwala wznosić się przy kolizji poziomej ze ścianą (pchanie się
 * w blok) BEZ żadnego z powyższych — dlatego kluczowym sygnałem jest
 * jednoczesne wystąpienie: kolizji poziomej + dodatniej deltaY + brak climbable.
 */
public class SpiderCheck extends Check {

    private final CCAnticheat plugin;

    public SpiderCheck(PlayerData data, ViolationProcessor vp, CCAnticheat plugin) {
        super(data, vp, "Spider");
        this.plugin = plugin;
        this.vlIncrement = 1.0;
        this.vlDecay = 0.15;
        this.vlDecayMultiplier = 0.93;
        this.flagThreshold = 4.0;
        this.setbackThreshold = 10.0;
        this.requiredBuffer = 2;
        this.maxBuffer = 15;
    }

    public void onMovement(MovementData current) {
        Player player = data.player;

        if (tickExemption()) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (player.isFlying() || player.getAllowFlight()) return;
        if (data.awaitingTeleportConfirm) return;

        boolean exemptContext = current.onClimbable || current.inBubbleColumn
            || current.inWater || current.inLava || current.gliding
            || current.actuallyOnGround || current.touchingPistonOrMovingBlock
            || player.hasPotionEffect(org.bukkit.potion.PotionEffectType.LEVITATION);

        if (exemptContext) {
            reward();
            return;
        }

        MovementData previous = data.movementAgo(1);
        boolean recentlyJumped = previous != null && previous.actuallyOnGround && previous.deltaY > 0.35;

        if (recentlyJumped) {
            // Legalny skok — pierwszy tick po odbiciu ma dodatnią deltaY nawet
            // przy kolizji poziomej (np. skok w stronę ściany).
            reward();
            return;
        }

        boolean ascending = current.deltaY > 0.06;
        boolean pressingWall = current.horizontalCollision;

        if (ascending && pressingWall) {
            double severity = Math.min(current.deltaY * 10.0, 3.0);
            buffer(severity, String.format("deltaY:%.4f horizontalCollision:%b", current.deltaY, pressingWall));
        } else {
            reward();
        }

        if (getViolationLevel() >= setbackThreshold) {
            SetbackUtil.performSetback(plugin, data, "Spider");
        }
    }
}
