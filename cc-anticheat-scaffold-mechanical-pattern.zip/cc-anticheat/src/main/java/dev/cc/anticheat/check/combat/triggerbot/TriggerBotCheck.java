/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.combat.triggerbot;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;

/**
 * cc-anticheat — TriggerBotCheck
 *
 * Wykrywa "TriggerBot" — automatyczne atakowanie w momencie, gdy cel wchodzi
 * na linię celowania gracza (crosshair), bez ludzkiego inputu decyzyjnego.
 *
 * Różni się od KillAura/AimBot tym, że TriggerBot NIE zmienia rotacji gracza
 * (gracz sam celuje myszą) — bot tylko "naciska" atak automatycznie, kiedy
 * wykryje entity pod celownikiem. Sygnatura: atak następuje w bardzo krótkim,
 * spójnym czasie po tym, jak cel faktycznie znalazł się na linii wzroku
 * gracza (raytrace), z niemal zerową wariancją między kolejnymi atakami —
 * człowiek ma naturalny, zmienny czas reakcji.
 *
 * Sub-checki:
 *   A. Reaction Consistency — niska wariancja czasu (target-in-crosshair → atak)
 *   B. Reaction Time — czas reakcji poniżej ludzkiego minimum, wymagający
 *      POWTARZALNOŚCI w krótkim oknie (nie pojedynczy szybki atak — patrz
 *      naprawa poniżej)
 *   C. Look-then-attack correlation — atak następuje ZAWSZE i WYŁĄCZNIE gdy
 *      cel jest idealnie wyśrodkowany na celowniku (małe FOV), co u ludzi
 *      ma dużo większy rozrzut kątowy w momencie kliknięcia.
 *
 * NAPRAWA (priorytet 🟡14): sub-check B (Reaction Time) flagował na
 * podstawie POJEDYNCZEGO szybkiego trafienia — ale człowiek może przypadkiem
 * trafić bardzo szybko, jeśli już naciskał atak z niepowiązanego powodu
 * (np. dobijanie moba) dokładnie w momencie, gdy nowy cel wszedł na
 * celownik. Teraz wymagamy co najmniej 2 szybkich trafień w krótkim oknie
 * (3s) zanim ten sub-check faktycznie zgłosi naruszenie — analogicznie do
 * naprawy zastosowanej w KillAura/AimBot (spójność w czasie, nie
 * jednorazowy zbieg okoliczności).
 */
public class TriggerBotCheck extends Check {

    private static final long HUMAN_REACTION_MIN_MS = 90L;
    private static final int CONSISTENCY_SAMPLE_MIN = 6;
    private static final double CONSISTENCY_CV_THRESHOLD = 0.05;
    private static final double TIGHT_AIM_DEGREES = 3.0;
    private static final long FAST_REACTION_WINDOW_MS = 3000L;
    private static final int FAST_REACTION_MIN_COUNT = 2;

    private final ArrayDeque<Long> reactionTimes = new ArrayDeque<>(20);
    private final ArrayDeque<Double> attackAngles = new ArrayDeque<>(20);
    private final ArrayDeque<Long> fastReactionTimestamps = new ArrayDeque<>(10);

    /** Timestamp, w którym cel po raz pierwszy wszedł idealnie na celownik gracza (ustawiane przez onTick). */
    private long targetAcquiredMs = 0L;
    private int currentTargetEntityId = -1;

    public TriggerBotCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "TriggerBot");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.08;
        this.vlDecayMultiplier = 0.93;
        this.flagThreshold = 4.0;
        this.setbackThreshold = Double.MAX_VALUE;
        this.requiredBuffer = 1;
        this.maxBuffer = 12;
    }

    /**
     * Wołane na każdym ticku ruchu/rotacji — sprawdza, czy jakaś encja jest
     * aktualnie na celowniku gracza (mały kąt od kierunku patrzenia) i
     * zapamiętuje moment, w którym to nastąpiło.
     */
    public void onTick(Entity potentialTarget) {
        if (potentialTarget == null) {
            currentTargetEntityId = -1;
            return;
        }

        double angle = angleToTarget(potentialTarget);

        if (angle < TIGHT_AIM_DEGREES) {
            if (currentTargetEntityId != potentialTarget.getEntityId()) {
                currentTargetEntityId = potentialTarget.getEntityId();
                targetAcquiredMs = System.currentTimeMillis();
            }
        } else {
            currentTargetEntityId = -1;
        }
    }

    /**
     * Wołane na USE_ENTITY (atak).
     */
    public void onAttack(Entity target) {
        if (tickExemption()) return;

        if (target.getEntityId() != currentTargetEntityId) {
            // Atak na cel, który nie był "świeżo namierzony" na celowniku —
            // brak podstaw do porównania czasu reakcji w tym ataku.
            return;
        }

        long now = System.currentTimeMillis();
        long reactionMs = now - targetAcquiredMs;
        double angle = angleToTarget(target);

        boolean flagged = false;

        // ── B. Reaction Time (wymaga powtarzalności w oknie) ──────────────────
        if (reactionMs < HUMAN_REACTION_MIN_MS) {
            fastReactionTimestamps.addLast(now);
            while (!fastReactionTimestamps.isEmpty()
                    && now - fastReactionTimestamps.peekFirst() > FAST_REACTION_WINDOW_MS) {
                fastReactionTimestamps.pollFirst();
            }
            if (fastReactionTimestamps.size() >= FAST_REACTION_MIN_COUNT) {
                buffer(2.0, String.format("sub:ReactionTime reactionMs:%d threshold:%d count:%d",
                    reactionMs, HUMAN_REACTION_MIN_MS, fastReactionTimestamps.size()));
                flagged = true;
            }
        }

        // ── A. Reaction Consistency ─────────────────────────────────────────
        reactionTimes.addLast(reactionMs);
        while (reactionTimes.size() > 20) reactionTimes.pollFirst();

        if (reactionTimes.size() >= CONSISTENCY_SAMPLE_MIN) {
            double mean = mean(reactionTimes);
            double sd = standardDeviation(reactionTimes, mean);
            double cv = mean > 0 ? sd / mean : 1.0;
            if (cv < CONSISTENCY_CV_THRESHOLD) {
                buffer(2.5, String.format("sub:Consistency cv:%.4f mean:%.1f n:%d", cv, mean, reactionTimes.size()));
                flagged = true;
            }
        }

        // ── C. Look-then-attack correlation (tight aim on every hit) ─────────
        attackAngles.addLast(angle);
        while (attackAngles.size() > 20) attackAngles.pollFirst();

        if (attackAngles.size() >= CONSISTENCY_SAMPLE_MIN) {
            double meanAngle = meanDouble(attackAngles);
            double sdAngle = standardDeviationDouble(attackAngles, meanAngle);
            // Ludzie mają naturalny rozrzut kątowy przy kliknięciu — bardzo mała
            // wariancja kąta trafienia przez wiele ataków z rzędu jest podejrzana,
            // ale tylko w połączeniu z niskim mean angle (idealne wycelowanie za każdym razem).
            if (sdAngle < 0.3 && meanAngle < 1.0) {
                buffer(1.5, String.format("sub:AimCorrelation meanAngle:%.3f sdAngle:%.3f", meanAngle, sdAngle));
                flagged = true;
            }
        }

        if (!flagged) {
            reward();
        }

        currentTargetEntityId = -1;
    }

    /** Kąt (stopnie) między kierunkiem patrzenia gracza a wektorem do celu. */
    private double angleToTarget(Entity target) {
        Player player = data.player;
        double eyeHeight = target instanceof LivingEntity
            ? ((LivingEntity) target).getEyeHeight() : 0.9;

        double dx = target.getLocation().getX() - data.x;
        double dy = (target.getLocation().getY() + eyeHeight / 2.0) - (data.y + 1.62);
        double dz = target.getLocation().getZ() - data.z;

        Vector toTarget = new Vector(dx, dy, dz).normalize();
        Vector look = player.getLocation().getDirection().normalize();

        double dot = clamp(toTarget.dot(look), -1.0, 1.0);
        return Math.toDegrees(Math.acos(dot));
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    private double mean(Iterable<Long> values) {
        double sum = 0; int count = 0;
        for (long v : values) { sum += v; count++; }
        return count == 0 ? 0 : sum / count;
    }

    private double standardDeviation(Iterable<Long> values, double mean) {
        double sum = 0; int count = 0;
        for (long v : values) { sum += (v - mean) * (v - mean); count++; }
        return count == 0 ? 0 : Math.sqrt(sum / count);
    }

    private double meanDouble(Iterable<Double> values) {
        double sum = 0; int count = 0;
        for (double v : values) { sum += v; count++; }
        return count == 0 ? 0 : sum / count;
    }

    private double standardDeviationDouble(Iterable<Double> values, double mean) {
        double sum = 0; int count = 0;
        for (double v : values) { sum += (v - mean) * (v - mean); count++; }
        return count == 0 ? 0 : Math.sqrt(sum / count);
    }

    @Override
    public void reset() {
        super.reset();
        reactionTimes.clear();
        attackAngles.clear();
        fastReactionTimestamps.clear();
        currentTargetEntityId = -1;
    }
}
