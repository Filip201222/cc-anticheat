/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.combat;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.predict.EntityHistoryTracker;
import dev.cc.anticheat.predict.EntityLookup;
import dev.cc.anticheat.predict.RayTraceUtil;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.Iterator;

/**
 * cc-anticheat — ReachCheck
 *
 * NAPRAWA (specyfikacja, punkt 2): poprzednia wersja liczyła point-to-box
 * distance (odległość oka gracza od najbliższej krawędzi bounding boxa celu)
 * — to daje sensowny wynik dla "jak blisko", ale NIE weryfikuje, czy gracz
 * faktycznie PATRZY na cel. Zastąpione prawdziwym raytrace ray/AABB:
 *
 *   eye position → rotation → direction vector → ray → target AABB
 *   → ray/AABB intersection → closest valid intersection
 *
 * (patrz RayTraceUtil dla implementacji algorytmu "slab"). Gracz przechodzi
 * check tylko jeśli promień wystrzelony Z JEGO ZAMROŻONEJ ROTACJI w momencie
 * ataku faktycznie przecina bounding box celu w zasięgu REACH_LIMIT — nie
 * wystarczy już samo stanie wystarczająco blisko.
 *
 * Reszta modelu lag compensation zachowana bez zmian: PendingAttack
 * przechowuje DOKŁADNĄ pozycję/rotację ATAKUJĄCEGO w momencie ataku (nie
 * "aktualną" przy przetwarzaniu kolejki), a pozycję CELU bierzemy z
 * EntityHistoryTracker dla tego samego timestampu — więc raytrace jest
 * wykonywany dokładnie na tym stanie świata, jaki serwer widział w chwili
 * odebrania pakietu USE_ENTITY, a nie na stanie "teraz".
 *
 * Pełny model pozy (stojąc/kucając/pływając/na ziemi) zamiast dwóch stałych
 * wysokości oczu, oraz szersza tolerancja lag proporcjonalna do pingu gracza
 * zamiast stałej wartości — zachowane z poprzedniej wersji.
 */
public class ReachCheck extends Check {

    private static final double REACH_LIMIT = 3.1; // bloki, bazowy limit vanilla (~3.0) + minimalny margines zaokrąglenia
    /** Margines na bounding box celu (float/double precision — patrz specyfikacja: "nie flaguj za minimalne różnice"). */
    private static final double BASE_EXPAND = 0.05;
    /** Dodatkowy margines na bounding box celu proporcjonalny do pingu (ruch celu między klatkami przy wyższym pingu). */
    private static final double PING_EXPAND_FACTOR = 0.0015;
    private static final int MAX_QUEUE = 10;

    public ReachCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "Reach");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.1;
        this.vlDecayMultiplier = 0.9;
        this.flagThreshold = 2.0;
        this.requiredBuffer = 1;
        this.maxBuffer = 10;
    }

    /**
     * Wołane na USE_ENTITY (akcja ataku). Kolejkuje atak z zamrożoną pozycją
     * i rotacją atakującego do weryfikacji na następnym pakiecie ruchu.
     *
     * @return true jeśli atak powinien być natychmiast anulowany (oczywista niemożliwość)
     */
    public boolean onAttack(Entity target) {
        if (data.pendingAttacks.size() >= MAX_QUEUE) {
            buffer(5.0, "sub:AttackFlood queue:" + data.pendingAttacks.size());
            return true;
        }

        double fastDist = fastDistance(target);
        boolean prelimOk = fastDist <= REACH_LIMIT + 0.5;

        data.pendingAttacks.add(new PlayerData.PendingAttack(
            target.getEntityId(), prelimOk, data.x, data.y, data.z, data.yaw, data.pitch));

        if (fastDist > REACH_LIMIT + 1.5) {
            buffer(3.0, String.format("sub:Obvious dist:%.3f limit:%.1f", fastDist, REACH_LIMIT));
            data.pendingAttacks.remove(data.pendingAttacks.size() - 1);
            return true;
        }

        return false;
    }

    /**
     * Wołane na każdym pakiecie ruchu — przetwarza zakolejkowane ataki przez
     * prawdziwy raytrace z ZAMROŻONEJ pozycji/rotacji atakującego w momencie
     * ataku, na lag-compensated pozycji celu dla tego samego timestampu.
     */
    public void onMovement() {
        if (data.pendingAttacks.isEmpty()) return;
        if (tickExemption()) {
            data.pendingAttacks.clear();
            return;
        }

        Iterator<PlayerData.PendingAttack> it = data.pendingAttacks.iterator();
        while (it.hasNext()) {
            PlayerData.PendingAttack attack = it.next();
            it.remove();

            Entity target = findEntityById(attack.entityId);
            if (target == null) continue;

            double toleranceMs = data.averagePing();
            double limit = REACH_LIMIT + toleranceMs * PING_EXPAND_FACTOR;

            double bestMiss = Double.MAX_VALUE;

            // Próbujemy kilka kombinacji: pozycja celu w oknie tolerancji
            // (interpolacja/ruch między tickami) × możliwe wysokości oczu
            // atakującego (poza w chwili ataku mogła być przejściowa) —
            // bierzemy NAJLEPSZE dopasowanie, dając graczowi korzyść
            // wątpliwości tam, gdzie serwer sam nie ma pewności co do
            // dokładnego stanu klienta w tamtej chwili.
            for (EntityHistoryTracker.TimedLocation targetLoc :
                    EntityHistoryTracker.getPositionsInWindow(target, attack.timestampMs, 50L)) {

                BoundingBox box = getExpandedBox(target, targetLoc);
                Vector direction = directionFromRotation(attack.attackerYaw, attack.attackerPitch);

                for (double eyeHeight : possibleEyeHeights()) {
                    Vector eye = new Vector(attack.attackerX, attack.attackerY + eyeHeight, attack.attackerZ);
                    double miss = RayTraceUtil.missDistance(eye, direction, box, limit);
                    if (miss < bestMiss) bestMiss = miss;
                }
            }

            if (bestMiss > 0.0) {
                buffer(1.0, String.format("missDistance:%.4f limit:%.3f ping:%.0f", bestMiss, limit, toleranceMs));
            } else {
                reward();
            }
        }
    }

    // ── Pomocniki ─────────────────────────────────────────────────────────────

    /** Wektor kierunku patrzenia z yaw/pitch (stopnie) — standardowa konwersja Minecrafta. */
    private Vector directionFromRotation(float yaw, float pitch) {
        double yawRad = Math.toRadians(yaw);
        double pitchRad = Math.toRadians(pitch);
        double x = -Math.sin(yawRad) * Math.cos(pitchRad);
        double y = -Math.sin(pitchRad);
        double z = Math.cos(yawRad) * Math.cos(pitchRad);
        return new Vector(x, y, z).normalize();
    }

    /**
     * Bounding box celu wyśrodkowany na pozycji z EntityHistoryTracker
     * (nie na aktualnej pozycji encji) — zachowuje kształt/rozmiar aktualny,
     * ale przesunięty do zamrożonego punktu w czasie.
     */
    private BoundingBox getExpandedBox(Entity target, EntityHistoryTracker.TimedLocation loc) {
        BoundingBox currentBox = target.getBoundingBox();
        double halfWidth = (currentBox.getMaxX() - currentBox.getMinX()) / 2.0;
        double height = currentBox.getMaxY() - currentBox.getMinY();

        BoundingBox box = new BoundingBox(
            loc.x - halfWidth, loc.y, loc.z - halfWidth,
            loc.x + halfWidth, loc.y + height, loc.z + halfWidth
        );
        box.expand(BASE_EXPAND);
        return box;
    }

    /**
     * Pełny model pozy: stojąc, kucając, pływając/leżąc (elytra, swimming).
     */
    private double[] possibleEyeHeights() {
        if (data.player.isSwimming() || data.player.isGliding()) {
            return new double[]{0.4, 0.6}; // wysokość oczu w pozycji poziomej
        }
        if (data.player.isSneaking()) {
            return new double[]{1.27, 1.62}; // margines na przejście sneak/stand w trakcie ataku
        }
        return new double[]{1.62, 1.27};
    }

    private double fastDistance(Entity target) {
        double dx = data.x - target.getLocation().getX();
        double dy = (data.y + 1.62) - (target.getLocation().getY()
            + (target instanceof LivingEntity ? ((LivingEntity) target).getEyeHeight() / 2.0 : 0.9));
        double dz = data.z - target.getLocation().getZ();
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private Entity findEntityById(int entityId) {
        return EntityLookup.get(entityId);
    }
}
