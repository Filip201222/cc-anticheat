/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.movement.strafe;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

/**
 * cc-anticheat — StrafeCheck
 *
 * Wykrywa nienaturalną kontrolę kierunku ruchu w powietrzu ("air strafe" cheat).
 *
 * W vanilla, gracz w powietrzu ma bardzo ograniczoną zdolność zmiany kierunku
 * ruchu — input WASD w locie dodaje niewielkie przyspieszenie (0.02 * kierunek
 * patrzenia) do istniejącego wektora prędkości, który jest tłumiony przez opór
 * powietrza (0.91 na tick). Gracz NIE MOŻE:
 *   - Zachować pełnej prędkości poziomej podczas ostrego zakrętu w locie
 *     (>90° zmiana kierunku ruchu w jednym ticku bez znaczącej utraty prędkości)
 *   - Przyspieszyć w locie ponad to, co pozwala mu input-acceleration + tarcie
 *
 * Analizujemy kąt między kolejnymi wektorami ruchu ORAZ zachowaną wielkość
 * prędkości po zmianie kierunku — cheat "strafe" pozwala graczowi skręcać
 * w locie tak, jakby wciąż stał na ziemi (zero utraty prędkości).
 */
public class StrafeCheck extends Check {

    private static final double SHARP_TURN_DEGREES = 80.0;
    private static final double MIN_SPEED_FOR_CHECK = 0.08;
    /** Ile prędkości gracz powinien stracić przy ostrym zakręcie w locie (opór 0.91/tick skumulowany z kątem). */
    private static final double EXPECTED_RETENTION_ON_SHARP_TURN = 0.85;

    public StrafeCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "Strafe");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.1;
        this.vlDecayMultiplier = 0.95;
        this.flagThreshold = 5.0;
        this.setbackThreshold = Double.MAX_VALUE;
        this.requiredBuffer = 3;
        this.maxBuffer = 20;
    }

    public void onMovement(MovementData current) {
        Player player = data.player;

        if (tickExemption()) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (player.isFlying() || player.getAllowFlight()) return;
        if (data.awaitingTeleportConfirm) return;
        // Strafe dotyczy WYŁĄCZNIE ruchu w powietrzu — na ziemi/w wodzie/na drabinie
        // pełna kontrola kierunku jest legalna.
        if (current.actuallyOnGround || current.inWater || current.inLava
            || current.onClimbable || current.inWeb || current.gliding
            || current.onSlimeBlock || current.touchingPistonOrMovingBlock) {
            reward();
            return;
        }

        MovementData previous = data.movementAgo(1);
        if (previous == null) return;

        double currentSpeed = current.horizontalDistance();
        double previousSpeed = previous.horizontalDistance();

        if (previousSpeed < MIN_SPEED_FOR_CHECK || currentSpeed < MIN_SPEED_FOR_CHECK) {
            reward();
            return;
        }

        double angleChange = angleBetween(previous.deltaX, previous.deltaZ, current.deltaX, current.deltaZ);
        double retention = currentSpeed / previousSpeed;

        if (angleChange > SHARP_TURN_DEGREES && retention > EXPECTED_RETENTION_ON_SHARP_TURN) {
            double severity = Math.min((retention - EXPECTED_RETENTION_ON_SHARP_TURN) * 8.0, 3.0);
            buffer(severity, String.format(
                "angleChange:%.1f retention:%.3f prevSpeed:%.4f currSpeed:%.4f",
                angleChange, retention, previousSpeed, currentSpeed));
        } else {
            reward();
        }
    }

    /** Kąt (0-180°) między dwoma wektorami ruchu w płaszczyźnie poziomej. */
    private double angleBetween(double x1, double z1, double x2, double z2) {
        double dot = x1 * x2 + z1 * z2;
        double mag1 = Math.sqrt(x1 * x1 + z1 * z1);
        double mag2 = Math.sqrt(x2 * x2 + z2 * z2);
        if (mag1 < 1e-6 || mag2 < 1e-6) return 0;
        double cos = clamp(dot / (mag1 * mag2), -1.0, 1.0);
        return Math.toDegrees(Math.acos(cos));
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }
}
