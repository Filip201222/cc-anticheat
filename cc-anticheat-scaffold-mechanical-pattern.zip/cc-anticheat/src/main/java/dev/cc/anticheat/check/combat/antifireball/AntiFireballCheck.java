/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.combat.antifireball;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.entity.Fireball;

import java.util.ArrayDeque;

/**
 * cc-anticheat — AntiFireballCheck
 *
 * Wykrywa "AntiFireball" — automatyczne, botowe odbijanie pocisków (fireball
 * Ghasta, strzały, trójzęby itp.) przez atak/blokowanie w idealnym momencie,
 * z częstotliwością i precyzją niemożliwą dla człowieka.
 *
 * Sub-checki:
 *   A. Reaction Time — czas między wejściem fireballa w zasięg ataku gracza
 *      a momentem ataku (deflect) jest poniżej progu ludzkiej reakcji.
 *   B. Consistency — wariancja czasu reakcji na kolejne fireballe jest
 *      niemożliwie niska (identyczny czas reakcji za każdym razem — sygnatura
 *      bota, człowiek ma naturalny jitter reakcji).
 *   C. Frequency — liczba odbitych fireballi w krótkim oknie czasowym
 *      przekracza to, co jest fizycznie możliwe przy typowym summonie Ghasta.
 */
public class AntiFireballCheck extends Check {

    private static final long HUMAN_REACTION_MIN_MS = 80L;
    private static final int CONSISTENCY_SAMPLE_MIN = 5;
    private static final double CONSISTENCY_CV_THRESHOLD = 0.04;

    private final ArrayDeque<Long> reactionTimes = new ArrayDeque<>(16);
    private final ArrayDeque<Long> deflectTimestamps = new ArrayDeque<>(16);

    public AntiFireballCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "AntiFireball");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.1;
        this.vlDecayMultiplier = 0.92;
        this.flagThreshold = 4.0;
        this.setbackThreshold = Double.MAX_VALUE;
        this.requiredBuffer = 1;
        this.maxBuffer = 10;
    }

    /**
     * Wołane gdy gracz odbija fireballa (atak/interakcja, który zmienia
     * kierunek lotu pocisku — patrz ProjectileHitEvent/EntityDamageByEntityEvent
     * z Fireball jako damager).
     *
     * @param fireball        odbity pocisk
     * @param enteredRangeMs  timestamp, w którym pocisk wszedł w zasięg ataku gracza
     */
    public void onFireballDeflect(Fireball fireball, long enteredRangeMs) {
        if (tickExemption()) return;

        long now = System.currentTimeMillis();
        long reactionMs = now - enteredRangeMs;

        boolean flagged = false;

        // ── A. Reaction Time ────────────────────────────────────────────────
        if (reactionMs < HUMAN_REACTION_MIN_MS) {
            buffer(2.5, String.format("sub:ReactionTime reactionMs:%d threshold:%d", reactionMs, HUMAN_REACTION_MIN_MS));
            flagged = true;
        }

        // ── B. Consistency ──────────────────────────────────────────────────
        reactionTimes.addLast(reactionMs);
        while (reactionTimes.size() > 16) reactionTimes.pollFirst();

        if (reactionTimes.size() >= CONSISTENCY_SAMPLE_MIN) {
            double mean = mean(reactionTimes);
            double sd = standardDeviation(reactionTimes, mean);
            double cv = mean > 0 ? sd / mean : 1.0;

            if (cv < CONSISTENCY_CV_THRESHOLD) {
                buffer(2.0, String.format("sub:Consistency cv:%.4f mean:%.1f n:%d", cv, mean, reactionTimes.size()));
                flagged = true;
            }
        }

        // ── C. Frequency ─────────────────────────────────────────────────────
        deflectTimestamps.addLast(now);
        while (!deflectTimestamps.isEmpty() && now - deflectTimestamps.peekFirst() > 10_000L) {
            deflectTimestamps.pollFirst();
        }
        if (deflectTimestamps.size() > 6) { // >6 odbitych fireballi w 10s to skrajnie nietypowe dla walki 1v1 z Ghastem
            buffer(1.5, String.format("sub:Frequency count:%d windowMs:10000", deflectTimestamps.size()));
            flagged = true;
        }

        if (!flagged) {
            reward();
        }
    }

    private double mean(Iterable<Long> values) {
        double sum = 0; int count = 0;
        for (long v : values) { sum += v; count++; }
        return count == 0 ? 0 : sum / count;
    }

    private double standardDeviation(Iterable<Long> values, double mean) {
        double sum = 0; int count = 0;
        for (long v : values) { sum += (v - mean) * (v - mean); count++; }
        return count == 0 ? 0 : Math.sqrt(sum / count);
    }

    @Override
    public void reset() {
        super.reset();
        reactionTimes.clear();
        deflectTimestamps.clear();
    }
}
