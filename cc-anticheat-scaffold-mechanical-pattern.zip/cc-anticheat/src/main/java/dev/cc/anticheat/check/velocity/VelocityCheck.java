/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.velocity;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.predict.PlayerPhysicsEngine;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.util.Vector;

import java.util.Iterator;

/**
 * cc-anticheat — VelocityCheck (AntiKB / Anti-Knockback)
 *
 * NAPRAWA (przegląd, priorytet 🔴1 "Velocity prediction"): poprzednia wersja
 * mierzyła głównie "największy horizontalDistance / największy deltaY" w
 * oknie tolerancji — to NIE jest rekonstrukcja odpowiedzi na KB, tylko
 * przybliżenie przez maksimum, podatne na oszukanie (np. spike ruchu z innego
 * powodu w tym samym oknie fałszywie "uzasadniał" ignorowanie KB) i na
 * false-positive w bardziej złożonych sytuacjach (nakładające się ciosy,
 * zmiana medium w trakcie okna).
 *
 * Przebudowane na PEŁNY ŁAŃCUCH, tick po ticku:
 *
 *   velocity przed KB
 *         ↓
 *   + wektor KB
 *         ↓
 *   PlayerPhysicsEngine.predictPostKnockbackVelocity (grawitacja/tarcie/opór
 *   wody/kolizja — TA SAMA tabela fizyki co Speed/Flight, patrz punkt
 *   "Physics Engine" z przeglądu)
 *         ↓
 *   expected velocity PO ticku
 *         ↓
 *   porównanie z RZECZYWISTĄ deltą ruchu tego ticka (actual)
 *         ↓
 *   deviation → dopiero TO generuje violation
 *
 * Dla kolejnych ticków w oknie tolerancji, "velocity przed" to już nie
 * surowy KB, tylko WYNIK predykcji z poprzedniego ticka (self-consistent
 * chain) — czyli symulujemy KB przez cały tick-by-tick, nie tylko pierwszy
 * moment kontaktu. To eliminuje możliwość "przeczekania" jednego ticka i
 * zignorowania KB w kolejnych, bo każdy tick w oknie ma WŁASNĄ, świeżo
 * policzoną oczekiwaną wartość zależną od poprzedniego (prawdziwego LUB
 * przewidzianego) stanu, a nie jedno zbiorcze "maksimum z całego okna".
 *
 * Fallback: jeśli w danym ticku deviation jest zbyt duże żeby uznać go za
 * jitter/zaokrąglenie, ALE zsumowany ruch w całym oknie tolerancji wciąż
 * mieści się w rozsądnym zakresie (np. gracz zaaplikował KB z opóźnieniem
 * jednego ticka przez packet ordering), nie karzemy — to jest dokładnie
 * przypadek, o którym mówi przegląd: "bestHorizontal < expectedMin jako
 * fallback, nie główny mechanizm".
 */
public class VelocityCheck extends Check {

    /** Dolna granica jako ułamek expected — ile MINIMUM musi gracz zaaplikować, żeby uznać KB za respektowany. */
    private static final double MELEE_MIN_RATIO = 0.55;
    private static final double MELEE_MAX_RATIO = 1.6;
    /** Eksplozje mają szerszy naturalny rozrzut (siła zależy od odległości od epicentrum, dokładność serwera ograniczona). */
    private static final double EXPLOSION_MIN_RATIO = 0.35;
    private static final double EXPLOSION_MAX_RATIO = 2.0;
    private static final double PROJECTILE_MIN_RATIO = 0.45;
    private static final double PROJECTILE_MAX_RATIO = 1.8;

    private static final double VERTICAL_MIN_RATIO = 0.5;

    /** Niższy próg w wodzie/przy kolizji — tam nawet pełny KB daje mniejsze przemieszczenie z powodu oporu/przeszkody. */
    private static final double CONTEXT_WATER_MULTIPLIER = 0.5;
    private static final double CONTEXT_COLLISION_MULTIPLIER = 0.4;
    /** Sprint zwiększa opór poziomy inaczej niż stanie w miejscu — bazowa prędkość własna gracza nakłada się na KB. */
    private static final double SPRINT_MAX_BONUS = 1.3;

    private static final double MIN_SIGNIFICANT_KB = 0.05;
    private static final int VERTICAL_IMPULSE_WINDOW_TICKS = 2;

    public VelocityCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "Velocity");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.1;
        this.vlDecayMultiplier = 0.95;
        this.flagThreshold = 4.0;
        this.requiredBuffer = 1;
        this.maxBuffer = 10;
    }

    /** Wołane tuż przed wysłaniem pakietu knockback/velocity do klienta z domyślnym źródłem MELEE (kompatybilność wsteczna). */
    public void onKnockbackSent(int entityId, Vector kb) {
        onKnockbackSent(entityId, kb, PlayerData.KnockbackSource.MELEE);
    }

    /**
     * Wołane tuż przed wysłaniem pakietu knockback/velocity/explosion/projectile
     * do klienta. Zapisuje też "velocity przed KB" (delta ostatniego
     * zarejestrowanego ticka ruchu) — początek łańcucha predykcji.
     */
    public void onKnockbackSent(int entityId, Vector kb, PlayerData.KnockbackSource source) {
        int toleranceTicks = toleranceForPing(data.averagePing());
        MovementData last = data.lastMovement();
        double velBeforeX = last != null ? last.deltaX : 0;
        double velBeforeY = last != null ? last.deltaY : 0;
        double velBeforeZ = last != null ? last.deltaZ : 0;

        PlayerData.VelocityData vel = new PlayerData.VelocityData(
            entityId, data.movementTickCount, kb.clone(), toleranceTicks, source,
            velBeforeX, velBeforeY, velBeforeZ);
        data.pendingKnockback.addLast(vel);
    }

    /**
     * Wołane na każdym ticku ruchu. Sprawdza, czy okno tolerancji dla
     * najstarszego oczekującego KB już minęło — jeśli tak, weryfikujemy
     * ruch gracza tick-po-ticku przez pełny łańcuch predykcji.
     */
    public void onMovement(MovementData current) {
        if (data.pendingKnockback.isEmpty()) return;
        if (tickExemption()) {
            data.pendingKnockback.clear();
            return;
        }

        Iterator<PlayerData.VelocityData> it = data.pendingKnockback.iterator();
        PlayerData.VelocityData previous = null;
        while (it.hasNext()) {
            PlayerData.VelocityData vel = it.next();
            long ticksSince = data.movementTickCount - vel.sentAtTickCount;

            if (ticksSince < vel.toleranceTicks) {
                break; // kolejka jest chronologiczna — dalsze też będą "za wczesne"
            }

            PlayerData.VelocityData overlapping = peekSecondInQueue();
            boolean overlapsWithNext = overlapping != null
                && overlapping.sentAtTickCount < vel.sentAtTickCount + vel.toleranceTicks + 3;

            long windowEndTick = previous != null ? previous.sentAtTickCount : data.movementTickCount;

            verifyKnockbackApplied(vel, windowEndTick, overlapsWithNext ? overlapping : null);
            it.remove();
            previous = vel;
        }
    }

    /**
     * Drugi element w kolejce pending KB (jeśli istnieje) — używany do
     * wykrycia nakładających się okien przy szybkich seriach ciosów.
     */
    private PlayerData.VelocityData peekSecondInQueue() {
        return data.pendingKnockback.size() > 1
            ? data.pendingKnockback.stream().skip(1).findFirst().orElse(null)
            : null;
    }

    /**
     * Główna weryfikacja — pełny łańcuch tick-po-ticku zamiast pomiaru
     * maksimum z okna. Iterujemy ticki od sentAtTickCount do windowEndTick w
     * porządku CHRONOLOGICZNYM (najstarszy first), symulując oczekiwaną
     * velocity krok po kroku: dla pierwszego ticka bazą jest zarejestrowana
     * "velocity przed KB", dla kolejnych — WYNIK predykcji poprzedniego ticka
     * (self-consistent chain, patrz javadoc klasy).
     */
    private void verifyKnockbackApplied(PlayerData.VelocityData vel, long windowEndTick, PlayerData.VelocityData overlapping) {
        java.util.List<MovementData> window = collectWindowChronological(vel, windowEndTick);
        if (window.isEmpty()) return;

        Vector expected = vel.knockback;
        double expectedX = expected.getX();
        double expectedY = expected.getY();
        double expectedZ = expected.getZ();
        if (overlapping != null) {
            // Nakładający się drugi cios — jego wektor doliczamy do PIERWSZEGO
            // ticka łańcucha (uproszczenie: oba impulsy trafiają w tym samym
            // przybliżonym oknie), żeby expected od razu odzwierciedlał sumę.
            expectedX += overlapping.knockback.getX();
            expectedY += overlapping.knockback.getY();
            expectedZ += overlapping.knockback.getZ();
        }

        double[] hRatioRange = ratioRangeFor(vel.source);
        double minRatio = hRatioRange[0];
        double maxRatio = hRatioRange[1];

        double chainVx = vel.velBeforeX;
        double chainVy = vel.velBeforeY;
        double chainVz = vel.velBeforeZ;
        boolean kbApplied = false;

        double bestHorizontalDeviationRatio = Double.MAX_VALUE;
        double bestVerticalDeviationRatio = Double.MAX_VALUE;
        boolean anomalousBoost = false;
        boolean anyWaterInWindow = false;
        boolean anyCollisionInWindow = false;
        boolean anySprintInWindow = false;

        for (int idx = 0; idx < window.size(); idx++) {
            MovementData tick = window.get(idx);
            anyWaterInWindow |= tick.inWater;
            anyCollisionInWindow |= tick.horizontalCollision;
            anySprintInWindow |= tick.sprinting;

            Vector kbForThisTick;
            if (!kbApplied) {
                kbForThisTick = new Vector(expectedX, expectedY, expectedZ);
                kbApplied = true;
            } else {
                kbForThisTick = new Vector(0, 0, 0); // KB to jednorazowy impuls — kolejne ticki tylko kontynuują fizykę
            }

            PlayerPhysicsEngine.VelocityPrediction prediction = PlayerPhysicsEngine.predictPostKnockbackVelocity(
                chainVx, chainVy, chainVz, kbForThisTick, tick);

            double contextMultiplier = 1.0;
            if (tick.inWater) contextMultiplier = Math.min(contextMultiplier, CONTEXT_WATER_MULTIPLIER);
            if (tick.horizontalCollision) contextMultiplier = Math.min(contextMultiplier, CONTEXT_COLLISION_MULTIPLIER);
            double sprintBonus = tick.sprinting ? SPRINT_MAX_BONUS : 1.0;

            double expectedHThisTick = Math.sqrt(prediction.expectedVx * prediction.expectedVx + prediction.expectedVz * prediction.expectedVz);
            double actualHThisTick = tick.horizontalDistance();

            if (expectedHThisTick > MIN_SIGNIFICANT_KB) {
                double expectedMin = expectedHThisTick * minRatio * contextMultiplier;
                double expectedMaxThisTick = expectedHThisTick * maxRatio * sprintBonus;
                double ratio = expectedMin > 0 ? actualHThisTick / expectedMin : 1.0;
                if (ratio < bestHorizontalDeviationRatio) bestHorizontalDeviationRatio = ratio;

                // Nienaturalne WZMOCNIENIE KB (nie tylko ignorowanie) — rzadszy,
                // ale realny wektor ataku (niektóre cheaty modyfikują pakiet
                // velocity zamiast go całkowicie ignorować). Traktujemy to jako
                // osobny sygnał zamiast miksować z dolną granicą.
                if (actualHThisTick > expectedMaxThisTick) {
                    anomalousBoost = true;
                }
            }

            // Oś pionowa: fizyczny moment impulsu to tylko pierwsze ticki od
            // wysłania (zachowana naprawa z poprzedniej iteracji).
            long ticksFromSend = tick.tickCount - vel.sentAtTickCount;
            if (ticksFromSend >= 0 && ticksFromSend < VERTICAL_IMPULSE_WINDOW_TICKS
                    && Math.abs(prediction.expectedVy) > MIN_SIGNIFICANT_KB) {
                double expectedMinV = prediction.expectedVy * VERTICAL_MIN_RATIO * contextMultiplier;
                double ratio = expectedMinV != 0 ? tick.deltaY / expectedMinV : 1.0;
                if (ratio < bestVerticalDeviationRatio) bestVerticalDeviationRatio = ratio;
            }

            // Łańcuch przechodzi do NASTĘPNEGO ticka z przewidzianą (nie
            // rzeczywistą) prędkością — utrzymuje self-consistency modelu
            // niezależnie od tego, czy klient faktycznie zastosował KB
            // poprawnie w międzyczasie (to właśnie sprawdzamy).
            chainVx = prediction.expectedVx;
            chainVy = prediction.expectedVy;
            chainVz = prediction.expectedVz;
        }

        double contextMultiplierOverall = 1.0;
        if (anyWaterInWindow) contextMultiplierOverall = Math.min(contextMultiplierOverall, CONTEXT_WATER_MULTIPLIER);
        if (anyCollisionInWindow) contextMultiplierOverall = Math.min(contextMultiplierOverall, CONTEXT_COLLISION_MULTIPLIER);

        boolean horizontalViolation = bestHorizontalDeviationRatio != Double.MAX_VALUE && bestHorizontalDeviationRatio < 1.0;
        boolean verticalViolation = bestVerticalDeviationRatio != Double.MAX_VALUE && bestVerticalDeviationRatio < 1.0;

        if (horizontalViolation || verticalViolation) {
            // Fallback zgodny z przeglądem: zanim ukarzemy na podstawie
            // tick-po-tickowej deviation, sprawdzamy też zbiorczy fallback
            // "czy w CAŁYM oknie gracz w ogóle zaaplikował rozsądną część KB"
            // — jeśli tak, traktujemy tick-level deviation jako możliwy efekt
            // packet ordering/jednego złego ticka, nie jako dowód cheatowania.
            double windowMaxHorizontal = 0;
            for (MovementData tick : window) {
                windowMaxHorizontal = Math.max(windowMaxHorizontal, tick.horizontalDistance());
            }
            double expectedH = Math.sqrt(expectedX * expectedX + expectedZ * expectedZ);
            boolean fallbackOk = expectedH <= MIN_SIGNIFICANT_KB
                || windowMaxHorizontal >= expectedH * minRatio * contextMultiplierOverall;

            if (!fallbackOk) {
                double severity = horizontalViolation
                    ? Math.min((1.0 - bestHorizontalDeviationRatio) * 3.0, 4.0)
                    : Math.min((1.0 - bestVerticalDeviationRatio) * 3.0, 4.0);
                buffer(Math.max(severity, 1.0), String.format(
                    "chain hDevRatio:%.2f vDevRatio:%.2f source:%s water:%b collision:%b sprint:%b windowSize:%d",
                    bestHorizontalDeviationRatio, bestVerticalDeviationRatio, vel.source,
                    anyWaterInWindow, anyCollisionInWindow, anySprintInWindow, window.size()));
                return;
            }
        }

        if (anomalousBoost) {
            // Nienaturalne wzmocnienie KB ponad expectedMax jest osobnym, słabszym
            // sygnałem niż ignorowanie KB — nie zawsze oznacza cheatowanie (może
            // to być legalne nałożenie się z pędem sprintu w tym samym kierunku
            // co KB), więc karzemy niżej i wymagamy większego bufora naturalnie
            // przez sam mechanizm Check (requiredBuffer/vlIncrement niższe niż
            // przy ignorowaniu KB).
            buffer(0.8, String.format("anomalousBoost source:%s sprint:%b", vel.source, anySprintInWindow));
            return;
        }

        reward();
    }

    /** Zbiera ticki ruchu z historii, od sentAtTickCount do windowEndTick, w porządku CHRONOLOGICZNYM (najstarszy pierwszy). */
    private java.util.List<MovementData> collectWindowChronological(PlayerData.VelocityData vel, long windowEndTick) {
        java.util.List<MovementData> reversed = new java.util.ArrayList<>();
        int ticksToScan = vel.toleranceTicks + 3;
        for (int i = 0; i < ticksToScan; i++) {
            MovementData m = data.movementAgo(i);
            if (m == null) break;
            if (m.tickCount < vel.sentAtTickCount) break;
            if (m.tickCount > windowEndTick) continue;
            reversed.add(m);
        }
        java.util.Collections.reverse(reversed); // movementAgo(0) to najnowszy — chcemy najstarszy first
        return reversed;
    }

    /** Zwraca [minRatio, maxRatio] właściwe dla źródła KB — patrz javadoc klasy. */
    private double[] ratioRangeFor(PlayerData.KnockbackSource source) {
        switch (source) {
            case EXPLOSION:
                return new double[]{EXPLOSION_MIN_RATIO, EXPLOSION_MAX_RATIO};
            case PROJECTILE:
                return new double[]{PROJECTILE_MIN_RATIO, PROJECTILE_MAX_RATIO};
            case MELEE:
            case OTHER:
            default:
                return new double[]{MELEE_MIN_RATIO, MELEE_MAX_RATIO};
        }
    }

    /**
     * Ticki tolerancji rosną z pingiem: przy niskim pingu wystarczy 1-2 ticki,
     * przy wysokim pingu (250ms+) dajemy więcej marginesu, żeby nie karać
     * graczy z gorszym połączeniem za fizyczne opóźnienie w dotarciu pakietu.
     */
    private int toleranceForPing(double pingMs) {
        int base = 2;
        int extra = (int) Math.ceil(pingMs / 100.0);
        return Math.min(base + extra, 8);
    }

    public void onReset() {
        data.pendingKnockback.clear();
        reset();
    }
}
