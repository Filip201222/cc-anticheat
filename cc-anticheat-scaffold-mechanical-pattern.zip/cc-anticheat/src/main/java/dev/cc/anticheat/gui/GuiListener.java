/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.gui;

import dev.cc.anticheat.CCAnticheat;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

/**
 * cc-anticheat — GuiListener
 *
 * Prevents item theft from PlayerInfoGUI and wires up the spectate button.
 */
public class GuiListener implements Listener {

    private final CCAnticheat plugin;

    public GuiListener(CCAnticheat plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof PlayerInfoGUI)) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player)) return;
        Player staff = (Player) event.getWhoClicked();
        PlayerInfoGUI gui = (PlayerInfoGUI) event.getInventory().getHolder();

        if (event.getRawSlot() == PlayerInfoGUI.SPECTATE_SLOT) {
            Player target = Bukkit.getPlayer(gui.getTargetName());
            if (target == null || !target.isOnline()) {
                plugin.getAlertManager().sendTo(staff, ChatColor.RED + "Gracz jest teraz offline.");
                return;
            }
            staff.closeInventory();
            boolean nowSpectating = plugin.getSpectateManager().toggleSpectate(staff, target);
            plugin.getAlertManager().sendTo(staff, nowSpectating
                    ? ChatColor.GREEN + "Obserwujesz " + ChatColor.WHITE + target.getName()
                    : ChatColor.YELLOW + "Zakończono obserwację.");
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof PlayerInfoGUI) {
            event.setCancelled(true);
        }
    }
}
