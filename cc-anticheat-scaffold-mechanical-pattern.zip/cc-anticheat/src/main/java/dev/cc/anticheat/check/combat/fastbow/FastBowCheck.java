/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.combat.fastbow;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.violation.ViolationProcessor;

/**
 * cc-anticheat — FastBowCheck
 *
 * Wykrywa "FastBow" — wystrzeliwanie strzał z łuku bez odczekania minimalnego
 * czasu naciągu, uzyskując pełną (lub prawie pełną) siłę strzału natychmiast.
 *
 * Fizyka vanilla: siła strzału rośnie z czasem trzymania PPM na łuku według
 * wzoru: t = useDuration/20 (w sekundach); power = clamp((t*t + 2*t)/3, 0, 1).
 * Pełna siła (power=1.0, dystans/obrażenia maksymalne) wymaga >= 1 sekundy
 * (20 ticków) trzymania. FastBow pozwala uzyskać pełną siłę przy czasie
 * naciągu bliskim zeru.
 *
 * Wykrywamy to porównując zgłoszony/zmierzony czas trzymania łuku (od
 * momentu podniesienia ręki do wystrzału) z oczekiwaną wartością na podstawie
 * prędkości wylotowej strzały, jeśli to możliwe do zmierzenia, a w prostszym
 * modelu — bezpośrednio z czasu serwerowego między start-use a release.
 */
public class FastBowCheck extends Check {

    /** Poniżej tego czasu, moc strzału powinna być bliska zeru (strzała powinna spaść pod nogi). */
    private static final long INSTANT_SHOT_THRESHOLD_MS = 50L;

    private long bowRaisedAtMs = 0L;
    private boolean bowCurrentlyRaised = false;

    public FastBowCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "FastBow");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.1;
        this.vlDecayMultiplier = 0.9;
        this.flagThreshold = 3.0;
        this.setbackThreshold = Double.MAX_VALUE;
        this.requiredBuffer = 1;
        this.maxBuffer = 10;
    }

    /** Wołane gdy gracz zaczyna naciągać łuk (PlayerInteractEvent RIGHT_CLICK_AIR/BLOCK z łukiem w ręce). */
    public void onBowRaise() {
        if (bowCurrentlyRaised) return;
        bowCurrentlyRaised = true;
        bowRaisedAtMs = System.currentTimeMillis();
    }

    /**
     * Wołane gdy strzała opuszcza łuk (EntityShootBowEvent).
     *
     * @param reportedForce siła strzału zgłoszona przez zdarzenie Bukkit (0.0-1.0)
     */
    public void onShoot(float reportedForce) {
        if (tickExemption()) {
            bowCurrentlyRaised = false;
            return;
        }

        if (!bowCurrentlyRaised) {
            // Strzał bez wcześniejszego zarejestrowanego naciągu — podejrzane samo
            // w sobie, ale mogliśmy przegapić event przy starcie pluginu/joinie gracza.
            bowCurrentlyRaised = false;
            return;
        }

        long drawTimeMs = System.currentTimeMillis() - bowRaisedAtMs;
        bowCurrentlyRaised = false;

        double expectedForceForDrawTime = expectedForce(drawTimeMs);

        // Tolerancja: siła zgłoszona przez klienta nie powinna istotnie
        // przekraczać tego, co wynika z fizycznie zmierzonego czasu naciągu.
        double tolerance = 0.15;

        if (reportedForce > expectedForceForDrawTime + tolerance) {
            double severity = Math.min((reportedForce - expectedForceForDrawTime) * 5.0, 4.0);
            buffer(severity, String.format(
                "drawMs:%d reportedForce:%.3f expectedForce:%.3f",
                drawTimeMs, reportedForce, expectedForceForDrawTime));
        } else if (drawTimeMs < INSTANT_SHOT_THRESHOLD_MS && reportedForce > 0.3) {
            buffer(4.0, String.format("sub:InstantShot drawMs:%d force:%.3f", drawTimeMs, reportedForce));
        } else {
            reward();
        }
    }

    /**
     * Oblicza oczekiwaną siłę strzału na podstawie czasu naciągu, zgodnie
     * z wanilla formułą: power = ((useTicks/20)^2 + 2*(useTicks/20)) / 3.
     */
    private double expectedForce(long drawTimeMs) {
        double useTicks = drawTimeMs / 50.0; // 50ms = 1 tick
        double t = useTicks / 20.0;
        double power = (t * t + 2 * t) / 3.0;
        return Math.max(0.0, Math.min(1.0, power));
    }

    /** Wywoływane gdy gracz przestaje trzymać PPM bez wystrzału (np. puszczenie/schowanie łuku). */
    public void onBowLower() {
        bowCurrentlyRaised = false;
    }

    @Override
    public void reset() {
        super.reset();
        bowCurrentlyRaised = false;
        bowRaisedAtMs = 0L;
    }
}
