/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.manager;

import dev.cc.anticheat.CCAnticheat;
import dev.cc.anticheat.check.combat.AutoTotemCheck;
import dev.cc.anticheat.check.combat.BaitEspCheck;
import dev.cc.anticheat.check.combat.CombatContext;
import dev.cc.anticheat.check.combat.ReachCheck;
import dev.cc.anticheat.check.combat.aimbot.AimBotCheck;
import dev.cc.anticheat.check.combat.antifireball.AntiFireballCheck;
import dev.cc.anticheat.check.combat.autoarmor.AutoArmorCheck;
import dev.cc.anticheat.check.combat.clickpatterns.ClickPatternEnsemble;
import dev.cc.anticheat.check.combat.criticals.CriticalsCheck;
import dev.cc.anticheat.check.combat.fastbow.FastBowCheck;
import dev.cc.anticheat.check.combat.killaura.KillAuraCheck;
import dev.cc.anticheat.check.combat.triggerbot.TriggerBotCheck;
import dev.cc.anticheat.check.movement.climb.SpiderCheck;
import dev.cc.anticheat.check.movement.liquid.JesusCheck;
import dev.cc.anticheat.check.movement.noslow.NoSlowCheck;
import dev.cc.anticheat.check.movement.phase.PhaseCheck;
import dev.cc.anticheat.check.movement.phase.SneakFlyCheck;
import dev.cc.anticheat.check.movement.physics.BoatFlyCheck;
import dev.cc.anticheat.check.movement.physics.FlightCheck;
import dev.cc.anticheat.check.movement.scaffold.ScaffoldCheck;
import dev.cc.anticheat.check.movement.speed.SpeedCheck;
import dev.cc.anticheat.check.movement.strafe.StrafeCheck;
import dev.cc.anticheat.check.movement.timer.TimerCheck;
import dev.cc.anticheat.check.velocity.VelocityCheck;
import dev.cc.anticheat.check.world.fastbreak.FastBreakCheck;
import dev.cc.anticheat.check.world.nuke.NukeCheck;
import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.predict.EntityLookup;
import dev.cc.anticheat.predict.SetbackUtil;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * cc-anticheat — CheckManager
 *
 * Centralny dyspozytor. Trzyma per-gracz instancje każdego checka i deleguje
 * do nich zdarzenia otrzymane z PacketListener/BukkitListener.
 *
 * Każdy check dziedziczy z Check (Etap 1) i sam zarządza swoim
 * VL/buffer/decay/threshold — CheckManager tylko woła odpowiednie metody
 * we właściwej kolejności i rejestruje wszystkie instancje w
 * PlayerData#allChecks, żeby exemptAll()/reset globalny działał spójnie.
 *
 * Etap 2 dodał: Speed, NoSlow, Strafe, Jesus, Spider, Phase, SneakFly, Scaffold.
 * Etap 3 dodał: AutoArmor, FastBow, Criticals, AntiFireball, TriggerBot.
 * Etap 4 dodaje: Nuke, FastBreak (pełna fizyka kopania — MiningPhysicsEngine).
 */
public class CheckManager {

    private static final double FIREBALL_RANGE_DETECTION = 4.0;
    private static final double TRIGGERBOT_RAYTRACE_RANGE = 4.5;

    private final CCAnticheat plugin;
    private final ViolationProcessor vp;

    private final Map<UUID, PlayerChecks> checks = new ConcurrentHashMap<>();

    public CheckManager(CCAnticheat plugin, ViolationProcessor vp) {
        this.plugin = plugin;
        this.vp = vp;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    public void onJoin(Player player) {
        PlayerData data = new PlayerData(player);
        PlayerChecks pc = new PlayerChecks(plugin, data, vp);
        checks.put(player.getUniqueId(), pc);
    }

    public void onQuit(Player player) {
        PlayerChecks pc = checks.remove(player.getUniqueId());
        if (pc != null) {
            vp.clearGlobalPoints(player.getUniqueId());
        }
    }

    // ── Event dispatch ────────────────────────────────────────────────────────

    /** ARM_ANIMATION packet received. */
    public void onSwing(PlayerData data, boolean hadSwingThisTick) {
        PlayerChecks pc = get(data);
        if (pc == null) return;

        pc.clickPatterns.onSwing();
        pc.killAura.onSwing();
    }

    /**
     * USE_ENTITY (attack) packet received.
     *
     * @return true jeśli atak powinien być anulowany
     */
    public boolean onAttack(PlayerData data, Entity target, boolean hadSwing) {
        PlayerChecks pc = get(data);
        if (pc == null) return false;

        boolean cancelReach = pc.reach.onAttack(target);

        // CombatContext (przegląd, punkt 🔴2): jeden wspólny kontekst dla
        // TEGO ataku, dzielony przez KillAura i AimBot — oba są wołane PRZED
        // odczytaniem correlationMultiplier(), żeby ocena korelacji widziała
        // wynik OBU checków, niezależnie od kolejności ich wywołania.
        dev.cc.anticheat.check.combat.CombatContext combatContext = new CombatContext();
        pc.killAura.onAttack(target, hadSwing, combatContext);
        pc.aimBot.onAttack(target, combatContext);
        pc.triggerBot.onAttack(target);

        if (combatContext.anomalyCount() >= 2) {
            // Skorelowany sygnał: KillAura I AimBot niezależnie wykryły
            // anomalię w tym samym ataku — to jest silniejszy dowód niż suma
            // tych samych incydentów rozproszonych w czasie (punkt 🟠6),
            // więc dokładamy DODATKOWY wpis do globalnych punktów karnych z
            // podwyższonym mnożnikiem, ponad to, co każdy check już zgłosił
            // osobno przez własne buffer().
            vp.flag(data, "CombatCorrelation",
                String.format("killAura:%b aimBot:%b", combatContext.killAuraAnomaly, combatContext.aimBotSnapAnomaly),
                combatContext.anomalyCount(), false, combatContext.correlationMultiplier());
        }

        return cancelReach;
    }

    /**
     * Pakiet ruchu odebrany (FLYING / POSITION / POSITION_LOOK / LOOK).
     */
    public void onMovement(PlayerData data, double prevY, boolean hasPosition, boolean onGround, MovementData movement) {
        PlayerChecks pc = get(data);
        if (pc == null) return;

        pc.reach.onMovement();
        pc.velocity.onMovement(movement);
        pc.killAura.onTick();
        pc.autoArmor.onInventoryPoll();

        if (hasPosition) {
            pc.flight.onMovement(movement);
            pc.boatFly.onMovement(movement);
            pc.speed.onMovement(movement);
            pc.noSlow.onMovement(movement);
            pc.strafe.onMovement(movement);
            pc.jesus.onMovement(movement);
            pc.spider.onMovement(movement);
            pc.phase.onMovement(movement);
            pc.sneakFly.onMovement(movement);
            pc.scaffold.onMovement(movement);
        }

        scanNearbyFireballs(data);
        updateCrosshairTarget(data, pc);

        // Bait ESP (przegląd, priorytet 🟡): sprawdzamy TYLKO gdy bait jest
        // faktycznie aktywny dla tego gracza (tanie sprawdzenie HashMap) —
        // bait jest uruchamiany ręcznie na konkretnego podejrzanego, nie
        // działa domyślnie dla wszystkich graczy, więc to nie dodaje kosztu
        // do zwykłego ruchu większości graczy na serwerze.
        if (plugin.getBaitEspManager().isActive(data.player)) {
            pc.baitEsp.onTick(plugin.getBaitEspManager());
        }

        // Aktualizuj pozycję bezpieczną tylko jeśli żaden check ruchu nie ma
        // aktualnie podniesionego VL — prosty wspólny wskaźnik "gracz porusza
        // się czysto w tym momencie", używany jako baza do ewentualnego setbacku.
        if (isMovementClean(pc)) {
            SetbackUtil.updateSafePosition(data);
        }
    }

    private boolean isMovementClean(PlayerChecks pc) {
        return pc.flight.getViolationLevel() < 3.0
            && pc.speed.getViolationLevel() < 3.0
            && pc.spider.getViolationLevel() < 3.0
            && pc.phase.getViolationLevel() < 1.0
            && pc.sneakFly.getViolationLevel() < 3.0
            && pc.jesus.getViolationLevel() < 3.0;
    }

    /**
     * Skanuje otoczenie gracza w poszukiwaniu fireballi w zasięgu ataku —
     * zasila AntiFireballCheck momentem "wejścia w zasięg" (patrz
     * PlayerData#fireballsInRange), z którego BukkitListener#onDamage
     * odczytuje czas reakcji przy faktycznym odbiciu.
     */
    private void scanNearbyFireballs(PlayerData data) {
        Player player = data.player;
        for (Entity nearby : player.getNearbyEntities(FIREBALL_RANGE_DETECTION, FIREBALL_RANGE_DETECTION, FIREBALL_RANGE_DETECTION)) {
            if (!(nearby instanceof Fireball)) continue;
            data.fireballsInRange.putIfAbsent(nearby.getEntityId(), System.currentTimeMillis());
        }
        // Sprzątanie wpisów dla fireballi, które oddaliły się poza zasięg bez odbicia.
        data.fireballsInRange.keySet().removeIf(id -> {
            Entity e = findEntityById(id);
            return e == null || e.getLocation().distance(player.getLocation()) > FIREBALL_RANGE_DETECTION * 1.5;
        });
    }

    /**
     * Aktualizuje encję pod celownikiem gracza przez prosty raytrace —
     * zasila TriggerBotCheck.
     */
    private void updateCrosshairTarget(PlayerData data, PlayerChecks pc) {
        Player player = data.player;
        RayTraceResult result = player.getWorld().rayTraceEntities(
            player.getEyeLocation(),
            player.getEyeLocation().getDirection(),
            TRIGGERBOT_RAYTRACE_RANGE,
            0.3,
            entity -> entity instanceof LivingEntity && !entity.equals(player)
        );

        Entity target = result != null ? result.getHitEntity() : null;
        data.currentCrosshairTarget = target;
        pc.triggerBot.onTick(target);
    }

    private Entity findEntityById(int entityId) {
        return EntityLookup.get(entityId);
    }

    /** LOOK / POSITION_LOOK rotation received. */
    public void onRotation(PlayerData data, float yaw, float pitch) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        pc.aimBot.onRotation(yaw, pitch);
        pc.killAura.onRotation(yaw, pitch);
    }

    /**
     * CLIENT_TICK_END odebrany — główne źródło danych dla TimerCheck (patrz
     * uwaga architektoniczna w PlayerData/PacketListener o usunięciu
     * nieistniejącego pakietu WINDOW_CONFIRMATION).
     */
    public void onClientTickEnd(PlayerData data) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        double tps = plugin.getCurrentTps();
        pc.timer.onClientTickEnd(tps);
    }

    /** Gracz użył totema (EntityResurrectEvent). */
    public void onTotemUse(PlayerData data) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        pc.autoTotem.onTotemUse();
    }

    /** Gracz wykonał akcję w ekwipunku (window click / item swap). */
    public void onInventoryAction(PlayerData data) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        pc.autoTotem.onInventoryAction();
    }

    /** Knockback wysłany do gracza (hook na EntityDamageByEntityEvent). */
    /** Knockback wysłany do gracza (hook na EntityDamageByEntityEvent) — domyślne źródło MELEE, zachowane dla kompatybilności. */
    public void onKnockbackSent(PlayerData data, int attackerEntityId, Vector knockback) {
        onKnockbackSent(data, attackerEntityId, knockback, PlayerData.KnockbackSource.MELEE);
    }

    /** Knockback wysłany do gracza z jawnie określonym źródłem (MELEE/PROJECTILE/EXPLOSION/OTHER). */
    public void onKnockbackSent(PlayerData data, int attackerEntityId, Vector knockback, PlayerData.KnockbackSource source) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        pc.velocity.onKnockbackSent(attackerEntityId, knockback, source);
    }

    /** Gracz położył blok (BLOCK_PLACE) — używane przez ScaffoldCheck. */
    /** Gracz położył blok (BLOCK_PLACE) — wersja bez pozycji bloku, kompatybilność wsteczna. */
    public void onBlockPlace(PlayerData data, Vector placedAgainst) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        pc.scaffold.onBlockPlace(placedAgainst);
    }

    /**
     * Gracz położył blok (BLOCK_PLACE) — wersja z jawną pozycją bloku, na
     * którym stawiany jest nowy blok, potrzebną do prawdziwego raytrace
     * (block face) w ScaffoldCheck (przegląd, punkt 8 pierwotnej
     * specyfikacji: "Rozbuduj Scaffold o analizę: placement position, block
     * face, raytrace").
     */
    public void onBlockPlace(PlayerData data, Vector placedAgainst, int blockX, int blockY, int blockZ) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        pc.scaffold.onBlockPlace(placedAgainst, blockX, blockY, blockZ);
    }

    /**
     * Gracz położył blok (BLOCK_PLACE) — pełna wersja z jawnym block face
     * (którą ścianę bloku kliknął gracz, wprost z pakietu) — przegląd,
     * priorytet 🔴 "Scaffold raytrace → konkretny BlockFace". Bez tego
     * parametru raytrace weryfikował tylko "czy promień trafia w blok w
     * ogóle" (dowolna ściana), co jest słabszym testem niż to, co faktycznie
     * niesie protokół.
     */
    public void onBlockPlace(PlayerData data, Vector placedAgainst, int blockX, int blockY, int blockZ,
                              com.comphenix.protocol.wrappers.EnumWrappers.Direction face) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        pc.scaffold.onBlockPlace(placedAgainst, blockX, blockY, blockZ, face);
    }

    /** Gracz otrzymał obrażenia z dowolnego źródła — trigger dla AutoArmorCheck. */
    public void onDamageTaken(PlayerData data) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        pc.autoArmor.onDamageTaken();
    }

    /** Atak gracza został oznaczony jako critical (EntityDamageByEntityEvent#isCritical). */
    public void onCriticalHit(PlayerData data) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        pc.criticals.onCriticalHit();
    }

    /** Gracz zaczyna naciągać łuk/kuszę (PlayerInteractEvent). */
    public void onBowRaise(PlayerData data) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        pc.fastBow.onBowRaise();
    }

    /** Strzała opuściła łuk gracza (EntityShootBowEvent). */
    public void onBowShoot(PlayerData data, float force) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        pc.fastBow.onShoot(force);
    }

    /** Gracz odbił fireballa atakiem — feed dla AntiFireballCheck. */
    public void onFireballDeflect(PlayerData data, Fireball fireball, long enteredRangeMs) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        pc.antiFireball.onFireballDeflect(fireball, enteredRangeMs);
    }

    /** Gracz rozpoczął kopanie bloku (START_DESTROY_BLOCK) — feed dla FastBreakCheck. */
    public void onDigStart(PlayerData data, Block block) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        pc.fastBreak.onDigStart(block);
    }

    /** Gracz anulował/zakończył kopanie bez złamania bloku (ABORT/STOP_DESTROY_BLOCK). */
    public void onDigCancel(PlayerData data) {
        PlayerChecks pc = get(data);
        if (pc == null) return;
        pc.fastBreak.onDigCancel();
    }

    /**
     * Blok został faktycznie złamany (BlockBreakEvent) — weryfikacja przez
     * FastBreak (czas łamania) i Nuke (rate/spread/no-look).
     *
     * @return true jeśli złamanie powinno być anulowane
     */
    public boolean onBlockBreak(PlayerData data, Location brokenBlockLoc) {
        PlayerChecks pc = get(data);
        if (pc == null) return false;

        boolean cancelFastBreak = pc.fastBreak.onBlockBreak();
        boolean cancelNuke = pc.nuke.onBlockBreak(brokenBlockLoc);

        return cancelFastBreak || cancelNuke;
    }

    // ── Data access ───────────────────────────────────────────────────────────

    public PlayerData getData(Player player) {
        PlayerChecks pc = checks.get(player.getUniqueId());
        return pc != null ? pc.data : null;
    }

    /** Zwraca punkty karne gracza (globalny wskaźnik eskalacji) do wyświetlenia w /ac stats. */
    public double getGlobalPoints(Player player) {
        return vp.getGlobalPoints(player.getUniqueId());
    }

    /** Zwraca aktualny VL danego checka gracza po nazwie — używane przez komendę /ac stats. */
    public double getCheckVl(Player player, String checkKey) {
        PlayerChecks pc = checks.get(player.getUniqueId());
        if (pc == null) return 0.0;
        switch (checkKey.toLowerCase()) {
            case "timer": return pc.timer.getViolationLevel();
            case "flight": return pc.flight.getViolationLevel();
            case "boatfly": return pc.boatFly.getViolationLevel();
            case "velocity": return pc.velocity.getViolationLevel();
            case "reach": return pc.reach.getViolationLevel();
            case "killaura": return pc.killAura.getViolationLevel();
            case "aimbot": return pc.aimBot.getViolationLevel();
            case "autototem": return pc.autoTotem.getViolationLevel();
            case "clickpattern": return pc.clickPatterns.getViolationLevel();
            case "speed": return pc.speed.getViolationLevel();
            case "noslow": return pc.noSlow.getViolationLevel();
            case "strafe": return pc.strafe.getViolationLevel();
            case "jesus": return pc.jesus.getViolationLevel();
            case "spider": return pc.spider.getViolationLevel();
            case "phase": return pc.phase.getViolationLevel();
            case "sneakfly": return pc.sneakFly.getViolationLevel();
            case "scaffold": return pc.scaffold.getViolationLevel();
            case "autoarmor": return pc.autoArmor.getViolationLevel();
            case "fastbow": return pc.fastBow.getViolationLevel();
            case "criticals": return pc.criticals.getViolationLevel();
            case "antifireball": return pc.antiFireball.getViolationLevel();
            case "triggerbot": return pc.triggerBot.getViolationLevel();
            case "baitesp": return pc.baitEsp.getViolationLevel();
            case "nuke": return pc.nuke.getViolationLevel();
            case "fastbreak": return pc.fastBreak.getViolationLevel();
            default: return 0.0;
        }
    }

    /** Resetuje wszystkie checki gracza (np. po /ac reset). */
    public void resetAll(Player player) {
        PlayerChecks pc = checks.get(player.getUniqueId());
        if (pc == null) return;
        for (dev.cc.anticheat.check.Check c : pc.data.allChecks) {
            c.reset();
        }
        vp.clearGlobalPoints(player.getUniqueId());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Internal helpers
    // ─────────────────────────────────────────────────────────────────────────

    private PlayerChecks get(PlayerData data) {
        return checks.get(data.uuid);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Per-player check bundle
    // ─────────────────────────────────────────────────────────────────────────

    private static class PlayerChecks {
        final PlayerData data;

        // Combat — Etap 1
        final ClickPatternEnsemble clickPatterns;
        final KillAuraCheck killAura;
        final AimBotCheck aimBot;
        final ReachCheck reach;
        final AutoTotemCheck autoTotem;

        // Movement — Etap 1
        final TimerCheck timer;
        final FlightCheck flight;
        final BoatFlyCheck boatFly;

        // Movement — Etap 2
        final SpeedCheck speed;
        final NoSlowCheck noSlow;
        final StrafeCheck strafe;
        final JesusCheck jesus;
        final SpiderCheck spider;
        final PhaseCheck phase;
        final SneakFlyCheck sneakFly;
        final ScaffoldCheck scaffold;

        // Combat — Etap 3
        final AutoArmorCheck autoArmor;
        final FastBowCheck fastBow;
        final CriticalsCheck criticals;
        final AntiFireballCheck antiFireball;
        final TriggerBotCheck triggerBot;

        // Combat — Bait ESP confidence signal (przegląd, priorytet 🟡)
        final BaitEspCheck baitEsp;

        // World — Etap 4
        final NukeCheck nuke;
        final FastBreakCheck fastBreak;

        // Velocity
        final VelocityCheck velocity;

        PlayerChecks(CCAnticheat plugin, PlayerData data, ViolationProcessor vp) {
            this.data = data;

            this.clickPatterns = new ClickPatternEnsemble(data, vp);
            this.killAura = new KillAuraCheck(data, vp);
            this.aimBot = new AimBotCheck(data, vp);
            this.reach = new ReachCheck(data, vp);
            this.autoTotem = new AutoTotemCheck(data, vp);

            this.timer = new TimerCheck(data, vp);
            this.flight = new FlightCheck(data, vp, plugin);
            this.boatFly = new BoatFlyCheck(data, vp);

            this.speed = new SpeedCheck(data, vp, plugin);
            this.noSlow = new NoSlowCheck(data, vp);
            this.strafe = new StrafeCheck(data, vp);
            this.jesus = new JesusCheck(data, vp, plugin);
            this.spider = new SpiderCheck(data, vp, plugin);
            this.phase = new PhaseCheck(data, vp, plugin);
            this.sneakFly = new SneakFlyCheck(data, vp, plugin);
            this.scaffold = new ScaffoldCheck(data, vp);

            this.autoArmor = new AutoArmorCheck(data, vp);
            this.fastBow = new FastBowCheck(data, vp);
            this.criticals = new CriticalsCheck(data, vp);
            this.antiFireball = new AntiFireballCheck(data, vp);
            this.triggerBot = new TriggerBotCheck(data, vp);
            this.baitEsp = new BaitEspCheck(data, vp);

            this.nuke = new NukeCheck(data, vp);
            this.fastBreak = new FastBreakCheck(data, vp);

            this.velocity = new VelocityCheck(data, vp);

            data.allChecks.add(clickPatterns);
            data.allChecks.add(killAura);
            data.allChecks.add(aimBot);
            data.allChecks.add(reach);
            data.allChecks.add(autoTotem);
            data.allChecks.add(timer);
            data.allChecks.add(flight);
            data.allChecks.add(boatFly);
            data.allChecks.add(speed);
            data.allChecks.add(noSlow);
            data.allChecks.add(strafe);
            data.allChecks.add(jesus);
            data.allChecks.add(spider);
            data.allChecks.add(phase);
            data.allChecks.add(sneakFly);
            data.allChecks.add(scaffold);
            data.allChecks.add(autoArmor);
            data.allChecks.add(fastBow);
            data.allChecks.add(criticals);
            data.allChecks.add(antiFireball);
            data.allChecks.add(triggerBot);
            data.allChecks.add(baitEsp);
            data.allChecks.add(nuke);
            data.allChecks.add(fastBreak);
            data.allChecks.add(velocity);
        }
    }
}
