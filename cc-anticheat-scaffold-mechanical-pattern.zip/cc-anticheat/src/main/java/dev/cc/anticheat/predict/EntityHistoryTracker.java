/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.predict;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.util.BoundingBox;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * cc-anticheat — EntityHistoryTracker
 *
 * Utrzymuje krótką historię stanu WSZYSTKICH encji na serwerze (nie tylko
 * graczy), próbkowaną raz na tick serwerowy, żeby combat checki (KillAura,
 * Reach, AimBot, TriggerBot, Velocity) mogły oceniać kąt/dystans/prędkość
 * ataku względem stanu celu W MOMENCIE, w którym atakujący faktycznie
 * widział go na ekranie — nie względem stanu "teraz" po stronie serwera.
 *
 * NAPRAWA (przegląd, punkt 🔴3 "EntityHistory nadal ma jedną wadę"): każdy
 * snapshot przechowywał wcześniej TYLKO x/y/z/timestamp — interpolacja
 * pozycji A→B zakładała ruch liniowy o stałej prędkości między dwiema
 * znanymi próbkami, co jest gorszym przybliżeniem niż position+velocity
 * (analogicznie do tego, jak silniki gier robią dead reckoning: pozycja
 * ekstrapolowana z ostatniej znanej prędkości jest dokładniejsza niż czysta
 * interpolacja liniowa między dwoma punktami, szczególnie gdy target
 * przyspiesza/skręca między próbkami). Każdy TimedSnapshot ma teraz też:
 *
 *   velocityX/Y/Z — prędkość WYLICZONA z różnicy pozycji do poprzedniej
 *                   próbki (nie Entity#getVelocity(), które jest wewnętrznym
 *                   stanem serwera i nie zawsze wiernie odzwierciedla
 *                   faktyczny ruch obserwowalny — delta pozycji jest
 *                   spójna z resztą silnika, który wszędzie indziej też
 *                   liczy "prędkość" jako deltę pozycji między tickami)
 *   yaw/pitch     — rotacja encji w danym ticku (dla żywych/graczy — 0 dla
 *                   encji bez jawnej rotacji, np. przedmiotów)
 *   boundingBox   — kształt/rozmiar hitboxa w danym ticku (może się zmieniać:
 *                   sneak, swimming, itp.)
 *
 * Pamięć pozostaje ograniczona identycznie jak wcześniej: HISTORY_TICKS na
 * encję, MAX_TRACKED_ENTITIES globalnie, purgeStale() cyklicznie sprząta
 * nieaktywne wpisy — dodanie velocity/yaw/pitch/boundingBox nie zmienia
 * asymptotyki pamięciowej (wciąż O(1) dodatkowych pól per-snapshot, nie
 * nowa kolekcja).
 */
public final class EntityHistoryTracker {

    private static final int HISTORY_TICKS = 20; // 1 sekunda przy 20 TPS
    private static final int MAX_TRACKED_ENTITIES = 4096; // twardy limit pamięci na duże servery

    private static final Map<UUID, Deque<TimedSnapshot>> history = new ConcurrentHashMap<>();

    private EntityHistoryTracker() {}

    public static final class TimedSnapshot {
        public final double x, y, z;
        public final double velocityX, velocityY, velocityZ;
        public final float yaw, pitch;
        public final BoundingBox boundingBox;
        public final long timestampMs;

        TimedSnapshot(double x, double y, double z,
                      double velocityX, double velocityY, double velocityZ,
                      float yaw, float pitch, BoundingBox boundingBox, long timestampMs) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.velocityX = velocityX;
            this.velocityY = velocityY;
            this.velocityZ = velocityZ;
            this.yaw = yaw;
            this.pitch = pitch;
            this.boundingBox = boundingBox;
            this.timestampMs = timestampMs;
        }
    }

    /** Alias zachowany dla kompatybilności wstecznej z checkami napisanymi przed rozbudową o velocity/rotation. */
    public static final class TimedLocation {
        public final double x, y, z;
        public final long timestampMs;

        TimedLocation(double x, double y, double z, long timestampMs) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.timestampMs = timestampMs;
        }

        static TimedLocation fromSnapshot(TimedSnapshot s) {
            return new TimedLocation(s.x, s.y, s.z, s.timestampMs);
        }
    }

    /** Wołane raz na tick serwerowy dla każdej encji, którą chcemy śledzić (żywe encje w załadowanych światach). */
    public static void recordPosition(Entity entity) {
        UUID id = entity.getUniqueId();
        if (history.size() >= MAX_TRACKED_ENTITIES && !history.containsKey(id)) {
            return; // twardy limit — nowe encje ponad limit po prostu nie są śledzone
        }

        Deque<TimedSnapshot> deque = history.computeIfAbsent(id, k -> new ArrayDeque<>(HISTORY_TICKS + 2));
        Location loc = entity.getLocation();
        long now = System.currentTimeMillis();

        TimedSnapshot last = deque.peekLast();
        double vx = 0, vy = 0, vz = 0;
        if (last != null) {
            long dtMs = now - last.timestampMs;
            if (dtMs > 0) {
                // Prędkość jako delta pozycji / czas, znormalizowana do "na tick"
                // (50ms) — spójne jednostki z MovementData.deltaX/Y/Z używanymi
                // wszędzie indziej w silniku, żeby checki mogły bezpośrednio
                // porównywać wartości bez dodatkowej konwersji jednostek.
                double scale = 50.0 / dtMs;
                vx = (loc.getX() - last.x) * scale;
                vy = (loc.getY() - last.y) * scale;
                vz = (loc.getZ() - last.z) * scale;
            }
        }

        TimedSnapshot snapshot = new TimedSnapshot(
            loc.getX(), loc.getY(), loc.getZ(),
            vx, vy, vz,
            loc.getYaw(), loc.getPitch(),
            entity.getBoundingBox(),
            now
        );
        deque.addLast(snapshot);

        while (deque.size() > HISTORY_TICKS) {
            deque.pollFirst();
        }
    }

    /** Sprząta historię encji, które opuściły serwer/despawnęły — wołane cyklicznie. */
    public static void purgeStale(long maxAgeMs) {
        long now = System.currentTimeMillis();
        history.entrySet().removeIf(entry -> {
            Deque<TimedSnapshot> deque = entry.getValue();
            return deque.isEmpty() || (now - deque.peekLast().timestampMs) > maxAgeMs;
        });
    }

    public static void forget(UUID entityUuid) {
        history.remove(entityUuid);
    }

    /**
     * Zwraca pełny snapshot (position + velocity + rotation + bounding box)
     * encji w przybliżeniu targetTimestampMs milisekund temu.
     *
     * Zamiast czystej interpolacji liniowej między dwiema znanymi próbkami,
     * używamy dead reckoning: bierzemy najbliższą próbkę PRZED targetem i
     * EKSTRAPOLUJEMY jej pozycję do przodu o brakujący czas, używając JEJ
     * WŁASNEJ zarejestrowanej prędkości — to lepiej odzwierciedla ruch
     * przyspieszający/skręcający niż zakładanie stałej prędkości między
     * dwoma punktami, szczególnie gdy okno próbek jest rzadkie względem
     * dynamiki ruchu celu.
     */
    public static TimedSnapshot getSnapshotAt(Entity entity, long targetTimestampMs) {
        Deque<TimedSnapshot> deque = history.get(entity.getUniqueId());
        if (deque == null || deque.isEmpty()) {
            return currentSnapshot(entity);
        }

        TimedSnapshot before = null;
        TimedSnapshot after = null;
        for (TimedSnapshot sample : deque) {
            if (sample.timestampMs <= targetTimestampMs) {
                before = sample;
            } else {
                after = sample;
                break;
            }
        }

        if (before == null) {
            // Target sprzed początku historii — najstarsza dostępna próbka.
            return after != null ? after : deque.peekFirst();
        }
        if (after == null) {
            // Target po najnowszej próbce — ekstrapolacja przez dead reckoning
            // z ostatniej znanej prędkości zamiast zwracania "zamrożonej" pozycji.
            return extrapolate(before, targetTimestampMs);
        }

        // Mamy próbki po obu stronach — dead reckoning z "before" jest
        // dokładniejszy niż liniowa interpolacja do "after", bo wykorzystuje
        // faktyczną prędkość w tamtym momencie zamiast uśredniać ją na całym
        // odcinku (co gubi przyspieszenie/zmianę kierunku w połowie odcinka).
        return extrapolate(before, targetTimestampMs);
    }

    /** Kompatybilność wsteczna: zwraca tylko pozycję (bez velocity/rotation) — patrz getSnapshotAt dla pełnych danych. */
    public static TimedLocation getPositionAt(Entity entity, long targetTimestampMs) {
        return TimedLocation.fromSnapshot(getSnapshotAt(entity, targetTimestampMs));
    }

    /**
     * Zwraca kilka snapshotów z okna czasowego (targetTimestampMs ± windowMs) —
     * używane przez checki, które chcą sprawdzić NAJLEPSZE dopasowanie kąta/
     * dystansu w oknie tolerancji pingu, zamiast pojedynczego punktu.
     */
    public static Iterable<TimedSnapshot> getSnapshotsInWindow(Entity entity, long targetTimestampMs, long windowMs) {
        Deque<TimedSnapshot> deque = history.get(entity.getUniqueId());
        java.util.List<TimedSnapshot> result = new java.util.ArrayList<>();
        if (deque == null || deque.isEmpty()) {
            result.add(currentSnapshot(entity));
            return result;
        }
        for (TimedSnapshot sample : deque) {
            if (Math.abs(sample.timestampMs - targetTimestampMs) <= windowMs) {
                result.add(sample);
            }
        }
        if (result.isEmpty()) {
            result.add(deque.peekLast());
        }
        return result;
    }

    /** Kompatybilność wsteczna: wersja zwracająca tylko pozycje — patrz getSnapshotsInWindow dla pełnych danych. */
    public static Iterable<TimedLocation> getPositionsInWindow(Entity entity, long targetTimestampMs, long windowMs) {
        java.util.List<TimedLocation> result = new java.util.ArrayList<>();
        for (TimedSnapshot s : getSnapshotsInWindow(entity, targetTimestampMs, windowMs)) {
            result.add(TimedLocation.fromSnapshot(s));
        }
        return result;
    }

    private static TimedSnapshot extrapolate(TimedSnapshot base, long targetMs) {
        double dtTicks = (targetMs - base.timestampMs) / 50.0; // w jednostkach "na tick", spójnych z velocity
        return new TimedSnapshot(
            base.x + base.velocityX * dtTicks,
            base.y + base.velocityY * dtTicks,
            base.z + base.velocityZ * dtTicks,
            base.velocityX, base.velocityY, base.velocityZ,
            base.yaw, base.pitch, base.boundingBox, targetMs
        );
    }

    private static TimedSnapshot currentSnapshot(Entity entity) {
        Location loc = entity.getLocation();
        return new TimedSnapshot(
            loc.getX(), loc.getY(), loc.getZ(),
            0, 0, 0,
            loc.getYaw(), loc.getPitch(),
            entity.getBoundingBox(),
            System.currentTimeMillis()
        );
    }
}
