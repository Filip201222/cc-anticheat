/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.predict;

import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Levelled;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

/**
 * cc-anticheat — CollisionUtil
 *
 * Odpowiednik uproszczonego silnika kolizji AABB używanego przez Grima.
 * Zamiast sprawdzania pojedynczego bloku pod stopami gracza (co daje masę
 * false-positive/negative przy słupkach, schodach, płytkach, ścianach), budujemy
 * pełny bounding box gracza i sprawdzamy przecięcie z bounding boxami bloków
 * w promieniu, tak jak robi to serwer vanilla przy pchaniu encji.
 *
 * Gracz ma bounding box o wymiarach 0.6 x 1.8 (0.3 promienia w X/Z, stojąc),
 * lub 0.6 x 0.6 podczas czołgania się (Minecraft 1.14+).
 */
public final class CollisionUtil {

    public static final double PLAYER_WIDTH_HALF = 0.3;
    public static final double PLAYER_HEIGHT_STANDING = 1.8;
    public static final double PLAYER_HEIGHT_SNEAKING = 1.5;
    public static final double PLAYER_HEIGHT_SWIMMING = 0.6;

    /** Margines tolerancji przy sprawdzaniu kolizji z gruntem (vanilla używa 1.0E-3 do 1.0E-7). */
    private static final double GROUND_EPSILON = 0.005;

    private CollisionUtil() {}

    /**
     * Buduje bounding box gracza wyśrodkowany na x,z z podstawą na y.
     */
    public static BoundingBox playerBoundingBox(double x, double y, double z, double height) {
        return new BoundingBox(
            x - PLAYER_WIDTH_HALF, y, z - PLAYER_WIDTH_HALF,
            x + PLAYER_WIDTH_HALF, y + height, z + PLAYER_WIDTH_HALF
        );
    }

    /**
     * Sprawdza, czy gracz faktycznie stoi na stałym bloku, testując przecięcie
     * bounding boxa przesuniętego minimalnie w dół z bounding boxami bloków w okolicy.
     * To jest znacznie dokładniejsze niż sprawdzenie pojedynczego bloku pod środkiem gracza,
     * ponieważ obsługuje przypadki, gdy gracz stoi na krawędzi bloku, na schodach
     * (górna/dolna połówka), półblokach, otwartych/zamkniętych trapdoorach, płytkach,
     * ścianach czy słupkach (fence/wall hitboxes wystają ponad pełny blok, do y=1.5).
     *
     * Sprawdzamy trzy warstwy Y (checkY-1, checkY, checkY+1) zamiast dwóch, bo
     * bloki wysokości >1 (fence, wall, trapdoor w pozycji pionowej otwartej)
     * mogą mieć swój bounding box zaczynający się w warstwie POWYŻEJ tej, w
     * której nominalnie stoją, a kończący się w warstwie graniczącej ze
     * stopami gracza.
     */
    public static boolean isOnGround(World world, double x, double y, double z) {
        BoundingBox playerBox = playerBoundingBox(x, y - GROUND_EPSILON, z, PLAYER_HEIGHT_STANDING);

        int minX = (int) Math.floor(playerBox.getMinX());
        int maxX = (int) Math.floor(playerBox.getMaxX());
        int minZ = (int) Math.floor(playerBox.getMinZ());
        int maxZ = (int) Math.floor(playerBox.getMaxZ());
        int checkY = (int) Math.floor(y - GROUND_EPSILON);

        for (int bx = minX; bx <= maxX; bx++) {
            for (int bz = minZ; bz <= maxZ; bz++) {
                for (int by = checkY - 1; by <= checkY + 1; by++) {
                    Block block = world.getBlockAt(bx, by, bz);
                    if (!hasCollision(block)) continue;

                    for (BoundingBox blockBox : blockCollisionBoxes(block)) {
                        if (blockBox.overlaps(playerBox)) {
                            // Wystarczy, że górna krawędź bloku (np. wierzch schodów,
                            // zamkniętego trapdooru, górnej połówki, płytki) jest blisko
                            // dolnej krawędzi gracza — stoi NA bloku, nie wewnątrz niego.
                            if (Math.abs(blockBox.getMaxY() - y) < 0.05 + GROUND_EPSILON) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * Sprawdza kolizję poziomą (ściany) na danej pozycji — używane przez
     * Phase/NoClip check do weryfikacji, czy gracz mógł fizycznie znaleźć się
     * w danym miejscu bez przenikania przez bloki.
     */
    public static boolean hasHorizontalCollision(World world, double x, double y, double z, double height) {
        BoundingBox playerBox = playerBoundingBox(x, y, z, height);
        int minX = (int) Math.floor(playerBox.getMinX());
        int maxX = (int) Math.floor(playerBox.getMaxX());
        int minY = (int) Math.floor(playerBox.getMinY());
        int maxY = (int) Math.floor(playerBox.getMaxY());
        int minZ = (int) Math.floor(playerBox.getMinZ());
        int maxZ = (int) Math.floor(playerBox.getMaxZ());

        for (int bx = minX; bx <= maxX; bx++) {
            for (int by = minY; by <= maxY; by++) {
                for (int bz = minZ; bz <= maxZ; bz++) {
                    Block block = world.getBlockAt(bx, by, bz);
                    if (!hasCollision(block)) continue;
                    for (BoundingBox blockBox : blockCollisionBoxes(block)) {
                        if (blockBox.overlaps(playerBox)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * Sprawdza, czy dany segment ruchu (od start do end) przecina jakikolwiek
     * pełny/kolizyjny blok — zgrubna wersja raytrace'a dla Phase check.
     * Próbkuje odcinek co maksymalnie 0.1 bloku żeby wykryć "tunelowanie" przez
     * cienkie ściany przy dużej prędkości ruchu w jednym pakiecie.
     */
    public static boolean segmentIntersectsSolid(World world, Vector start, Vector end, double height) {
        double dist = start.distance(end);
        int steps = Math.max(1, (int) Math.ceil(dist / 0.1));
        for (int i = 0; i <= steps; i++) {
            double t = (double) i / steps;
            double x = start.getX() + (end.getX() - start.getX()) * t;
            double y = start.getY() + (end.getY() - start.getY()) * t;
            double z = start.getZ() + (end.getZ() - start.getZ()) * t;
            if (hasHorizontalCollision(world, x, y, z, height)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Zwraca listę bounding boxów bloku w jego lokalnym układzie świata.
     * Uwzględnia niepełne bloki (płytki, schody, ściany, ogrodzenia) — dla
     * uproszczenia (bez pełnego modelu wokselowego 1.13+) korzystamy z
     * Bukkit Block#getBoundingBox(), który zwraca poprawny kształt kolizji
     * bloku zgodnie z jego BlockData.
     */
    private static BoundingBox[] blockCollisionBoxes(Block block) {
        BoundingBox box = block.getBoundingBox();
        if (box.getVolume() <= 0) {
            return new BoundingBox[0];
        }
        return new BoundingBox[] { box };
    }

    private static boolean hasCollision(Block block) {
        Material type = block.getType();
        if (type == Material.AIR || type.isAir()) return false;
        // Bloki bez kolizji fizycznej mimo że nie są "AIR" (trawa, kwiaty, itp.)
        return block.isCollidable();
    }

    /** Poziom cieczy (0-8) dla bloków typu water/lava z BlockData Levelled. */
    public static int liquidLevel(Block block) {
        BlockData data = block.getBlockData();
        if (data instanceof Levelled levelled) {
            return levelled.getLevel();
        }
        return 0;
    }
}
