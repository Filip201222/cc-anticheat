/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.combat.criticals;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.entity.Player;

/**
 * cc-anticheat — CriticalsCheck
 *
 * Wykrywa "Criticals" — wymuszanie trafień krytycznych (1.5x obrażeń, cząstki
 * gwiazdek) w warunkach, w których vanilla by ich nie przyznał.
 *
 * Warunki krytycznego trafienia w vanilla:
 *   - deltaY gracza (ruch pionowy) w momencie ataku musi być ujemna (gracz opada),
 *   - gracz NIE MOŻE być on ground,
 *   - gracz NIE MOŻE być na drabinie/pnączu,
 *   - gracz NIE MOŻE być w wodzie (chyba że z Riptide trident — pomijamy tu),
 *   - gracz NIE MOŻE mieć efektu Blindness.
 *
 * Cheat "Criticals" fałszuje warunek spadania (np. przez wysyłanie sztucznej
 * mikro-deltaY w dół tuż przed atakiem, mimo stania faktycznie na ziemi) albo
 * ignoruje ograniczenia i wymusza cząstki krytyczne bezwarunkowo na każdym
 * ataku. Weryfikujemy przez naszą NIEZALEŻNĄ (AABB) ocenę gruntu zamiast ufać
 * samej deltaY zgłoszonej przez klienta.
 *
 * NAPRAWA (priorytet 🟡13): poprzednia wersja zawierała błąd merytoryczny —
 * wykluczała sprint z warunków legalnego criticala (`!player.isSprinting()`)
 * z mylnym komentarzem, jakoby sprint blokował critical hity w vanilla. To
 * NIEPRAWDA: sprint NIE ma wpływu na warunek criticala (jedynym wymogiem jest
 * spadanie + brak podparcia/drabiny/wody/blindness). Gracz atakujący w skoku
 * podczas sprintu (bardzo częsty, w pełni legalny wzorzec walki — "sprint
 * reset") był fałszywie flagowany przez ten błędny warunek. Usunięty.
 */
public class CriticalsCheck extends Check {

    public CriticalsCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "Criticals");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.1;
        this.vlDecayMultiplier = 0.9;
        this.flagThreshold = 3.0;
        this.setbackThreshold = Double.MAX_VALUE;
        this.requiredBuffer = 1;
        this.maxBuffer = 10;
    }

    /**
     * Wołane na EntityDamageByEntityEvent, gdy atak gracza został oznaczony
     * jako critical (event.isCritical() == true w Bukkit/Paper).
     */
    public void onCriticalHit() {
        if (tickExemption()) return;

        Player player = data.player;
        MovementData current = data.lastMovement();
        if (current == null) return;

        boolean legitimateFall = current.deltaY < 0
            && !current.actuallyOnGround
            && !current.onClimbable
            && !current.inWater
            && !current.inLava
            && !current.inVehicle
            && !player.hasPotionEffect(org.bukkit.potion.PotionEffectType.BLINDNESS);

        if (!legitimateFall) {
            buffer(2.0, String.format(
                "deltaY:%.4f onGround:%b climbable:%b water:%b",
                current.deltaY, current.actuallyOnGround, current.onClimbable, current.inWater));
        } else {
            reward();
        }
    }
}
