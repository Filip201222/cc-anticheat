/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.world.fastbreak;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.predict.MiningPhysicsEngine;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.GameMode;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

/**
 * cc-anticheat — FastBreakCheck
 *
 * Wykrywa "FastBreak" — łamanie bloków szybciej niż fizycznie pozwala na to
 * formuła vanilla, uwzględniająca narzędzie, enchanty (Efficiency), efekty
 * (Haste, Mining Fatigue, Conduit Power), hardness bloku, oraz medium
 * (na ziemi/w powietrzu/w wodzie z lub bez Aqua Affinity) — patrz
 * MiningPhysicsEngine dla pełnej formuły.
 *
 * Zasada działania: śledzimy moment rozpoczęcia kopania (START_DESTROY_BLOCK
 * z pakietu PLAYER_DIGGING) i moment faktycznego złamania (BlockBreakEvent).
 * Rzeczywisty czas między nimi porównujemy z oczekiwanym czasem obliczonym
 * przez MiningPhysicsEngine.
 *
 * NAPRAWA (priorytet 🟡12): poprzednia wersja liczyła expectedBreakMs TYLKO
 * na podstawie stanu gracza w momencie ROZPOCZĘCIA kopania. Dla bloków o
 * dłuższym czasie łamania (np. diament, obsydian — kilka sekund), gracz może
 * w trakcie zmienić stan (wyskoczyć, wejść do wody) — oba te stany WYDŁUŻAJĄ
 * legalny czas kopania (5x kara za bycie w powietrzu/wodzie bez Aqua Affinity).
 * Porównywanie tylko ze stanem początkowym mogło niesłusznie flagować gracza,
 * który podczas długiego kopania na chwilę podskoczył. Teraz bierzemy MNIEJ
 * restrykcyjne z dwóch oszacowań (start i koniec) — czyli KRÓTSZY oczekiwany
 * czas jako wymagane minimum, żeby dać graczowi korzyść wątpliwości za
 * legalną zmianę kontekstu w trakcie, jednocześnie wciąż łapiąc realne
 * FastBreak (gdzie różnica jest zbyt duża, żeby to wytłumaczyć).
 */
public class FastBreakCheck extends Check {

    private static final double BASE_TOLERANCE_MS = 50.0; // 1 tick marginesu na zaokrąglenie
    private static final double PING_TOLERANCE_FACTOR = 0.5; // dodatkowy margines proporcjonalny do pingu

    private long digStartMs = 0L;
    private double expectedBreakMsAtStart = 0.0;
    private Block diggingBlock = null;
    private boolean diggingInProgress = false;

    public FastBreakCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "FastBreak");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.1;
        this.vlDecayMultiplier = 0.9;
        this.flagThreshold = 3.0;
        this.setbackThreshold = Double.MAX_VALUE; // FastBreak tylko flaguje/cancel, nie robi setbacku pozycji
        this.requiredBuffer = 1;
        this.maxBuffer = 10;
    }

    /**
     * Wołane gdy gracz rozpoczyna kopanie bloku (START_DESTROY_BLOCK z
     * pakietu PLAYER_DIGGING, lub — dla bloków instant-break — pomijane,
     * bo tam nie ma znaczącego okna czasowego do zweryfikowania).
     */
    public void onDigStart(Block block) {
        if (tickExemption()) return;

        Player player = data.player;

        // Creative mode: bloki łamią się natychmiast niezależnie od narzędzia/
        // hardness/enchantów — formuła vanilla dla survivalu tu nie obowiązuje,
        // więc nie ma sensownego oczekiwanego czasu do porównania.
        if (player.getGameMode() == GameMode.CREATIVE) {
            diggingInProgress = false;
            return;
        }

        boolean onGround = player.isOnGround();

        MiningPhysicsEngine.MiningResult result = MiningPhysicsEngine.computeBreakTime(player, block, onGround);

        if (result.instantBreak) {
            diggingInProgress = false;
            return;
        }

        digStartMs = System.currentTimeMillis();
        expectedBreakMsAtStart = result.expectedMs;
        diggingBlock = block;
        diggingInProgress = true;
    }

    /**
     * Wołane gdy blok faktycznie pęka (BlockBreakEvent).
     *
     * @return true jeśli złamanie powinno być anulowane (FastBreak wykryty z wysoką pewnością)
     */
    public boolean onBlockBreak() {
        if (!diggingInProgress) {
            // Blok pękł bez zarejestrowanego START_DESTROY_BLOCK — może być
            // instant-break (już obsłużony w onDigStart) albo utracony packet.
            // Nie flagujemy na podstawie samej nieobecności danych.
            return false;
        }

        diggingInProgress = false;

        if (tickExemption()) return false;

        long actualMs = System.currentTimeMillis() - digStartMs;

        // Przeliczamy oczekiwany czas RAZ JESZCZE dla stanu gracza w momencie
        // ZAKOŃCZENIA kopania i bierzemy KRÓTSZY z dwóch oszacowań — dając
        // graczowi korzyść wątpliwości, jeśli w trakcie kopania legalnie
        // zmienił kontekst na taki, który przyspiesza (lepsze narzędzie w
        // ręku, zniknięcie Mining Fatigue) — patrz javadoc klasy.
        double expectedBreakMsAtEnd = expectedBreakMsAtStart;
        if (diggingBlock != null) {
            Player player = data.player;
            if (player.getGameMode() != GameMode.CREATIVE) {
                MiningPhysicsEngine.MiningResult endResult =
                    MiningPhysicsEngine.computeBreakTime(player, diggingBlock, player.isOnGround());
                if (!endResult.instantBreak) {
                    expectedBreakMsAtEnd = endResult.expectedMs;
                }
            }
        }
        double expectedBreakMs = Math.min(expectedBreakMsAtStart, expectedBreakMsAtEnd);

        double tolerance = BASE_TOLERANCE_MS + data.averagePing() * PING_TOLERANCE_FACTOR;

        if (actualMs < expectedBreakMs - tolerance) {
            double deficitRatio = (expectedBreakMs - actualMs) / Math.max(expectedBreakMs, 1.0);
            double severity = Math.min(deficitRatio * 6.0, 4.0);
            buffer(severity, String.format(
                "actualMs:%d expectedMs:%.0f tolerance:%.0f ratio:%.2f",
                actualMs, expectedBreakMs, tolerance, deficitRatio));
        } else {
            reward();
        }

        return getViolationLevel() >= flagThreshold * 2;
    }

    /** Wołane gdy gracz anuluje kopanie (STOP_DESTROY_BLOCK, zmiana celu, itp.) bez złamania bloku. */
    public void onDigCancel() {
        diggingInProgress = false;
        diggingBlock = null;
    }

    @Override
    public void reset() {
        super.reset();
        diggingInProgress = false;
        digStartMs = 0L;
        expectedBreakMsAtStart = 0.0;
        diggingBlock = null;
    }
}
