/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.movement.liquid;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.CCAnticheat;
import dev.cc.anticheat.data.MovementData;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.predict.SetbackUtil;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

/**
 * cc-anticheat — JesusCheck (WaterWalk)
 *
 * Wykrywa "chodzenie po wodzie" — utrzymywanie się na powierzchni cieczy
 * zamiast zanurzania/pływania zgodnie z fizyką vanilla.
 *
 * Legalne sposoby utrzymania się na wodzie, które MUSIMY wykluczyć:
 *   - Frost Walker (lód tworzony pod stopami — blok pod graczem to wtedy
 *     FROSTED_ICE, nie WATER, więc naturalnie wypada z tego checka)
 *   - Łódź (gracz w vehicle)
 *   - Skok z brzegu (pierwsze 1-2 ticki nad wodą po skoku — łagodzimy buforem)
 *   - Bąbelki (bubble column) — osobny check gravity dla tego przypadku
 *
 * Zasada: jeśli gracz ma pod stopami tylko blok WATER (nie dno, nie ląd) i NIE
 * jest w trybie pływania (swimming) ani nie tonie (submerged), to w vanilla
 * MUSI opadać zgodnie z grawitacją wodną, a nie utrzymywać stałą wysokość
 * przez dłuższy czas.
 */
public class JesusCheck extends Check {

    private static final int HOVER_TICK_THRESHOLD = 6;

    private int hoverStreak = 0;

    private final CCAnticheat plugin;

    public JesusCheck(PlayerData data, ViolationProcessor vp, CCAnticheat plugin) {
        super(data, vp, "Jesus");
        this.plugin = plugin;
        this.vlIncrement = 1.0;
        this.vlDecay = 0.1;
        this.vlDecayMultiplier = 0.95;
        this.flagThreshold = 5.0;
        this.setbackThreshold = 14.0;
        this.requiredBuffer = 2;
        this.maxBuffer = 20;
    }

    public void onMovement(MovementData current) {
        Player player = data.player;

        if (tickExemption()) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (current.inVehicle) return;
        if (player.isSwimming()) return; // pływanie na powierzchni jest legalne (nie "chodzenie")

        boolean onlyWaterSurface = isStandingOnWaterSurface(player, current);

        if (!onlyWaterSurface) {
            hoverStreak = Math.max(0, hoverStreak - 2);
            reward();
            return;
        }

        // Frost Walker tworzy lód pod stopami — wtedy blok pod graczem przestaje
        // być wodą (staje się FROSTED_ICE), więc onlyWaterSurface już to wyklucza.

        boolean notSinking = current.deltaY >= -0.01;

        if (notSinking) {
            hoverStreak++;
            if (hoverStreak > HOVER_TICK_THRESHOLD) {
                buffer(2.0, String.format("hoverStreak:%d deltaY:%.5f", hoverStreak, current.deltaY));
            }
        } else {
            hoverStreak = 0;
            reward();
        }

        if (getViolationLevel() >= setbackThreshold) {
            SetbackUtil.performSetback(plugin, data, "Jesus");
            hoverStreak = 0;
        }
    }

    /**
     * Sprawdza, czy gracz stoi bezpośrednio na powierzchni wody — czyli blok
     * pod nim jest wodą, a pod tym blokiem NIE MA dna w zasięgu jednego bloku
     * (żeby nie flagować graczy stojących w płytkiej wodzie na dnie).
     */
    @SuppressWarnings("deprecation")
    private boolean isStandingOnWaterSurface(Player player, MovementData current) {
        Block below = player.getWorld().getBlockAt(
            (int) Math.floor(current.x), (int) Math.floor(current.y - 0.1), (int) Math.floor(current.z));

        if (below.getType() != Material.WATER) return false;

        // Sprawdź, czy gracz jest zanurzony (submerged) — jeśli tak, to normalne pływanie.
        Block atFeet = player.getWorld().getBlockAt(
            (int) Math.floor(current.x), (int) Math.floor(current.y + 0.3), (int) Math.floor(current.z));
        if (atFeet.getType() == Material.WATER) return false; // zanurzony po pas+ — legalne

        // Sprawdź głębokość wody pod graczem — jeśli dno jest tuż pod powierzchnią
        // (płytka woda), stanie na "dnie przez wodę" jest legalne.
        int waterDepth = 0;
        for (int i = 1; i <= 4; i++) {
            Block b = player.getWorld().getBlockAt(
                (int) Math.floor(current.x), (int) Math.floor(current.y - 0.1 - i), (int) Math.floor(current.z));
            if (b.getType() == Material.WATER) {
                waterDepth++;
            } else {
                break;
            }
        }
        return waterDepth >= 3; // wymagamy realnej głębi, żeby wykluczyć płytką wodę/dno
    }

    @Override
    public void reset() {
        super.reset();
        hoverStreak = 0;
    }
}
