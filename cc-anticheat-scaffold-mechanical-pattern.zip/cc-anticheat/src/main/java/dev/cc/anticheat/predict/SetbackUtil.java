/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.predict;

import dev.cc.anticheat.CCAnticheat;
import dev.cc.anticheat.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

/**
 * cc-anticheat — SetbackUtil
 *
 * Scentralizowana logika cofania gracza do ostatniej znanej bezpiecznej pozycji.
 * Wszystkie checki ruchu wołają tu zamiast implementować własną logikę teleportu,
 * dzięki czemu zachowanie (exempt po setbacku, aktualizacja pozycji bazowej) jest
 * spójne w całym projekcie.
 *
 * Bezpieczna pozycja jest aktualizowana przez CheckManager po każdym ticku ruchu,
 * w którym żaden check nie zgłosił naruszenia w danym ticku (patrz updateSafePosition).
 */
public final class SetbackUtil {

    private SetbackUtil() {}

    /**
     * Zapisuje bieżącą pozycję jako bezpieczną — wołane po czystym ticku ruchu.
     */
    public static void updateSafePosition(PlayerData data) {
        data.setbackX = data.x;
        data.setbackY = data.y;
        data.setbackZ = data.z;
        data.setbackYaw = data.yaw;
        data.setbackPitch = data.pitch;
    }

    /**
     * Wykonuje teleport gracza do ostatniej zapisanej bezpiecznej pozycji.
     * Zwalnia (exempt) wszystkie checki na 20 ticków, żeby sam setback nie
     * wygenerował kolejnej fali flag (nagła zmiana pozycji jest z definicji
     * "nielegalnym" ruchem z punktu widzenia predykcji fizyki).
     */
    public static void performSetback(CCAnticheat plugin, PlayerData data, String reason) {
        if (data.awaitingTeleportConfirm) {
            // Setback już w toku — nie duplikujemy teleportów.
            return;
        }
        data.awaitingTeleportConfirm = true;
        data.exemptAll(20);

        Player player = data.player;
        Location target = new Location(player.getWorld(),
            data.setbackX, data.setbackY, data.setbackZ,
            data.setbackYaw, data.setbackPitch);

        Bukkit.getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) {
                player.teleport(target);
            }
            data.awaitingTeleportConfirm = false;
        });
    }
}
