/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.bait;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.wrappers.EnumWrappers;
import com.comphenix.protocol.wrappers.PlayerInfoData;
import com.comphenix.protocol.wrappers.Pair;
import com.comphenix.protocol.wrappers.WrappedChatComponent;
import com.comphenix.protocol.wrappers.WrappedDataValue;
import com.comphenix.protocol.wrappers.WrappedDataWatcher;
import com.comphenix.protocol.wrappers.WrappedGameProfile;
import dev.cc.anticheat.CCAnticheat;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * cc-anticheat — BaitEspManager
 *
 * Spawns a decoy "player" entity that is sent, via raw ProtocolLib packets,
 * ONLY to one specific client — never touching the shared game state, never
 * seen by anyone else.
 *
 * The decoy:
 *   - Is disguised under a fixed, non-existent name (_77Nezzi_)
 *   - Wears a full diamond kit and holds a diamond pickaxe
 *   - Sits 30 blocks above ("up") or below ("down") the target
 *   - Carries the INVISIBLE entity flag, so a vanilla client renders
 *     nothing (no body, no nametag) — only a client whose ESP/X-ray
 *     module reads raw entity-tracker data (bypassing the invisibility
 *     render check) will actually be able to "see" it.
 *   - Flashes briefly visible for ~10 ticks right after spawning, then
 *     goes invisible — so the target's client is guaranteed to receive
 *     at least one visible frame before the bait effectively vanishes
 *     to legitimate rendering.
 *   - "Fake-walks": nudged by ~0.01 blocks every couple of ticks via
 *     ENTITY_TELEPORT packets, with no real server-side entity or physics
 *     behind it.
 *
 * IMPORTANT — protocol version note:
 * This targets the 1.19.4 protocol / ProtocolLib 5.1.0, where Mojang merged
 * the old "Spawn Player" packet into the generic SPAWN_ENTITY packet, and
 * split PLAYER_INFO into add (PLAYER_INFO) / remove (PLAYER_INFO_REMOVE)
 * actions. If you upgrade the server/ProtocolLib version, re-verify these
 * packet field names against ProtocolLib's changelog before relying on it.
 */
public class BaitEspManager {

    private static final String DECOY_NAME   = "_77Nezzi_";
    private static final double OFFSET       = 30.0;
    /** Fake "step" size per tick — simulated walking with no real physics behind it. */
    private static final double STEP         = 0.01;
    /** How many ticks the bait stays briefly visible before going invisible. */
    private static final int FLASH_TICKS     = 10;
    /** Ile ticków (min/max) bait utrzymuje TEN SAM kierunek ruchu przed zmianą na nowy (priorytet 🔴 "Bait randomizacja pozycji/ruchu"). */
    private static final int MIN_PHASE_TICKS = 8;
    private static final int MAX_PHASE_TICKS = 24;

    public enum Direction { UP, DOWN }

    private final CCAnticheat plugin;
    private final ProtocolManager protocol;
    private final Map<UUID, ActiveBait> active = new HashMap<>();

    public BaitEspManager(CCAnticheat plugin) {
        this.plugin   = plugin;
        this.protocol = ProtocolLibrary.getProtocolManager();
    }

    /** Spawns (replacing any previous one) a bait only {@code viewer} can receive packets for. */
    public void start(Player viewer, Direction direction) {
        stop(viewer);

        int entityId  = ThreadLocalRandom.current().nextInt(1_000_000, 2_000_000_000);
        UUID fakeUuid = UUID.randomUUID();

        Location base = viewer.getLocation().clone();
        base.setY(base.getY() + (direction == Direction.UP ? OFFSET : -OFFSET));
        base.setPitch(0f);

        WrappedGameProfile profile = new WrappedGameProfile(fakeUuid, DECOY_NAME);

        sendPlayerInfoAdd(viewer, profile);
        sendSpawn(viewer, entityId, fakeUuid, base);
        sendEquipment(viewer, entityId);
        sendMetadata(viewer, entityId, false); // brief flash: visible at first

        ActiveBait bait = new ActiveBait(entityId, fakeUuid, base.clone());
        active.put(viewer.getUniqueId(), bait);

        // Go invisible after the flash window, then remove from the tab list
        // (the tab-list add was only needed so the client resolves a skin).
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!viewer.isOnline() || !active.containsKey(viewer.getUniqueId())) return;
            sendMetadata(viewer, entityId, true);
            sendPlayerInfoRemove(viewer, fakeUuid);
            ActiveBait current = active.get(viewer.getUniqueId());
            if (current != null) current.invisiblePhase = true;
        }, FLASH_TICKS);

        // Fake micro-walk loop — NAPRAWA (przegląd 🔴 "Bait randomizacja
        // pozycji/ruchu"): poprzednia wersja robiła CZYSTO LOSOWY krok co
        // tick (nextBoolean() niezależnie na każdej osi, każdy tick) — to
        // jest szum bez trwałego kierunku, więc gracz z ESP fizycznie nie
        // MÓGŁBY skorelować swoją rotację z ruchem baita (nie ma spójnego
        // wektora do podążania). Teraz bait porusza się w FAZACH: wybiera
        // losowy kierunek (kąt w płaszczyźnie XZ) i utrzymuje go przez
        // MIN_PHASE_TICKS-MAX_PHASE_TICKS ticków, dając rozpoznawalny,
        // ciągły wektor ruchu, który BaitEspCheck może skorelować z
        // rotacją gracza (patrz BaitEspCheck — tracking correlation).
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            ActiveBait ab = active.get(viewer.getUniqueId());
            if (ab == null || !viewer.isOnline()) return;

            if (ab.phaseTicksRemaining <= 0) {
                double angle = ThreadLocalRandom.current().nextDouble(0, Math.PI * 2);
                ab.directionX = Math.cos(angle);
                ab.directionZ = Math.sin(angle);
                ab.phaseTicksRemaining = ThreadLocalRandom.current().nextInt(MIN_PHASE_TICKS, MAX_PHASE_TICKS + 1);
            }
            ab.phaseTicksRemaining--;

            ab.currentLocation.add(ab.directionX * STEP, 0, ab.directionZ * STEP);
            sendTeleport(viewer, entityId, ab.currentLocation);
        }, 4L, 2L);

        bait.task = task;
    }

    /** Despawns the bait for {@code viewer}, if any. @return true if one was active. */
    public boolean stop(Player viewer) {
        ActiveBait ab = active.remove(viewer.getUniqueId());
        if (ab == null) return false;
        if (ab.task != null) ab.task.cancel();
        if (viewer.isOnline()) {
            sendDestroy(viewer, ab.entityId);
            sendPlayerInfoRemove(viewer, ab.fakeUuid);
        }
        return true;
    }

    public boolean isActive(Player viewer) {
        return active.containsKey(viewer.getUniqueId());
    }

    // ── Packet builders ──────────────────────────────────────────────────────

    private void sendPlayerInfoAdd(Player viewer, WrappedGameProfile profile) {
        PacketContainer packet = protocol.createPacket(PacketType.Play.Server.PLAYER_INFO);
        packet.getPlayerInfoActions().write(0, EnumSet.of(EnumWrappers.PlayerInfoAction.ADD_PLAYER));
        PlayerInfoData data = new PlayerInfoData(profile, 0,
                EnumWrappers.NativeGameMode.SURVIVAL, WrappedChatComponent.fromText(DECOY_NAME));
        packet.getPlayerInfoDataLists().write(1, List.of(data));
        send(viewer, packet);
    }

    private void sendPlayerInfoRemove(Player viewer, UUID fakeUuid) {
        PacketContainer packet = protocol.createPacket(PacketType.Play.Server.PLAYER_INFO_REMOVE);
        packet.getUUIDLists().write(0, List.of(fakeUuid));
        send(viewer, packet);
    }

    private void sendSpawn(Player viewer, int entityId, UUID fakeUuid, Location loc) {
        PacketContainer packet = protocol.createPacket(PacketType.Play.Server.SPAWN_ENTITY);
        packet.getIntegers().write(0, entityId);
        packet.getEntityTypeModifier().write(0, EntityType.PLAYER);
        packet.getUUIDs().write(0, fakeUuid);
        packet.getDoubles()
                .write(0, loc.getX())
                .write(1, loc.getY())
                .write(2, loc.getZ());
        packet.getBytes()
                .write(0, (byte) (loc.getYaw() * 256F / 360F))
                .write(1, (byte) (loc.getPitch() * 256F / 360F));
        send(viewer, packet);
    }

    private void sendTeleport(Player viewer, int entityId, Location loc) {
        PacketContainer packet = protocol.createPacket(PacketType.Play.Server.ENTITY_TELEPORT);
        packet.getIntegers().write(0, entityId);
        packet.getDoubles()
                .write(0, loc.getX())
                .write(1, loc.getY())
                .write(2, loc.getZ());
        packet.getBytes()
                .write(0, (byte) (loc.getYaw() * 256F / 360F))
                .write(1, (byte) (loc.getPitch() * 256F / 360F));
        packet.getBooleans().write(0, true); // onGround
        send(viewer, packet);
    }

    private void sendMetadata(Player viewer, int entityId, boolean invisible) {
        PacketContainer packet = protocol.createPacket(PacketType.Play.Server.ENTITY_METADATA);
        packet.getIntegers().write(0, entityId);
        List<WrappedDataValue> values = List.of(
                // Index 0 = shared entity "flags" byte; bit 0x20 = invisible.
                new WrappedDataValue(0, WrappedDataWatcher.Registry.get(Byte.class), (byte) (invisible ? 0x20 : 0x00))
        );
        packet.getDataValueCollectionModifier().writeSafely(0, values);
        send(viewer, packet);
    }

    private void sendEquipment(Player viewer, int entityId) {
        PacketContainer packet = protocol.createPacket(PacketType.Play.Server.ENTITY_EQUIPMENT);
        packet.getIntegers().write(0, entityId);

        List<Pair<EnumWrappers.ItemSlot, ItemStack>> slots = List.of(
                new Pair<>(EnumWrappers.ItemSlot.MAINHAND, new ItemStack(Material.DIAMOND_PICKAXE)),
                new Pair<>(EnumWrappers.ItemSlot.HEAD,      new ItemStack(Material.DIAMOND_HELMET)),
                new Pair<>(EnumWrappers.ItemSlot.CHEST,     new ItemStack(Material.DIAMOND_CHESTPLATE)),
                new Pair<>(EnumWrappers.ItemSlot.LEGS,      new ItemStack(Material.DIAMOND_LEGGINGS)),
                new Pair<>(EnumWrappers.ItemSlot.FEET,      new ItemStack(Material.DIAMOND_BOOTS))
        );
        packet.getSlotStackPairLists().write(0, slots);
        send(viewer, packet);
    }

    private void sendDestroy(Player viewer, int entityId) {
        PacketContainer packet = protocol.createPacket(PacketType.Play.Server.ENTITY_DESTROY);
        packet.getIntLists().write(0, List.of(entityId));
        send(viewer, packet);
    }

    private void send(Player viewer, PacketContainer packet) {
        try {
            protocol.sendServerPacket(viewer, packet);
        } catch (Exception ex) {
            plugin.getLogger().warning("[BaitEsp] Failed to send " + packet.getType() + " to "
                    + viewer.getName() + ": " + ex.getMessage());
        }
    }

    // ── Internal state ───────────────────────────────────────────────────────

    private static class ActiveBait {
        final int entityId;
        final UUID fakeUuid;
        final Location currentLocation;
        BukkitTask task;
        /** Ustawiane true po upływie FLASH_TICKS, gdy bait staje się niewidoczny dla legalnego klienta. */
        volatile boolean invisiblePhase = false;
        /** Bieżący kierunek fazowego ruchu (znormalizowany wektor XZ) — patrz start(). */
        double directionX = 0, directionZ = 0;
        int phaseTicksRemaining = 0;

        ActiveBait(int entityId, UUID fakeUuid, Location currentLocation) {
            this.entityId        = entityId;
            this.fakeUuid         = fakeUuid;
            this.currentLocation = currentLocation;
        }
    }

    /**
     * Zwraca aktualną pozycję aktywnego baita dla danego gracza, lub null
     * jeśli żaden bait nie jest aktywny albo wciąż jest w fazie widocznego
     * "flash" (patrz FLASH_TICKS) — w tej fazie legalny klient TEŻ widzi
     * encję, więc reakcja gracza na nią nie jest informatywna dla detekcji
     * ESP. Dopiero po przejściu w fazę niewidoczną, reakcja gracza (rotacja
     * podążająca za pozycją baita mimo braku legalnego sposobu, by go
     * widzieć) jest sygnałem.
     */
    public Location getReactableLocation(Player viewer) {
        ActiveBait ab = active.get(viewer.getUniqueId());
        if (ab == null || !ab.invisiblePhase) return null;
        return ab.currentLocation.clone();
    }

    /**
     * Zwraca bieżący wektor kierunku fazowego ruchu baita (znormalizowany,
     * płaszczyzna XZ), lub null w tych samych warunkach co
     * getReactableLocation. Używane przez BaitEspCheck do korelacji
     * "bait porusza się w kierunku X → gracz obraca kamerę w kierunku X"
     * (przegląd 🔴 "Bait tracking correlation") — sama pozycja/kąt do baita
     * nie wystarcza, żeby ocenić, czy gracz REAGUJE na jego RUCH, nie tylko
     * przypadkiem patrzy w tamtą stronę.
     */
    public double[] getBaitMovementDirection(Player viewer) {
        ActiveBait ab = active.get(viewer.getUniqueId());
        if (ab == null || !ab.invisiblePhase) return null;
        return new double[]{ab.directionX, ab.directionZ};
    }
}
