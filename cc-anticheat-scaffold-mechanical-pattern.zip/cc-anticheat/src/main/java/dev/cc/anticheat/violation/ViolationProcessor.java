/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.violation;

import dev.cc.anticheat.CCAnticheat;
import dev.cc.anticheat.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * cc-anticheat — ViolationProcessor
 *
 * Przetwarza flagi zgłaszane przez poszczególne checki (przez Check#buffer()).
 *
 * W przeciwieństwie do poprzedniej wersji, mitygacja NIE opiera się na jednym
 * globalnym liczniku (data.totalViolations) sumującym wszystkie checki razem —
 * każdy check ma własny VL (patrz Check.java) i sam decyduje, kiedy zgłosić
 * flagę. ViolationProcessor odpowiada za:
 *   - wysyłkę alertów do staffu,
 *   - per-gracza, per-check licznik "punktów karnych" używany WYŁĄCZNIE do
 *     globalnej eskalacji (cancel/setback/kick) tak, by wiele różnych checków
 *     nie mogło w nieskończoność same z siebie eskalować do kicka pojedynczym
 *     drobnym naruszeniem, ale suma wielu realnych naruszeń — mogła.
 */
public class ViolationProcessor {

    private final CCAnticheat plugin;
    private final Logger log;

    private static final int CANCEL_THRESHOLD = 6;
    private static final int SETBACK_THRESHOLD = 18;
    private static final int KICK_THRESHOLD = 60;

    /** Punkty karne per gracz, z naturalnym zanikiem w czasie (obsługiwane przez DecayTask). */
    private final Map<UUID, Double> globalPoints = new ConcurrentHashMap<>();

    public ViolationProcessor(CCAnticheat plugin) {
        this.plugin = plugin;
        this.log = plugin.getLogger();
    }

    /**
     * Przetwarza pojedynczą flagę zgłoszoną przez check, z domyślnym
     * mnożnikiem korelacji 1.0 (kompatybilność wsteczna — patrz przeciążona
     * wersja poniżej dla combat checków korzystających z CombatContext).
     *
     * @param data       stan gracza
     * @param checkName  np. "Speed/A", "Killaura/Rotation"
     * @param detail     opis debugowy (dołączany do alertu)
     * @param vl         aktualny VL checka w momencie zgłoszenia
     * @param setback    czy check sam zażądał setbacku (przekroczył swój setbackThreshold)
     */
    public ViolationResult flag(PlayerData data, String checkName, String detail, double vl, boolean setback) {
        return flag(data, checkName, detail, vl, setback, 1.0);
    }

    /**
     * Przetwarza flagę z jawnym mnożnikiem korelacji (punkt 🟠6 z przeglądu:
     * "jeśli jednocześnie Velocity anomaly + Aim anomaly + Reach anomaly, to
     * confidence powinien rosnąć mocniej niż przy trzech całkowicie
     * niezależnych flagach"). Mnożnik > 1.0 oznacza, że TEN atak/tick
     * wygenerował sygnał z WIĘCEJ NIŻ JEDNEGO niezależnego checka naraz
     * (patrz CombatContext#correlationMultiplier) — globalne punkty karne
     * rosną proporcjonalnie mocniej, bo skorelowany sygnał jest silniejszym
     * dowodem niż suma tych samych incydentów rozproszonych w czasie.
     */
    public ViolationResult flag(PlayerData data, String checkName, String detail, double vl, boolean setback, double correlationMultiplier) {
        UUID id = data.uuid;
        double points = globalPoints.merge(id, correlationMultiplier, Double::sum);

        String correlatedNote = correlationMultiplier > 1.0
            ? String.format(" | correlation:x%.1f", correlationMultiplier) : "";
        plugin.getAlertManager().sendAlert(data.player.getName(), checkName, detail, vl);
        log.info("[Flag] " + data.player.getName() + " | " + checkName + " | " + detail
            + " | globalPts:" + String.format("%.1f", points) + correlatedNote);

        Mitigation mitigation = Mitigation.NONE;

        if (points >= KICK_THRESHOLD) {
            mitigation = Mitigation.KICK;
            scheduleKick(data, checkName);
        } else if (setback || points >= SETBACK_THRESHOLD) {
            mitigation = Mitigation.SETBACK;
        } else if (points >= CANCEL_THRESHOLD) {
            mitigation = Mitigation.CANCEL;
        }

        return new ViolationResult(mitigation);
    }

    /**
     * Naturalny zanik punktów karnych w czasie — wołane cyklicznie (co 1s) przez
     * DecayTask zarejestrowany w CCAnticheat#onEnable, żeby stare, pojedyncze
     * incydenty nie kumulowały się w nieskończoność do kicka.
     */
    public void decayGlobalPoints(UUID uuid) {
        globalPoints.computeIfPresent(uuid, (k, v) -> Math.max(0.0, v - 0.5));
    }

    public void clearGlobalPoints(UUID uuid) {
        globalPoints.remove(uuid);
    }

    public double getGlobalPoints(UUID uuid) {
        return globalPoints.getOrDefault(uuid, 0.0);
    }

    private void scheduleKick(PlayerData data, String checkName) {
        plugin.getAlertManager().sendKickAlert(data.player.getName(), checkName,
            "globalPts:" + String.format("%.1f", getGlobalPoints(data.uuid)));
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (data.player.isOnline()) {
                data.player.kickPlayer(ChatColor.RED + "Kicked by cc-anticheat\n"
                    + ChatColor.GRAY + "Check: " + checkName);
            }
        });
        clearGlobalPoints(data.uuid);
    }

    // ── Result types ──────────────────────────────────────────────────────────

    public enum Mitigation { NONE, CANCEL, SETBACK, KICK }

    public static class ViolationResult {
        public final Mitigation mitigation;
        public ViolationResult(Mitigation m) { this.mitigation = m; }
        public boolean shouldCancel() { return mitigation == Mitigation.CANCEL || mitigation == Mitigation.KICK; }
        public boolean shouldSetback() { return mitigation == Mitigation.SETBACK || mitigation == Mitigation.KICK; }
    }
}
