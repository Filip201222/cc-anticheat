/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.combat.killaura;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.check.combat.CombatContext;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.predict.EntityHistoryTracker;
import dev.cc.anticheat.predict.RayTraceUtil;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;

/**
 * cc-anticheat — KillAuraCheck
 *
 * NAPRAWA (specyfikacja, punkt 3 "KillAura / combat correlation"): poprzednia
 * wersja miała cztery sub-checki, z których dwa (Multi-entity, Angle) woływały
 * buffer() NIEZALEŻNIE od pozostałych — czyli pojedyncza anomalia jednego typu
 * mogła sama z siebie napędzać VL, wbrew zasadzie "nie karz za pojedynczą
 * anomalię". Przebudowane na model KORELACYJNY:
 *
 *   każdy sygnał (rotacja, kąt/raytrace, brak swinga, target switching,
 *   rotation acceleration) daje PUNKTY za DANY atak, a buffer() jest wołane
 *   RAZ na atak z sumą punktów ze wszystkich sygnałów tego ataku — dopiero
 *   kilka niezależnych anomalii naraz generuje istotną karę, tak jak prosi
 *   specyfikacja ("Reach anomaly +3, Rotation anomaly +2..." — ten sam wzorzec
 *   zastosowany tutaj w skali pojedynczego ataku zamiast globalnego confidence,
 *   bo KillAura z natury jest wykrywalna na poziomie POJEDYNCZEGO ataku przez
 *   korelację cech tego ataku, nie tylko przez akumulację w czasie).
 *
 * Sygnały korelowane w jednym ataku:
 *   A. Attack angle (raytrace)   — czy promień z zamrożonej rotacji faktycznie
 *      przecina cel (nie tylko "jest blisko" — patrz RayTraceUtil/ReachCheck)
 *   B. Rotation acceleration    — nienaturalnie gwałtowna zmiana kierunku
 *      patrzenia bezpośrednio przed atakiem (jerk — druga pochodna rotacji)
 *   C. Target switching         — atak na inną encję niż ta, na którą gracz
 *      patrzył przez ostatnie kilka ticków (mechaniczne "przeskakiwanie")
 *   D. Attack-without-swing     — stosunek ataków bez ARM_ANIMATION w oknie
 *   E. Multi-entity clustering  — kilka RÓŻNYCH celów faktycznie w FOV
 *      zaatakowanych w bardzo krótkim oknie czasowym
 *
 * "rotationSamples" w PlayerData (wcześniej zadeklarowane, ale nigdy
 * nieużywane — martwe pole) jest teraz zasilane przez onRotation() i
 * konsumowane przez sub-check B (rotation acceleration).
 */
public class KillAuraCheck extends Check {

    private static final long CLUSTER_WINDOW_MS = 100L;
    private static final int CLUSTER_ENTITY_MIN = 2;
    private static final double FOV_LIMIT = 100.0; // stopnie, z marginesem na lag
    private static final int SWING_RATIO_WINDOW = 20; // ticki
    private static final int NO_SWING_SAMPLE_MIN = 6;
    private static final double NO_SWING_RATIO_THRESHOLD = 0.6;
    private static final long ANGLE_LOOKUP_WINDOW_MS = 60L;
    /** Margines raytrace na bounding box celu — float/double precision, patrz specyfikacja. */
    private static final double RAYTRACE_EXPAND = 0.08;
    private static final double REACH_LIMIT = 3.2;
    /** Próg jerku (druga pochodna rotacji) uznawany za nienaturalny — patrz computeRecentJerk. */
    private static final double ROTATION_JERK_THRESHOLD = 25.0;

    /** Próg SUMY punktów korelacji z jednego ataku, powyżej którego atak faktycznie generuje flagę. */
    private static final double CORRELATION_FLAG_THRESHOLD = 4.0;

    private int swingsThisWindow = 0;
    private int attacksThisWindow = 0;
    private int windowTick = 0;

    private final ArrayDeque<Boolean> recentSwingFlags = new ArrayDeque<>(20);
    /** Ostatni cel, na który gracz faktycznie "celował" (w wąskim FOV) przez kilka ticków z rzędu — do target-switching. */
    private int sustainedLookTargetId = -1;
    private int sustainedLookTicks = 0;

    public KillAuraCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "Killaura");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.05;
        this.vlDecayMultiplier = 0.99;
        this.flagThreshold = 3.0;
        this.setbackThreshold = Double.MAX_VALUE; // Killaura nigdy nie robi setbacku, tylko cancel/alert
        this.requiredBuffer = 1;
        this.maxBuffer = 15;
    }

    // ── Wołane na ARM_ANIMATION ──────────────────────────────────────────────
    public void onSwing() {
        swingsThisWindow++;
    }

    /**
     * Wołane na każdym pakiecie rotacji — zasila rotationSamples (dla sub-check
     * B, rotation acceleration/jerk) i śledzi "sustained look target" (dla
     * sub-check C, target switching) przez sprawdzenie, czy jakaś encja jest
     * aktualnie w wąskim FOV gracza.
     */
    public void onRotation(float yaw, float pitch) {
        data.rotationSamples.addLast(new float[]{yaw, pitch});
        while (data.rotationSamples.size() > 10) data.rotationSamples.pollFirst();
    }

    // ── Wołane na USE_ENTITY (atak) ──────────────────────────────────────────
    /** Wołane bez CombatContext (kompatybilność wsteczna) — tworzy jednorazowy, odrzucany kontekst. */
    public void onAttack(Entity target, boolean hadSwing) {
        onAttack(target, hadSwing, new CombatContext());
    }

    /**
     * Wołane na USE_ENTITY (atak). Zapisuje wynik korelacji do wspólnego
     * CombatContext, żeby CheckManager mógł go skorelować z AimBotCheck dla
     * tego samego ataku (przegląd, punkt 🔴2).
     */
    public void onAttack(Entity target, boolean hadSwing, CombatContext context) {
        if (tickExemption()) return;

        long now = System.currentTimeMillis();
        double correlationPoints = 0.0;
        StringBuilder reasons = new StringBuilder();

        // ── A. Attack angle przez raytrace (nie tylko "blisko") ───────────────
        double missDistance = lagCompensatedRaytraceMiss(target);
        boolean rayHit = missDistance <= 0.0;
        if (!rayHit && target instanceof LivingEntity) {
            correlationPoints += 3.0;
            reasons.append(String.format("angle(miss:%.2f)+3;", missDistance));
        }

        // ── B. Rotation acceleration (jerk) tuż przed atakiem ─────────────────
        double jerk = computeRecentJerk();
        if (jerk > ROTATION_JERK_THRESHOLD) {
            correlationPoints += 2.0;
            reasons.append(String.format("jerk(%.1f)+2;", jerk));
        }

        // ── C. Target switching — atak na cel inny niż ten, na którym gracz
        //      faktycznie utrzymywał spojrzenie przez ostatnie ticki ──────────
        updateSustainedLookTarget(target);
        boolean isSwitchedTarget = sustainedLookTargetId != -1
            && sustainedLookTargetId != target.getEntityId()
            && sustainedLookTicks < 2;
        if (isSwitchedTarget) {
            correlationPoints += 2.0;
            reasons.append("targetSwitch+2;");
        }

        // ── D. Attack-without-swing (stosunek w oknie) ────────────────────────
        recentSwingFlags.addLast(hadSwing);
        while (recentSwingFlags.size() > 20) recentSwingFlags.pollFirst();
        if (recentSwingFlags.size() >= NO_SWING_SAMPLE_MIN) {
            long noSwingCount = recentSwingFlags.stream().filter(swung -> !swung).count();
            double ratio = (double) noSwingCount / recentSwingFlags.size();
            if (ratio >= NO_SWING_RATIO_THRESHOLD) {
                correlationPoints += 1.0;
                reasons.append(String.format("noSwingRatio(%.2f)+1;", ratio));
            }
        }

        // ── E. Multi-entity clustering (kilka RÓŻNYCH celów w FOV, krótkie okno) ──
        data.recentAttackTimestamps.addLast(now);
        while (!data.recentAttackTimestamps.isEmpty()
                && now - data.recentAttackTimestamps.peekFirst() > CLUSTER_WINDOW_MS) {
            data.recentAttackTimestamps.pollFirst();
        }
        if (rayHit || angleWithinFov(target)) {
            data.entitiesAttackedWindow.add(target.getEntityId());
        }
        if (data.entitiesAttackedWindow.size() >= CLUSTER_ENTITY_MIN
                && data.recentAttackTimestamps.size() >= CLUSTER_ENTITY_MIN) {
            correlationPoints += 2.0;
            reasons.append(String.format("multiEntity(%d)+2;", data.entitiesAttackedWindow.size()));
        }
        if (data.recentAttackTimestamps.isEmpty()) {
            data.entitiesAttackedWindow.clear();
        }

        // Korelacja: dopiero SUMA sygnałów tego ataku decyduje o flagowaniu.
        // Pojedyncza, niewystarczająca anomalia (0 < correlationPoints < próg)
        // świadomie NIE woła ani buffer(), ani reward() — to wciąż był lekko
        // podejrzany atak, więc nie zasługuje na aktywne "czyszczenie" VL, ale
        // też nie jest wystarczającym dowodem samo w sobie, żeby karać.
        //
        // UWAGA: nie stosujemy tutaj context.correlationMultiplier() — w tym
        // momencie AimBotCheck mógł jeszcze nie przetworzyć tego samego ataku
        // (kolejność wywołań w CheckManager), więc kontekst byłby niepełny.
        // Korelację aplikuje CheckManager PO wywołaniu obu checków — patrz
        // CheckManager#onAttack.
        if (correlationPoints >= CORRELATION_FLAG_THRESHOLD) {
            context.killAuraAnomaly = true;
            buffer(correlationPoints / 2.0, "correlation:" + reasons + " total:" + correlationPoints);
        } else if (correlationPoints <= 0) {
            reward();
        }

        attacksThisWindow++;
    }

    // ── Wołane na każdym ticku ruchu ──────────────────────────────────────────
    public void onTick() {
        windowTick++;
        if (sustainedLookTargetId != -1) sustainedLookTicks++;

        if (windowTick >= SWING_RATIO_WINDOW) {
            if (attacksThisWindow >= 3 && swingsThisWindow == 0) {
                buffer(1.5, String.format("sub:SwingRatio attacks:%d swings:0", attacksThisWindow));
            } else {
                reward();
            }
            swingsThisWindow = 0;
            attacksThisWindow = 0;
            windowTick = 0;
        } else {
            reward();
        }
    }

    // ── Pomocniki ─────────────────────────────────────────────────────────────

    /**
     * Jerk (druga pochodna rotacji) z ostatnich próbek w rotationSamples —
     * duża, nagła zmiana PRZYSPIESZENIA obrotu (nie samej prędkości) tuż przed
     * atakiem jest sygnaturą mechanicznego "przyciągnięcia" do celu, bo ludzki
     * ruch myszy ma ciągłą, gładką krzywą przyspieszenia nawet przy szybkich ruchach.
     */
    private double computeRecentJerk() {
        if (data.rotationSamples.size() < 4) return 0.0;

        float[][] samples = data.rotationSamples.toArray(new float[0][]);
        int n = samples.length;

        double d1 = angleDelta(samples[n - 2][0], samples[n - 1][0]);
        double d2 = angleDelta(samples[n - 3][0], samples[n - 2][0]);
        double d3 = angleDelta(samples[n - 4][0], samples[n - 3][0]);

        double accel1 = d1 - d2;
        double accel2 = d2 - d3;
        return Math.abs(accel1 - accel2);
    }

    private double angleDelta(float a, float b) {
        return normalizeAngle(b - a);
    }

    /**
     * Aktualizuje "sustained look target" — encję, na którą gracz faktycznie
     * utrzymuje wąski FOV przez kolejne ticki (a nie tylko w momencie ataku).
     * Reset licznika, gdy cel się zmienia.
     */
    private void updateSustainedLookTarget(Entity target) {
        if (angleWithinFov(target)) {
            if (sustainedLookTargetId != target.getEntityId()) {
                sustainedLookTargetId = target.getEntityId();
                sustainedLookTicks = 0;
            }
        }
    }

    private boolean angleWithinFov(Entity target) {
        return lagCompensatedAngle(target) <= FOV_LIMIT;
    }

    /**
     * Miss distance przez prawdziwy raytrace (RayTraceUtil) z zamrożonej
     * rotacji gracza na lag-compensated pozycji celu — 0.0 oznacza trafienie
     * promienia w bounding box, wartość dodatnia to ile promień "chybił".
     */
    private double lagCompensatedRaytraceMiss(Entity target) {
        long targetTimestamp = System.currentTimeMillis() - (long) data.averagePing();

        double bestMiss = Double.MAX_VALUE;
        for (EntityHistoryTracker.TimedLocation loc : EntityHistoryTracker.getPositionsInWindow(
                target, targetTimestamp, ANGLE_LOOKUP_WINDOW_MS)) {

            BoundingBox box = expandedBoxAt(target, loc);
            Vector direction = directionFromRotation(data.yaw, data.pitch);
            Vector eye = new Vector(data.x, data.y + 1.62, data.z);

            double miss = RayTraceUtil.missDistance(eye, direction, box, REACH_LIMIT);
            if (miss < bestMiss) bestMiss = miss;
        }
        return bestMiss == Double.MAX_VALUE ? 0.0 : bestMiss;
    }

    private BoundingBox expandedBoxAt(Entity target, EntityHistoryTracker.TimedLocation loc) {
        BoundingBox currentBox = target.getBoundingBox();
        double halfWidth = (currentBox.getMaxX() - currentBox.getMinX()) / 2.0;
        double height = currentBox.getMaxY() - currentBox.getMinY();
        BoundingBox box = new BoundingBox(
            loc.x - halfWidth, loc.y, loc.z - halfWidth,
            loc.x + halfWidth, loc.y + height, loc.z + halfWidth
        );
        box.expand(RAYTRACE_EXPAND);
        return box;
    }

    private Vector directionFromRotation(float yaw, float pitch) {
        double yawRad = Math.toRadians(yaw);
        double pitchRad = Math.toRadians(pitch);
        double x = -Math.sin(yawRad) * Math.cos(pitchRad);
        double y = -Math.sin(pitchRad);
        double z = Math.cos(yawRad) * Math.cos(pitchRad);
        return new Vector(x, y, z).normalize();
    }

    /**
     * Kąt między kierunkiem patrzenia gracza a wektorem do celu, lag-compensated
     * (patrz javadoc klasy) — używany przez sub-check E (multi-entity) i
     * updateSustainedLookTarget (sub-check C), gdzie interesuje nas prosty
     * kąt do środka celu, nie pełny raytrace na bounding box.
     */
    private double lagCompensatedAngle(Entity target) {
        long targetTimestamp = System.currentTimeMillis() - (long) data.averagePing();

        double minAngle = Double.MAX_VALUE;
        for (EntityHistoryTracker.TimedLocation loc : EntityHistoryTracker.getPositionsInWindow(
                target, targetTimestamp, ANGLE_LOOKUP_WINDOW_MS)) {

            double eyeHeight = target instanceof LivingEntity
                ? ((LivingEntity) target).getEyeHeight() : 0.9;

            double dx = loc.x - data.x;
            double dz = loc.z - data.z;
            double dy = (loc.y + eyeHeight / 2.0) - (data.y + 1.62);

            double targetYaw = Math.toDegrees(Math.atan2(-dx, dz));
            double targetPitch = Math.toDegrees(-Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

            for (float yaw : new float[]{data.yaw, data.lastYaw}) {
                for (float pitch : new float[]{data.pitch, data.lastPitch}) {
                    double dyaw = Math.abs(normalizeAngle(yaw - targetYaw));
                    double dpitch = Math.abs(pitch - targetPitch);
                    double angle = Math.sqrt(dyaw * dyaw + dpitch * dpitch);
                    if (angle < minAngle) minAngle = angle;
                }
            }
        }
        return minAngle;
    }

    private double normalizeAngle(double angle) {
        while (angle > 180) angle -= 360;
        while (angle < -180) angle += 360;
        return angle;
    }

    @Override
    public void reset() {
        super.reset();
        swingsThisWindow = 0;
        attacksThisWindow = 0;
        windowTick = 0;
        recentSwingFlags.clear();
        sustainedLookTargetId = -1;
        sustainedLookTicks = 0;
    }
}
