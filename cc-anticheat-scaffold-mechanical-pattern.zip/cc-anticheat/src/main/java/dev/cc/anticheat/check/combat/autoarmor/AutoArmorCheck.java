/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.check.combat.autoarmor;

import dev.cc.anticheat.check.Check;
import dev.cc.anticheat.data.PlayerData;
import dev.cc.anticheat.violation.ViolationProcessor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * cc-anticheat — AutoArmorCheck
 *
 * Wykrywa "AutoArmor" — automatyczne zakładanie zbroi w reakcji na zdarzenie
 * (np. natychmiast po otrzymaniu obrażeń, po wejściu do walki, po utracie
 * poprzedniej zbroi) w czasie niemożliwym do osiągnięcia ręcznie.
 *
 * Zasada działania: śledzimy każdą zmianę w 4 slotach pancerza gracza.
 * Ręczne zakładanie zbroi w vanilla wymaga:
 *   - otwarcia ekwipunku (co generuje WINDOW_CLICK z konkretnym slotem),
 *   - LUB shift-clicka na przedmiocie w hotbarze/ekwipunku (auto-equip),
 * a każde z tych zdarzeń wymaga co najmniej jednego ticka renderowania GUI po
 * stronie klienta przed wysłaniem pakietu — więc naturalny czas reakcji między
 * zdarzeniem wyzwalającym (obrażenia/utrata zbroi) a zmianą slotu pancerza nie
 * powinien być poniżej progu ludzkiej reakcji.
 *
 * Sub-checki:
 *   A. Reaction Time — zbroja założona < 100ms po otrzymaniu obrażeń
 *   B. Multi-slot Instant — 2+ sloty pancerza zmienione w tym samym ticku
 *      (założenie całego seta na raz jest fizycznie niemożliwe jednym klikiem)
 */
public class AutoArmorCheck extends Check {

    private static final long HUMAN_REACTION_MIN_MS = 100L;
    private static final long DAMAGE_WINDOW_MS = 1500L;

    private long lastDamageMs = 0L;
    private ItemStack[] lastArmorContents = new ItemStack[4];
    private long lastArmorChangeMs = 0L;
    private int changedSlotsThisTick = 0;
    private long changedSlotsTickMs = 0L;

    public AutoArmorCheck(PlayerData data, ViolationProcessor vp) {
        super(data, vp, "AutoArmor");
        this.vlIncrement = 1.0;
        this.vlDecay = 0.1;
        this.vlDecayMultiplier = 0.9;
        this.flagThreshold = 3.0;
        this.setbackThreshold = Double.MAX_VALUE;
        this.requiredBuffer = 0; // dyskretne zdarzenie, jak AutoTotem
        this.maxBuffer = 5;

        ItemStack[] current = data.player.getInventory().getArmorContents();
        System.arraycopy(current, 0, lastArmorContents, 0, 4);
    }

    /** Wołane gdy gracz otrzymuje obrażenia (EntityDamageEvent). */
    public void onDamageTaken() {
        lastDamageMs = System.currentTimeMillis();
    }

    /**
     * Wołane cyklicznie (np. na każdym pakiecie ruchu lub akcji ekwipunku) —
     * porównuje aktualną zawartość slotów pancerza z poprzednio znaną.
     */
    public void onInventoryPoll() {
        if (tickExemption()) return;

        Player player = data.player;
        ItemStack[] current = player.getInventory().getArmorContents();
        long now = System.currentTimeMillis();

        int changedSlots = 0;
        for (int i = 0; i < 4; i++) {
            if (!itemStackEquals(current[i], lastArmorContents[i])) {
                changedSlots++;
            }
        }

        if (changedSlots == 0) return;

        // ── B. Multi-slot Instant ─────────────────────────────────────────
        if (now - changedSlotsTickMs < 60L) {
            changedSlotsThisTick += changedSlots;
        } else {
            changedSlotsThisTick = changedSlots;
        }
        changedSlotsTickMs = now;

        if (changedSlotsThisTick >= 2) {
            buffer(3.0, String.format("sub:MultiSlot slots:%d", changedSlotsThisTick));
        }

        // ── A. Reaction Time ────────────────────────────────────────────────
        long sinceDamage = now - lastDamageMs;
        if (sinceDamage < DAMAGE_WINDOW_MS && sinceDamage < HUMAN_REACTION_MIN_MS) {
            buffer(3.5, String.format("sub:ReactionTime sinceDamageMs:%d threshold:%d", sinceDamage, HUMAN_REACTION_MIN_MS));
        } else {
            reward();
        }

        System.arraycopy(current, 0, lastArmorContents, 0, 4);
        lastArmorChangeMs = now;
    }

    private boolean itemStackEquals(ItemStack a, ItemStack b) {
        if (a == null && b == null) return true;
        if (a == null || b == null) return false;
        return a.isSimilar(b) && a.getAmount() == b.getAmount();
    }

    @Override
    public void reset() {
        super.reset();
        changedSlotsThisTick = 0;
        changedSlotsTickMs = 0L;
    }
}
