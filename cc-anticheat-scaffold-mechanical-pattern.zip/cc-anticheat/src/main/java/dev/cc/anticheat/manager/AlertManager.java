/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.manager;

import dev.cc.anticheat.CCAnticheat;
import dev.cc.anticheat.data.AlertHistory;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.hover.content.Text;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * cc-anticheat — AlertManager
 *
 * Intave-style click alerts:
 *   "&d&lAC &8• &f{player} &7{check} (detail) [vl:x.x]"
 *
 * Clicking the player's name runs /anticheat alertgui <player>, opening the
 * player-info GUI (head, warning/kick/ban history, spectate button).
 *
 * Staff toggle their own alert stream on/off with /anticheat alert.
 * Default state = ON for anyone holding ccanticheat.alerts.
 */
public class AlertManager {

    private static final String PREFIX_LEGACY = "&d&lAC &8• ";

    private final CCAnticheat plugin;
    private final AlertHistory history;

    /** Staff UUIDs whose alert stream is currently OFF. */
    private final Set<UUID> alertsDisabled = ConcurrentHashMap.newKeySet();

    public AlertManager(CCAnticheat plugin, AlertHistory history) {
        this.plugin  = plugin;
        this.history = history;
    }

    /** @return true if alerts are now ON, false if they were just turned OFF. */
    public boolean toggle(Player staff) {
        UUID id = staff.getUniqueId();
        if (alertsDisabled.remove(id)) {
            return true;
        }
        alertsDisabled.add(id);
        return false;
    }

    public boolean isEnabled(Player staff) {
        return !alertsDisabled.contains(staff.getUniqueId());
    }

    /**
     * Broadcasts a clickable, Intave-style flag alert to every online staff
     * member who has ccanticheat.alerts and hasn't muted their stream.
     */
    public void sendAlert(String targetName, String checkName, String detail, double vl) {
        history.record(targetName, AlertHistory.Entry.Type.ALERT, checkName, detail);

        TextComponent message = legacy(PREFIX_LEGACY);

        TextComponent nameComp = legacy(ChatColor.WHITE + targetName + ChatColor.RESET + " ");
        nameComp.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/anticheat alertgui " + targetName));
        nameComp.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                new Text(ChatColor.GRAY + "Kliknij, aby otworzyć profil AC gracza " + targetName)));

        StringBuilder detailPart = new StringBuilder();
        detailPart.append(ChatColor.GRAY).append(checkName);
        if (detail != null && !detail.isEmpty()) {
            detailPart.append(ChatColor.DARK_GRAY).append(" (").append(detail).append(")");
        }
        detailPart.append(ChatColor.DARK_GRAY).append(" [vl:").append(String.format("%.1f", vl)).append("]");

        message.addExtra(nameComp);
        message.addExtra(legacy(detailPart.toString()));

        Bukkit.getScheduler().runTask(plugin, () -> {
            for (Player staff : Bukkit.getOnlinePlayers()) {
                if (staff.hasPermission("ccanticheat.alerts") && isEnabled(staff)) {
                    staff.spigot().sendMessage(message);
                }
            }
        });
    }

    /** Records + broadcasts that cc-anticheat kicked a player (non-clickable, informational). */
    public void sendKickAlert(String targetName, String checkName, String reasonDetail) {
        history.record(targetName, AlertHistory.Entry.Type.KICK, checkName, reasonDetail);
        send(ChatColor.RED + "Wyrzucono " + ChatColor.WHITE + targetName
                + ChatColor.RED + " (" + checkName + ")");
    }

    /** Simple AC-prefixed system message broadcast to all alert-subscribed staff. */
    public void send(String rawMessage) {
        String full = ChatColor.translateAlternateColorCodes('&', PREFIX_LEGACY) + rawMessage;
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (Player staff : Bukkit.getOnlinePlayers()) {
                if (staff.hasPermission("ccanticheat.alerts") && isEnabled(staff)) {
                    staff.sendMessage(full);
                }
            }
        });
    }

    /** AC-prefixed message to a single player (toggle confirmations, errors, etc). */
    public void sendTo(Player target, String rawMessage) {
        target.sendMessage(ChatColor.translateAlternateColorCodes('&', PREFIX_LEGACY) + rawMessage);
    }

    private static TextComponent legacy(String legacyText) {
        return new TextComponent(TextComponent.fromLegacyText(ChatColor.translateAlternateColorCodes('&', legacyText)));
    }
}
