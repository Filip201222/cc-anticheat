/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.manager;

import dev.cc.anticheat.CCAnticheat;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * cc-anticheat — SpectateManager
 *
 * Drops staff into spectator mode and follows a suspect, remembering the
 * staff member's previous gamemode/location so it can be restored later.
 * Used by both /anticheat spectate <player> and the GUI's green-dye button.
 */
public class SpectateManager {

    private final CCAnticheat plugin;

    private final Map<UUID, SavedState> saved = new ConcurrentHashMap<>();
    /** staffUUID -> targetUUID currently being spectated. */
    private final Map<UUID, UUID> currentlySpectating = new ConcurrentHashMap<>();

    public SpectateManager(CCAnticheat plugin) {
        this.plugin = plugin;
    }

    /**
     * Starts (or stops, if already spectating the same target) spectating.
     *
     * @return true if staff is now spectating target, false if spectate mode was cancelled
     */
    public boolean toggleSpectate(Player staff, Player target) {
        UUID staffId = staff.getUniqueId();

        if (currentlySpectating.containsKey(staffId)) {
            UUID previousTarget = currentlySpectating.get(staffId);
            stop(staff);
            if (previousTarget.equals(target.getUniqueId())) {
                return false; // was spectating this same target -> toggled off
            }
        }

        saved.put(staffId, new SavedState(staff.getGameMode(), staff.getLocation().clone()));
        currentlySpectating.put(staffId, target.getUniqueId());

        staff.setGameMode(GameMode.SPECTATOR);
        staff.teleport(target.getLocation());
        staff.setSpectatorTarget(target);
        return true;
    }

    /** Restores the staff member's previous gamemode/location and stops spectating. */
    public void stop(Player staff) {
        UUID staffId = staff.getUniqueId();
        currentlySpectating.remove(staffId);
        SavedState state = saved.remove(staffId);
        if (state == null) return;

        staff.setSpectatorTarget(null);
        staff.setGameMode(state.gameMode);
        Location loc = state.location;
        if (loc.getWorld() != null) {
            staff.teleport(loc);
        }
    }

    public boolean isSpectating(Player staff) {
        return currentlySpectating.containsKey(staff.getUniqueId());
    }

    /** Called on quit to avoid leaking saved state for players who log off mid-spectate. */
    public void forget(Player staff) {
        saved.remove(staff.getUniqueId());
        currentlySpectating.remove(staff.getUniqueId());
    }

    private static class SavedState {
        final GameMode gameMode;
        final Location location;

        SavedState(GameMode gameMode, Location location) {
            this.gameMode = gameMode;
            this.location = location;
        }
    }
}
