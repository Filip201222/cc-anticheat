/*
 * Plugin zrobiony dla servera CatCore
 * © Wszelkie prawa zastrzeżone
 * Autor: _77Nezzi_i
 */
package dev.cc.anticheat.data;

import dev.cc.anticheat.predict.MovementEnvelope;

/**
 * cc-anticheat — MovementData
 *
 * Niemutowalny (poza polami wypełnianymi podczas budowy) zrzut jednego ticka ruchu gracza.
 * Trzymamy krótką historię tych obiektów w PlayerData (ring buffer), żeby checki mogły
 * analizować SEKWENCJE ruchu, a nie pojedyncze pakiety w oderwaniu od kontekstu.
 *
 * To jest odpowiednik GrimPlayer's "movement" snapshotu z każdego ticka predykcji —
 * ale uproszczony do naszych własnych potrzeb detekcji.
 */
public class MovementData {

    // ── Pozycja ────────────────────────────────────────────────────────────
    public final double x, y, z;
    public final double lastX, lastY, lastZ;
    public final float yaw, pitch;

    /** Wektor ruchu faktycznie wysłany przez klienta (x - lastX, y - lastY, z - lastZ). */
    public final double deltaX, deltaY, deltaZ;

    // ── Stan gruntu / kolizji ──────────────────────────────────────────────
    public final boolean clientClaimsOnGround;
    /** Wynik naszej własnej weryfikacji AABB-collision, niezależny od deklaracji klienta. */
    public boolean actuallyOnGround;
    public boolean horizontalCollision;
    public boolean verticalCollisionUp;

    // ── Kontekst środowiska w momencie ticka ──────────────────────────────
    public boolean inLiquid;
    public boolean inWater;
    public boolean inLava;
    public boolean inWeb;
    public boolean inBubbleColumn;
    public boolean onClimbable;
    public boolean onIce;
    public boolean onSlimeBlock;
    public boolean onHoneyBlock;
    public boolean onSoulSand;
    public boolean gliding;
    public boolean swimming;
    public boolean sneaking;
    public boolean sprinting;
    public boolean flying;
    public boolean inVehicle;
    public double blockFriction = 0.6;
    /** Bounding box gracza dotyka bloku typu piston/moving block w tym ticku. */
    public boolean touchingPistonOrMovingBlock;

    // ── Predykcja serwera ────────────────────────────────────────────────
    public double predictedDeltaX;
    public double predictedDeltaY;
    public double predictedDeltaZ;
    public double offsetHorizontal;
    public double offsetVertical;

    /**
     * Pełny "expected state" tego ticka (expected velocity + legal envelope +
     * confidence) — patrz PlayerPhysicsEngine#computeEnvelope. Wyliczany raz
     * przez PacketListener zaraz po zbudowaniu tego snapshotu, tak żeby
     * wszystkie checki operujące na tym samym ticku (Speed, Flight, NoSlow,
     * Strafe...) współdzieliły jedno obliczenie zamiast każdy liczył je od
     * nowa. Może być null tylko w skrajnym przypadku braku dostępu do
     * Player w momencie budowy (np. gracz rozłączył się w tym samym ticku).
     */
    public MovementEnvelope envelope;

    // ── Timing ──────────────────────────────────────────────────────────
    public final long timestampMs;
    /** Numer ticka serwerowego (monotoniczny licznik utrzymywany przez PlayerData). */
    public final long tickCount;

    public MovementData(double x, double y, double z,
                         double lastX, double lastY, double lastZ,
                         float yaw, float pitch,
                         boolean clientClaimsOnGround,
                         long tickCount) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.lastX = lastX;
        this.lastY = lastY;
        this.lastZ = lastZ;
        this.yaw = yaw;
        this.pitch = pitch;
        this.deltaX = x - lastX;
        this.deltaY = y - lastY;
        this.deltaZ = z - lastZ;
        this.clientClaimsOnGround = clientClaimsOnGround;
        this.actuallyOnGround = clientClaimsOnGround;
        this.timestampMs = System.currentTimeMillis();
        this.tickCount = tickCount;
    }

    /** Pozioma odległość przebyta w tym ticku (bez osi Y). */
    public double horizontalDistance() {
        return Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
    }

    /** Pełna odległość 3D przebyta w tym ticku. */
    public double totalDistance() {
        return Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
    }

    @Override
    public String toString() {
        return String.format(
            "Move[dx=%.4f dy=%.4f dz=%.4f ground=%b water=%b friction=%.3f]",
            deltaX, deltaY, deltaZ, actuallyOnGround, inWater, blockFriction);
    }
}
